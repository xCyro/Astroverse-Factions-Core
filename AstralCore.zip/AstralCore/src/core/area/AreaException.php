<?php

declare(strict_types = 1);

namespace core\area;

use Exception;

class AreaException extends Exception {

}