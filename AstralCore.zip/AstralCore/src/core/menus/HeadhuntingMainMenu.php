//?php
//
//declare(strict_types = 1);
//
//namespace core\menus;
//
//use core\Elemental;
//use core\ElementalPlayer;
//use core\translation\Translation;
//use core\translation\TranslationException;
//use core\libs\muqsit\invmenu\InvMenu;
///use pocketmine\inventory\Inventory;
///use pocketmine\inventory\transaction\action\SlotChangeAction;
//use pocketmine\item\Item;
///use pocketmine\Player;
//use pocketmine\utils\TextFormat;
//
//class HeadhuntingMainMenu {
//
    ///** @var ElementalPlayer */
    //private $player;
//
    ///** @var InvMenu */
    //private $menu;
//
    ///**
    // * HeadhuntingMainMenu constructor.
    // *
    // * @param ElementalPlayer $sender
    // * @param ElementalPlayer $receiver
    // */
   // public function __construct(ElementalPlayer $player) {
//		
		//$this->player = $player;
//
        //$this->menu = InvMenu::create(InvMenu::TYPE_CHEST);
        //$this->menu->setName(TextFormat::BOLD . TextFormat::RED . "Headhunting");
        //$item = Item::get(Item::STAINED_GLASS, 14);
        ////$item->setCustomName(TextFormat::RESET . TextFormat::RED . TextFormat::BOLD . "DENY");
        ////$item->setLore([TextFormat::RESET . TextFormat::GRAY . "This can only be modified by " . TextFormat::LIGHT_PURPLE . $this->sender->getName()]);
        ///$this->menu->getInventory()->setItem(4, $item);
        ////$item = Item::get(Item::STAINED_GLASS, 14);
        ///$item->setCustomName(TextFormat::RESET . TextFormat::RED . TextFormat::BOLD . "DENY");
        //$item->setLore([TextFormat::RESET . TextFormat::GRAY . "This can only be modified by " . TextFormat::LIGHT_PURPLE . $this->receiver->getName()]);
        //$this->menu->getInventory()->setItem(22, $item);
        //////$this->menu->setListener(
            ///function(Player $player, Item $itemClicked, Item $itemClickedWith, SlotChangeAction $action): bool {
//
//
//
		//});
        //$this->menu->setInventoryCloseListener(
            //function(Player $player, Inventory $inventory): void {
                //foreach($this->menu->getInventory()->getContents() as $slot => $item) {
            	//}
			//}
		//);
	//}

    ///**
    // * @return ElementalPlayer
   //  */
   // public function getPlayer(): ElementalPlayer {
    //    return $this->player;
    //}

   // public function sendMenu() {
    //    $this->menu->send($this->player);
    //}
//}