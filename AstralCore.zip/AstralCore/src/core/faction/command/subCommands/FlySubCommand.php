<?php

declare(strict_types = 1);

namespace core\faction\command\subCommands;

use core\command\utils\SubCommand;
use core\faction\Faction;
use core\faction\FactionException;
use core\ElementalPlayer;
use core\translation\Translation;
use core\translation\TranslationException;
use pocketmine\command\CommandSender;

class FlySubCommand extends SubCommand {

    /**
     * FlySubCommand constructor.
     */
    public function __construct() {
        parent::__construct("fly", "/faction fly");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     *
     * @throws TranslationException
     * @throws FactionException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if(!$sender instanceof ElementalPlayer) {
            $sender->sendMessage(Translation::getMessage("noPermission"));
            return;
        }
        if($sender->getLevel()->getName() !== Faction::CLAIM_WORLD) {
            $sender->sendMessage(Translation::getMessage("noPermission"));
            return;
        }
        $faction = $sender->getFaction();
        if($faction === null) {
            $sender->sendMessage(Translation::getMessage("beInFaction"));
            return;
        }
        $factionManager = $this->getCore()->getFactionManager();
        if($factionManager->getClaimInPosition($sender) === null) {
            $sender->sendMessage(Translation::getMessage("notClaimed"));
            return;
		}
		if($factionManager->getClaimInPosition($sender)->getFaction()->getName() === $sender->getFaction()->getName()) {

			if($sender->getFaction()->getStrength() >= 1000) {
				if(!$sender->isFlying()) {
					$sender->setFlying(true);
					$sender->setAllowFlight(true);
					$sender->setFactionFly(true);
					$sender->sendMessage("§8§l(§a!§8) §r§7You have toggled your flight!");
					return;
				} else {
					$sender->setFlying(false);
					$sender->setAllowFlight(false);
					$sender->setFactionFly(false);
					$sender->sendMessage("§8§l(§c!§8) §r§7You have toggled your flight!");
					return;
				}
			} else {
				$sender->sendMessage("§8§l(§c!§8) §r§7You must have over §b1000 §7STR before you can fly in your claims.");
			}

		} else {
			$sender->sendMessage("§8§l(§c!§8) §r§7You are only able to fly in your own claims.");
			return;
		}
    }
}