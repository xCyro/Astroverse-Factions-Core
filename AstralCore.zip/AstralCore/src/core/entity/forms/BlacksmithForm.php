<?php

namespace core\entity\forms;

use core\Elemental;
use core\ElementalListener;
use core\ElementalPlayer;
use core\command\forms\RenameItemForm;
use core\command\forms\RepairForm;
use core\libs\form\MenuForm;
use core\libs\form\MenuOption;
use core\translation\Translation;
use pocketmine\entity\Skin;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class BlacksmithForm extends MenuForm
{
    public function __construct()
    {
        $title = TextFormat::DARK_PURPLE . TextFormat::BOLD . "Blacksmith";
        $text = TextFormat::DARK_AQUA."";
		$options[] = new MenuOption("Rename");
		$options[] = new MenuOption("Repair");
        parent::__construct($title, $text, $options);
    }

    public function onSubmit(Player $player, int $selectedOption): void
    {
        if (!$player instanceof ElementalPlayer) {
            return;
		}
		
		$option = $this->getOption($selectedOption)->getText();

		if($option === "Rename") {
			$player->sendForm(new RenameItemForm($player));
			return;
		}
		if($option === "Repair") {
			$player->sendForm(new RepairForm($player));
			return;
		}

    }
}
