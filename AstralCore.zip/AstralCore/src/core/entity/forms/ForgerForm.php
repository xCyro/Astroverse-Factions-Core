<?php

namespace core\entity\forms;

use core\Elemental;
use core\ElementalListener;
use core\ElementalPlayer;
use core\command\forms\RenameItemForm;
use core\command\forms\RepairForm;
use core\command\types\MaskCommand;
use core\libs\form\MenuForm;
use pocketmine\level\sound\AnvilBreakSound;
use pocketmine\level\sound\AnvilUseSound;
use core\libs\form\MenuOption;
use core\translation\Translation;
use pocketmine\entity\Skin;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class ForgerForm extends MenuForm
{
    public function __construct()
    {
        $title = TextFormat::DARK_RED . TextFormat::BOLD . "Forger";
        $text = TextFormat::DARK_AQUA."Would you like me to forge your 100,000 souls into a mask charm?";
		$options[] = new MenuOption("Yes, Forge!");
		$options[] = new MenuOption("No, don't Forge!");
        parent::__construct($title, $text, $options);
    }

    public function onSubmit(Player $player, int $selectedOption): void
    {
        if (!$player instanceof ElementalPlayer) {
            return;
		}
		
		$option = $this->getOption($selectedOption)->getText();

		if($option === "Yes, Forge!") {

			$player->getLevel()->addSound(new AnvilUseSound($player));

			$player->resetSouls();

			$item = MaskCommand::getMaskCharmItem();

			$player->getInventory()->addItem($item);

			$player->sendMessage("§r§8[§4§lForger§r§8] §r§7I have forged you a mask charm using your 100,000 souls! Also thanks for the change.");

			return;
		}

		if($option === "No, don't Forge!")
		{

			$player->getLevel()->addSound(new AnvilBreakSound($player));

			$player->sendMessage("§r§8[§4§lForger§r§8] §r§7Ok, i will not forge your 100,000 souls into a mask charm.");

			return;

		}

    }
}
