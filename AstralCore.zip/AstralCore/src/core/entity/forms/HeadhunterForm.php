<?php

namespace core\entity\forms;

use core\item\CustomItem;
use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\libs\form\ModalForm;
use core\item\types\Head;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use core\item\types\MoneyNote;
use core\item\types\XPNote;
use core\translation\Translation;
use core\translation\TranslationException;
use core\libs\form\CustomForm;
use core\libs\form\CustomFormResponse;
use core\libs\form\element\Dropdown;
use core\libs\form\element\Input;
use pocketmine\level\sound\BlazeShootSound;
use pocketmine\level\Level;
use pocketmine\block\Block;
use pocketmine\entity\Entity;
use pocketmine\entity\Living;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\inventory\ArmorInventory;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\level\Position;
use pocketmine\level\sound\AnvilBreakSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\nbt\BigEndianNBTStream;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\scheduler\Task;
use pocketmine\tile\Chest as TileChest;
use pocketmine\tile\Container;
use pocketmine\tile\Tile;

class HeadhunterForm extends ModalForm{

	/**
	 * HeadhunterForm constructor.
	 *
	 * @param ElementalPlayer $player
	 */
	public function __construct(ElementalPlayer $player){
		$item = $player->getInventory()->getItemInHand();
		//if($item->getId() !== Item::HEAD){
			//return;
		//}
		$tag = $item->getNamedTagEntry(CustomItem::CUSTOM);
		//if(!$tag instanceof CompoundTag){
			//return;
		//}
		//if($tag == null){
			//return;
		//}
		//if(!$tag->hasTag(Head::PLAYER, StringTag::class)){
			//return;
		//}
		//if($tag == null){
			//return;
		//}
		$title = TextFormat::BOLD . TextFormat::RED . "Headhunter";
		$this->title = $title;
        $text = "Ah, yes. A player's head it seems, what I was looking for. I'll be willing to trade 10% of that player's money for it. Do you accept my offer?";
        $this->content = $text;
        $this->button1 = "gui.yes";
        $this->button2 = "gui.no";
        parent::__construct($title, $text);
    }

	/**
	 * @param Player $player
	 * @param bool   $choice
	 */
	public function onSubmit(Player $player, bool $choice) : void{
		if(!$player instanceof ElementalPlayer){
			return;
		}
		if($choice == true){
			//$item = $player->getInventory()->getItemInHand();
			//$player->getInventory()->removeItem($item);
			//$item = new XPNote(mt_rand(25000, 5000));
			//$player->getInventory()->addItem($item->getItemForm());

			$item = $player->getInventory()->getItemInHand();
			$tag = $item->getNamedTagEntry(CustomItem::CUSTOM);

			if($tag === null){
				return;
			}

			if($tag->hasTag(Head::PLAYER, StringTag::class)){

				$player->getLevel()->addSound(new BlazeShootSound($player));
				$amount = $tag->getInt("Balance");
				$name = $tag->getString("Name");
				$player->addToBalance($amount);
				$player->sendMessage("§l§8(§a!§8)§r §7You have received §b$$amount §7from §b$name's §7head.§r");
				$player->getInventory()->setItemInHand($item->setCount($item->getCount() - 1));
				return;
			} else {
				$player->sendMessage("§8(§c§lHEADHUNTER§r§8) §r§7Really human, you tried scamming? But im a nice pig so i'll forgive you!");
				return;
			}
		}
	}
}