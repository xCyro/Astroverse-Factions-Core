<?php

declare(strict_types = 1);

namespace core\crate\types;

use core\crate\Crate;
use core\crate\Reward;
use core\item\ItemManager;
use core\item\types\MoneyNote;
use core\item\types\ChestKit;
use core\item\types\BloodyNote;
use core\item\types\MoneyPouch;
use core\item\types\EnchantmentBook;
use core\item\types\SellWand;
use core\item\types\XPNote;
use core\Elemental;
use core\ElementalPlayer;
use core\utils\UtilsException;
use pocketmine\item\Item;
use pocketmine\level\Position;

class RareCrate extends Crate {

    /**
     * RareCrate constructor.
     * @param Position $position
     */
    public function __construct(Position $position) {
        parent::__construct(self::RARE, $position, [
            new Reward("$100,000", Item::get(Item::PAPER, 0, 1), function(ElementalPlayer $player): void {
                $player->getInventory()->addItem((new MoneyNote(100000))->getItemForm());
            }, 50),
            new Reward("1,500 XP Note", Item::get(Item::PAPER, 0, 1), function(ElementalPlayer $player): void {
                $player->getInventory()->addItem((new XPNote(1500))->getItemForm());
            }, 100),
            new Reward("x64 Obsidian", Item::get(Item::OBSIDIAN, 0, 32), function(ElementalPlayer $player): void {
                $player->getInventory()->addItem(Item::get(Item::OBSIDIAN, 0, 64));
            }, 85),
            new Reward("x5 Enchanted Golden Apple", Item::get(Item::ENCHANTED_GOLDEN_APPLE, 0, 5), function(ElementalPlayer $player): void {
                $player->getInventory()->addItem(Item::get(Item::ENCHANTED_GOLDEN_APPLE, 0, 5));
            }, 79),
            new Reward("x32 Golden Apple", Item::get(Item::GOLDEN_APPLE, 0, 32), function(ElementalPlayer $player): void {
                $player->getInventory()->addItem(Item::get(Item::GOLDEN_APPLE, 0, 32));
            }, 99),
            new Reward("Enchantment", Item::get(Item::ENCHANTED_BOOK, 0, 1), function(ElementalPlayer $player): void {
                $player->getInventory()->addItem((new EnchantmentBook(ItemManager::getRandomEnchantment()))->getItemForm());
            }, 100),
            new Reward("Alula Kit", Item::get(Item::CHEST_MINECART, 0, 1), function(ElementalPlayer $player): void {
                $item = new ChestKit(Elemental::getInstance()->getKitManager()->getKitByName("Alula"));
                $player->getInventory()->addItem($item->getItemForm());
            }, 100),
            new Reward("Almathea Kit", Item::get(Item::CHEST_MINECART, 0, 1), function(ElementalPlayer $player): void {
                $item = new ChestKit(Elemental::getInstance()->getKitManager()->getKitByName("Almathea"));
                $player->getInventory()->addItem($item->getItemForm());
            }, 75),
            new Reward("x32 TNT", Item::get(Item::TNT, 0, 32), function(ElementalPlayer $player): void {
                $player->getInventory()->addItem(Item::get(Item::TNT, 0, 32));
            }, 91),
            new Reward("Sell Wand (Uses: 10)", Item::get(Item::DIAMOND_HOE, 0, 1), function(ElementalPlayer $player): void {
                $player->getInventory()->addItem((new SellWand(10))->getItemForm());
            }, 90),
            new Reward("x2 Epic Crate Keys", Item::get(Item::STRING), function(ElementalPlayer $player): void {
                $crate = Elemental::getInstance()->getCrateManager()->getCrate("Epic");
                $player->addKeys($crate, 2);
			}, 36),
			new Reward("Bloody Note", Item::get(Item::PAPER, 0, 1), function(ElementalPlayer $player): void {
				$player->getInventory()->addItem((new BloodyNote(75000))->getItemForm());
			}, 125),
			new Reward("Money Pouch", Item::get(Item::ENDER_CHEST, 0, 1), function(ElementalPlayer $player): void {
				$player->getInventory()->addItem((new MoneyPouch(200000))->getItemForm());
			}, 40)
        ]);
    }

    /**
     * @param ElementalPlayer $player
     *
     * @throws UtilsException
     */
    public function spawnTo(ElementalPlayer $player): void {
        $particle = $player->getFloatingText($this->getName());
        if($particle !== null) {
            return;
        }
        $player->addFloatingText(Position::fromObject($this->getPosition()->add(0.5, 1.25, 0.5), $this->getPosition()->getLevel()), $this->getName(), "§l§bRare Crate§r\n§7You have §b" . $player->getKeys($this) . " §7keys!§r");
    }

    /**
     * @param ElementalPlayer $player
     *
     * @throws UtilsException
     */
    public function updateTo(ElementalPlayer $player): void {
        $particle = $player->getFloatingText($this->getName());
        if($particle === null) {
            $this->spawnTo($player);
        }
        $text = $player->getFloatingText($this->getName());
        $text->update("§l§bRare Crate§r\n§7You have §b" . $player->getKeys($this) . " §7keys!§r");
        $text->sendChangesTo($player);
    }

    /**
     * @param ElementalPlayer $player
     */
    public function despawnTo(ElementalPlayer $player): void {
        $particle = $player->getFloatingText($this->getName());
        if($particle !== null) {
            $particle->despawn($player);
        }
    }

    /**
     * @param Reward        $reward
     * @param ElementalPlayer $player
     *
     * @throws UtilsException
     */
    public function showReward(Reward $reward, ElementalPlayer $player): void {
        $particle = $player->getFloatingText($this->getName());
        if($particle === null) {
            $this->spawnTo($player);
        }
        $text = $player->getFloatingText($this->getName());
        $text->update("§l§b" . $reward->getName());
        $text->sendChangesTo($player);
    }
}
