<?php


namespace core\crate\types;


use core\crate\Reward;
use core\Elemental;
use core\ElementalPlayer;
use core\item\ItemManager;
use core\item\types\EnchantmentBook;
use core\item\types\XPNote;
use core\item\types\BloodyNote;
use core\item\types\KothFlare;
use core\item\types\AsteroidSpell;
use core\item\types\ImmortalityRune;
use core\item\types\TNTLauncher;
use core\kit\Kit;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;

class GreekCrate
{
    /** @var array  */
    private $rewards = [];

    public const PREFIX = TextFormat::RESET . TextFormat::AQUA . TextFormat::BOLD . "ARTISTIC Crate";

    public function __construct()
    {
        $this->rewards = [
            new Reward("CE Books", Item::get(Item::ENCHANTED_BOOK, 0, 1), function (ElementalPlayer $player): void {
				$player->getInventory()->addItem((new EnchantmentBook(ItemManager::getRandomEnchantment()))->getItemForm());
				$player->sendMessage("§8§l(§b!§8) §r§7You have won a random enchantment book!");
            }, 30),
            new Reward("5x Legendary Crate Keys", Item::get(Item::PAPER), function (ElementalPlayer $player): void {
                $crate = Elemental::getInstance()->getCrateManager()->getCrate("Legendary");
				$player->addKeys($crate, 5);
				$player->sendMessage("§8§l(§b!§8) §r§7You have won §b5 §7legendary keys!");
            }, 50),
            new Reward("$1,000,000", Item::get(Item::PAPER, 0, 1), function (ElementalPlayer $player): void {
				$player->addToBalance(1000000);
				$player->sendMessage("§8§l(§b!§8) §r§7You have won §2§a1,000,000 §r§7in balance!");
            }, 70),
            new Reward("5000 XP Note", Item::get(Item::PAPER, 0, 5), function (ElementalPlayer $player): void {
				$player->getInventory()->addItem((new XPNote(5000))->getItemForm()->setCount(5));
				$player->sendMessage("§8§l(§b!§8) §r§7You have won a §b5000 §7XP note!");
            }, 90),
            new Reward("Random Kit", Item::get(Item::PAPER, 0, 1), function (ElementalPlayer $player): void {
                $kits = Elemental::getInstance()->getKitManager()->getSacredKits();
                /** @var Kit $kit */
                $kit = $kits[array_rand($kits)];
				$kit->giveTo($player);
				$player->sendMessage("§8§l(§b!§8) §r§7You have won a §bMystery §7kit!");
			}, 10),
			new Reward("Koth Flare", Item::get(Item::DYE, 0, 1), function(ElementalPlayer $player): void {
				$player->getInventory()->addItem((new KothFlare(1))->getItemForm());
			}, 100),
			new Reward("Bloody Note", Item::get(Item::PAPER, 0, 1), function(ElementalPlayer $player): void {
				$player->getInventory()->addItem((new BloodyNote(1500000))->getItemForm());
			}, 25),
			new Reward("Asteroid Spell", Item::get(Item::PRISMARINE_CRYSTALS, 0, 1), function(ElementalPlayer $player): void {
                $player->getInventory()->addItem((new AsteroidSpell(1))->getItemForm());
			}, 100),
			new Reward("Immortality Rune", Item::get(Item::PRISMARINE_SHARD, 0, 1), function(ElementalPlayer $player): void {
                $player->getInventory()->addItem((new ImmortalityRune(30))->getItemForm());
			}, 100),
			new Reward("TNT Launcher", Item::get(Item::PRISMARINE_CRYSTALS, 0, 1), function(ElementalPlayer $player): void {
                $player->getInventory()->addItem((new TNTLauncher(25, 3))->getItemForm());
            }, 100),
        ];
    }


    /**
     * @return Reward[]
     */
    public function getRewards(): array
    {
        return $this->rewards;
    }

    /**
     * @param int $loop
     *
     * @return Reward
     */
    public function getReward(int $loop = 0): Reward
    {
        $chance = mt_rand(0, 100);
        $reward = $this->rewards[array_rand($this->rewards)];
        if ($loop >= 10) {
            return $reward;
        }
        if ($reward->getChance() <= $chance) {
            return $this->getReward($loop + 1);
        }
        return $reward;
    }

}