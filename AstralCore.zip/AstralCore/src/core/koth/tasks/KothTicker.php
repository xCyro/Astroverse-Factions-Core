<?php

namespace core\koth\tasks;

use core\Elemental;
use core\ElementalPlayer;
use core\koth\Koth;
use core\koth\KothManager;
use core\translation\Translation;
use pocketmine\item\Item;
use pocketmine\scheduler\Task;
use pocketmine\level\Position;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class KothTicker extends Task
{

	private $kothManager;

	public function __construct()
	{

		$this->kothManager = Elemental::getInstance()->getKothManager();

	}

	public function onRun(int $tick)
	{

		if($this->kothManager->isRunning())
		{

			$level = Elemental::getInstance()->getServer()->getLevelByName("koth");

			$list = null;

			foreach($this->kothManager->getCaptures() as $player)
			{

				$list .= "§e" . $player->getName() . "§r§8 | §r§3" . $player->getKothCaptureProgress() . "§r\n";

			}

			foreach($level->getPlayers() as $player)
			{

				if($player->getFloatingText("KoTH") !== null)
				{

					$player->removeFloatingText("KoTH");

				}

				$player->addFloatingText(new Position(1, 65, 50, $level), "KoTH", "§3§l§kIII§r§b§l KOTH §r§3§l§kIII§r\n" . $list);

			}

		}
		else
		{

			foreach(Elemental::getInstance()->getServer()->getLevelByName("koth")->getPlayers() as $player)
			{

				$player->removeFloatingText("KoTH");

			}

			Elemental::getInstance()->getScheduler()->cancelTask($this->getTaskId());

		}

	}

}