<?php

namespace core\koth\tasks;

use core\Elemental;
use core\ElementalPlayer;
use core\koth\Koth;
use core\koth\KothManager;
use core\translation\Translation;
use pocketmine\item\Item;
use pocketmine\scheduler\Task;
use pocketmine\level\Position;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class KothCaptureTask extends Task
{

	private $player;


	private $taskId;

	private $core;

	private $kothManager;

	private $progress = 0;

	public function __construct(ElementalPlayer $player)
	{

		$this->player = $player;

		$this->core = Elemental::getInstance();

		$this->kothManager = $this->core->getKothManager();

		$this->taskId = $this->getTaskId();

	}

	public function onRun(int $tick)
	{

		if(!$this->kothManager->isCaptured() && $this->kothManager->isRunning() && $this->player->isCapturingKoth())
		{

			$this->progress++;

			$this->player->setKothCaptureProgress($this->progress);

			$this->player->sendPopup("§b§lKOTH§r§8: §r" . TextFormat::RED . $this->progress);

			if($this->progress == 100)
			{

				$this->core->getServer()->broadcastMessage("\n§b§lAstral §r§8| §r§e{$this->player->getName()} §r§7has captured the §bKoTH §r§7and has been rewarded 500 Faction Power, KoTH Loot bag, 500,000 in cash and more!\n\n");

				if($this->player->getFaction() == null)
				{

					// DO NOTHING

				}
				else
				{

					$this->player->getFaction()->addStrength(500);

				}

				$this->player->addToBalance(500000);

				$this->kothManager->unsetCaptures($this->player->getName());

				$this->kothManager->setRunning(false);

				$this->player->teleport($this->core->getServer()->getDefaultLevel()->getSafeSpawn());


				$this->core->getScheduler()->cancelTask($this->getTaskId());

				return;

			}

		}
		else
		{

			$this->core->getScheduler()->cancelTask($this->getTaskId());

			return;

		}

	}

}
