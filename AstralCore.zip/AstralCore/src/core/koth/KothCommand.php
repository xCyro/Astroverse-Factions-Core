<?php

namespace core\koth;

use core\koth\KothManager;
use core\koth\tasks\KothTicker;
use core\command\utils\Command;
use core\Elemental;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AnimatePacket;
use pocketmine\utils\TextFormat;
use core\command\task\TeleportTask;
use pocketmine\level\Position;
use pocketmine\Server;
use pocketmine\level\Level;

use function PHPSTORM_META\elementType;

class KothCommand extends Command
{

	public function __construct()
	{

		parent::__construct('koth', 'Koth Command', '', ['kt']);

	}

	public function execute(CommandSender $sender, string $label, array $args): void
	{

		$kothManager = Elemental::getInstance()->getKothManager();

		if(!$args)
		{

			if(!$sender instanceof ElementalPlayer)
			{

				return;

			}

			$level = Elemental::getInstance()->getServer()->getLevelByName("koth");

			$position = $level->getSpawnLocation();

			Elemental::getInstance()->getScheduler()->scheduleRepeatingTask(new TeleportTask($sender, $position, 15), 20);

			return;

		}

		if($args[0] == "start")
		{

			if($sender->isOp(true))
			{

				if($kothManager->isRunning())
				{

					$sender->sendMessage("§b§lAstral §r§8| §r§7There is already an on-going KoTH Event!");

					return;

				}

				Elemental::getInstance()->getServer()->broadcastMessage("\n§b§lAstral §r§8| §r§7The KoTH Event has been started by §e" . $sender->getName() . "§r§7!\n\n");

				$kothManager->setRunning(true);
				$kothManager->setCaptured(false);

				Elemental::getInstance()->getScheduler()->scheduleRepeatingTask(new KothTicker(), 100);

				return;

			}
			else
			{

				$sender->sendMessage(Translation::getMessage("noPermission"));

				return;

			}

		}

		if($args[0] == "end")
		{

			if($sender->isOp(true))
			{

				if(!$kothManager->isRunning())
				{

					$sender->sendMessage("§b§lAstral §r§8| §r§7There is currently no on-going KoTH Event!");

					return;

				}

				Elemental::getInstance()->getServer()->broadcastMessage("\n§b§lAstral §r§8| §r§7The KoTH Event has been ended by §e" . $sender->getName() . "§r§7!\n\n");


				$kothManager->setRunning(false);
				$kothManager->setCaptured(false);

				return;

			}
			else
			{

				$sender->sendMessage(Translation::getMessage("noPermission"));

				return;

			}

		}

	}

}