<?php

namespace core\koth;

class Koth
{

}
