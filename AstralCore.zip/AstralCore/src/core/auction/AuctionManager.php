<?php
namespace core\auction;

use core\Elemental;

class AuctionManager
{

    /**
     * @var Elemental
     */
    private $core;

    public function __construct(Elemental $core)
    {
        $this->core = $core;
    }

}