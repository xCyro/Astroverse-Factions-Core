<?php

declare(strict_types = 1);

namespace core\mask\masks;

use core\utils\Utils;
use pocketmine\entity\Effect;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class ZombieMask extends MaskAPI{

    /**
     * @return string
     */
    public function getName(): string{
        return "Zombie Mask";
    }

    /**
     * @return int
     */
    public function getDamage(): int{
        return 2;
    }

    /**
     * @return array
     */
    public function getLore(): array{
        return [
            TextFormat::BOLD . TextFormat::GREEN . "\nRARITY",
            TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Rare",
            "",
            TextFormat::BOLD . TextFormat::GREEN . "ABILITY",
            "§r§fEat their flesh and become one!",
            "",
            TextFormat::BOLD . TextFormat::GREEN . "EFFECTS",
            TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Speed IV",
            TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Haste II",
			TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Health Boost III",
			TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Night Vision II",
			TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Feel nauseated and drowsy all the time",
        ];
    }

    /**
     * @param int $currentTick
     */
    public function tick(int $currentTick): void{
        foreach(Server::getInstance()->getOnlinePlayers() as $p){
            if($this->hasMask($p)){
                Utils::addEffect($p, Effect::SPEED, 6, 3);
                Utils::addEffect($p, Effect::HASTE, 6, 1);
                Utils::addEffect($p, Effect::NAUSEA, 6);
                Utils::addEffect($p, Effect::NIGHT_VISION, 15);
				Utils::addEffect($p, Effect::HEALTH_BOOST, 6, 3);
				Utils::addEffect($p, Effect::MINING_FATIGUE, 6, 1);
				Utils::addEffect($p, Effect::SLOWNESS, 6, 1);
            }
        }
    }
}