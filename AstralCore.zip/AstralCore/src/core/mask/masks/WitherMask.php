<?php

declare(strict_types = 1);

namespace core\mask\masks;

use core\utils\Utils;
use pocketmine\entity\Effect;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class WitherMask extends MaskAPI{

    /**
     * @return string
     */
    public function getName(): string{
        return "Wither Mask";
    }

    /**
     * @return int
     */
    public function getDamage(): int{
        return 1;
    }

    /**
     * @return array
     */
    public function getLore(): array{
        return [
            TextFormat::BOLD . TextFormat::GREEN . "\nRARITY",
            TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "LEGENDARY",
            "",
            TextFormat::BOLD . TextFormat::GREEN . "ABILITY",
            "§r§fFight them like It's nothing!",
            "",
            TextFormat::BOLD . TextFormat::GREEN . "EFFECTS",
            TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Strength III",
			TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Speed IV",
			TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Night Vision II",
			TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Health boost II",
        ];
    }

    /**
     * @param int $currentTick
     */
    public function tick(int $currentTick): void{
        foreach(Server::getInstance()->getOnlinePlayers() as $p){
            if($this->hasMask($p)){
				Utils::addEffect($p, Effect::STRENGTH, 6, 2);
				Utils::addEffect($p, Effect::SPEED, 6, 3);
				Utils::addEffect($p, Effect::NIGHT_VISION, 15, 1);
                Utils::addEffect($p, Effect::HEALTH_BOOST, 6, 1);
            }
        }
    }
}