<?php

declare(strict_types = 1);

namespace core\mask\masks;

use core\ElementalPlayer;
use core\utils\Utils;
use pocketmine\entity\Effect;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class DragonMask extends MaskAPI{

    /**
     * @return string
     */
    public function getName(): string{
        return "Dragon Mask";
    }

    /**
     * @return int
     */
    public function getDamage(): int{
        return 5;
    }

    /**
     * @return array
     */
    public function getLore(): array{
        return [
            TextFormat::BOLD . TextFormat::GREEN . "\nRARITY",
            TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Legendary",
            "",
            TextFormat::BOLD . TextFormat::GREEN . "ABILITY",
            "§r§fGain many effects and gain the ability to fly!",
            "",
            TextFormat::BOLD . TextFormat::GREEN . "EFFECTS",
			TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Speed V",
			TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Strength I",
			TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Regeneration I",
			TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Night Vision II",
			TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Fire Resistance II",
			TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "Resistance I",
			TextFormat::BOLD . TextFormat::GREEN . " * " . TextFormat::RESET . "HealthBoost II",
        ];
    }

    /**
     * @param int $currentTick
     */
    public function tick(int $currentTick): void{
        foreach(Server::getInstance()->getOnlinePlayers() as $p){
            if($this->hasMask($p)){
                if($p instanceof ElementalPlayer){
                    if($p->getAllowFlight() == false and !$p->isTagged()){
                        $p->setAllowFlight(true);
                    }
				}
				Utils::addEffect($p, Effect::SPEED, 6, 4);
				Utils::addEffect($p, Effect::STRENGTH, 6, 0);
				Utils::addEffect($p, Effect::REGENERATION, 6, 0);
				Utils::addEffect($p, Effect::NIGHT_VISION, 15, 2);
				Utils::addEffect($p, Effect::FIRE_RESISTANCE, 6, 1);
				Utils::addEffect($p, Effect::RESISTANCE, 6, 0);
				Utils::addEffect($p, Effect::HEALTH_BOOST, 6, 2);
            }
        }
    }
}
