<?php

namespace core\task;

use core\discord\DiscordManager;
use core\Elemental;
use Error;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class ServerStatusTask extends Task
{

    /** @var int */
    protected $time = 300; // 5 minutes.

    /**
     * @param int $currentTick
     */
    public function onRun(int $currentTick)
    {
        if (($this->time % 300) == 0) {

			$server = Elemental::getInstance();

			$time = ($this->time >= 60) ? floor(($this->time / 60) % 60) . " minutes" : $this->time . " seconds";

			$webhook = "776164173516242954/9oWoj5syw1IRE92SREaARk-e7zMvBSGm1yIAflkq5unBCf20ZB1D9s6N8hTR9gNi0Frc";

			$serverAddress = "play.astralmc.tk:19132";

			// Check if server is ONLINE or OFFLINE

			$status = "ONLINE";
			$whitelist = "OFF";
			$onlinePlayers = "ERROR";
			$maximumPlayers = "ERROR";
			$version = "ERROR";
			$tps = "ERROR";

			//try {
				//if(array_key_exists("connected", json_decode(file_get_contents("https://b.mcpe.me/" . $serverAddress . "/json"), true))) {
					//$status = "ONLINE";
				//} else {
					//$status = "OFFLINE";
				//}
			//} finally {
			//}

			//if($server->getServer()->hasWhitelist()) {
				//$whitelist = "On";
			//} else {
				//$whitelist = "Off";
			//}

			$onlinePlayers = count($server->getServer()->getOnlinePlayers());
			$maximumPlayers = $server->getServer()->getMaxPlayers();
			$version = $server->getServer()->getVersion();
			$tps = $server->getServer()->getTicksPerSecond();

			DiscordManager::postWebhook($webhook, "", "Astrobaut", [
				[
					"color" => 0x00ffff,
					"title" => "Astroverse Status",
					"description" => "__**OP Factions**__\n\n**Status**: $status\n**Whitelist**: $whitelist\n**Players**: $onlinePlayers/$maximumPlayers\n**Version**: $version\n**TPS**: $tps\n\n__**PRACTICE**__\n\n**Status**: $status\n**Whitelist**: $whitelist\n**Players**: 0/$maximumPlayers\n**Version**: $version\n**TPS**: $tps\n\nThere is a total of **$onlinePlayers** players across the entire network."
				]
			]);

        }
        if ($this->time <= 0) {
            $this->time = 300;
        } else {
            --$this->time;
        }
    }
}
