<?php

namespace core\discord;

use core\discord\task\DiscordPost;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class DiscordManager{

    /**
     * @param string $url
     * @param string $content
     * @param string $username
     * @param array $embed
     */
    public static function postWebhook(string $url, string $content, string $username, array $embed = []): void{
        $data = [
            "username" => $username,
            "content" => $content
        ];
        if(!empty($embed)){
            $data["embeds"] = $embed;
            unset($data["content"]);
        }else{
            $msg = $data["content"];
            $msg = str_replace("@everyone", "(@)everyone", $msg);
            $msg = str_replace("@here", "(@)here", $msg);
            $data["content"] = $msg;
        }
        $con = json_encode($data);
        $post = new DiscordPost("https://discordapp.com/api/webhooks/" . $url, $con);
        Server::getInstance()->getAsyncPool()->submitTask($post);
    }

    /**
     * @param string $sender
     * @param string $player
     * @param string $type
     * @param array $details
     * @param string $reason
     */
    public static function sendPunishment(string $sender, string $player, string $type, array $details = [], string $reason = "None", $expiration = "Permanent"): void {
        $webhook = "776362878831558677/im5UGTfbg58P_MzWvCtWO3X_CNFIm0JbJg6na8ghzvRzQwqNIaKhTKn3X72TY9i9M9hF";
        $punishment = "**Player:** " . $player;
        $punishment .= "\n**Issuer**: " . $sender;
		$punishment .= "\n**Reason**: " . $reason;
		$punishment .= "\n**Expiration**: " . $expiration;

		//if($type == "Temporary Ban" || $type = "Temporary Mute") {
			//$punishment .= "\n**Expiration**: " . $expiration;
		//}

		$punishment .= "\n\nAppeal by making a ticket!\n**Server** - OP Factions";

        foreach($details as $string){
            $punishment .= TextFormat::EOL . $string;
        }
        DiscordManager::postWebhook($webhook, "", $player . "'s Punishment", [
            [
                "color" => 0xFF0004,
                "title" => "Punishment: " . $type,
                "description" => $punishment
            ]
        ]);
    }
}