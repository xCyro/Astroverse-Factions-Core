<?php

declare(strict_types = 1);

namespace core\watchdog;

use core\Elemental;
use core\ElementalPlayer;
use core\translation\Translation;
use core\translation\TranslationException;
use core\watchdog\task\ProxyCheckTask;
use core\libs\muqsit\invmenu\InvMenu;
use core\rank\Rank;
use pocketmine\entity\object\PrimedTNT;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\cheat\PlayerCheatEvent;
use pocketmine\event\player\cheat\PlayerIllegalMoveEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\InventoryTransactionPacket;
use pocketmine\block\Block;
use pocketmine\plugin\PluginBase;
use pocketmine\network\mcpe\protocol\AdventureSettingsPacket;
use pocketmine\network\mcpe\protocol\UpdateAttributesPacket;
use pocketmine\utils\TextFormat as TF;
use pocketmine\item\Item;
use pocketmine\entity\Entity;
use pocketmine\Player;
use pocketmine\tile\Container;
use pocketmine\utils\TextFormat;

class WatchdogListener implements Listener {

    /** @var Elemental */
    private $core;

    /** @var string[] */
    private $keys = [
      // Asterna why u not using my proxy keys where i created 5 accounts with my email ;-; 
      // Love Turnaizy
    ];

    /** @var int */
    private $count = 0;

    /** @var int */
	private $autoClickTime = 0;
	
	    /** @var array */
		public $point = array();
		/** @var array */
		public $surroundings = array();
		/** @var array */
		public $fly = array();

    /**
     * WatchdogListener constructor.
     *
     * @param Elemental $core
     */
    public function __construct(Elemental $core) {
        $this->core = $core;
    }

    /**
     * @priority LOWEST
     * @param PlayerJoinEvent $event
     */
    public function onPlayerJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        if(!$player instanceof ElementalPlayer) {
            return;
        }
       /*$ipAddress = $player->getAddress();
        $uuid = $player->getRawUniqueId();
        $stmt = $this->core->getMySQLProvider()->getDatabase()->prepare("SELECT riskLevel FROM ipAddress WHERE ipAddress = ? AND uuid = ?");
        $stmt->bind_param("ss", $ipAddress, $uuid);
        $stmt->execute();
        $stmt->bind_result($result);
        $stmt->fetch();
        $stmt->close();
        if($result === null) {
            ++$this->count;
            if($this->count > count($this->keys) - 1) {
                $this->count = 0;
            }
            $key = $this->keys[$this->count++];
            $this->core->getServer()->getAsyncPool()->submitTaskToWorker(new ProxyCheckTask($player->getName(), $ipAddress, $key), 0);
            return;
        }
        if($result === 1) {
            $player->close(null, TextFormat::RED . "A malicious ip swapper was detected!");
            return;
            */
    }

    /**
     * @priority NORMAL
     * @param PlayerQuitEvent $event
     */
    public function onPlayerQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        if(!$player instanceof ElementalPlayer) {
            return;
        }
        if($player->isImmobile()) {
            $name = $player->getName();
            $reason = "Leaving while being frozen";
            $time = "3d"; // 14 days // 129200
            $this->core->getServer()->dispatchCommand(new ConsoleCommandSender(), "tban $name $time $reason");
        }
    }

    /**
     * @priority LOWEST
     * @param PlayerCommandPreprocessEvent $event
     *
     * @throws TranslationException
     */
    public function onPlayerCommandPreprocess(PlayerCommandPreprocessEvent $event): void {
        $player = $event->getPlayer();
        if(!$player instanceof ElementalPlayer) {
            return;
        }
        if($player->isImmobile()) {
            $message = $event->getMessage();
            $value = false;
            $commands = ["/msg", "/w", "/tell", "/whisper", "/message", "/pm", "/m", "/spawn", "/pvp", "/boss", "/warp", "/warps", "f", "/f home", "/f warp", "/f warps"];
            foreach($commands as $command) {
                if(strpos($message, $command) !== false) {
                    $value = true;
                }
            }
            if($value === true) {
                $player->sendMessage(Translation::getMessage("frozen", [
                    "name" => "You are"
                ]));
            }
        }
    }

    /**
     * @priority HIGH
     * @param PlayerInteractEvent $event
     */
    public function onPlayerInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        if(!$player instanceof ElementalPlayer) {
            return;
        }
        if($player->hasVanished()) {
            $container = $event->getBlock()->getLevel()->getTile($event->getBlock());
            if($container instanceof Container) {
                $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
                $menu->readonly();
                $menu->getInventory($player)->setContents($container->getInventory()->getContents());
                $menu->setName($container->getInventory()->getName());
                $menu->send($player);
            }
            $event->setCancelled();
        }
    }

    /**
     * @priority LOWEST
     * @param EntityDamageEvent $event
     *
     * @throws TranslationException
     */
    public function onEntityDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();
        if(!$entity instanceof ElementalPlayer) {
            return;
        }
        if($entity->hasVanished()) {
            $event->setCancelled();
		}
        if($entity->isImmobile()) {
            $event->setCancelled();
            $entity->sendMessage(Translation::getMessage("frozen", [
                "name" => "You are"
            ]));
            if($event instanceof EntityDamageByEntityEvent) {
                $damager = $event->getDamager();
                if(!$damager instanceof ElementalPlayer) {
                    return;
                }
                $damager->sendMessage(Translation::getMessage("frozen", [
                    "name" => $entity->getName() . " is"
                ]));
            }
		}

		//if($event instanceof EntityDamageByEntityEvent) {

			//$damager = $event->getDamager();

			//if(!$damager instanceof ElementalPlayer) {

				//return;

			//}

		//}

	}
	
	// WATCHDOG ANTICHEAT DETECTIONS!

	public function GetSurroundingBlocks(ElementalPlayer $player){
		$level       = $player->getLevel();

		$posX        = $player->getX();
		$posY        = $player->getY();
		$posZ        = $player->getZ();    

		$pos1        = new Vector3($posX  , $posY, $posZ  );
		$pos2        = new Vector3($posX-1, $posY, $posZ  );
		$pos3        = new Vector3($posX-1, $posY, $posZ-1);
		$pos4        = new Vector3($posX  , $posY, $posZ-1);
		$pos5        = new Vector3($posX+1, $posY, $posZ  );
		$pos6        = new Vector3($posX+1, $posY, $posZ+1);
		$pos7        = new Vector3($posX  , $posY, $posZ+1);
		$pos8        = new Vector3($posX+1, $posY, $posZ-1);
		$pos9        = new Vector3($posX-1, $posY, $posZ+1);

		$bpos1       = $level->getBlock($pos1)->getId();
		$bpos2       = $level->getBlock($pos2)->getId();
		$bpos3       = $level->getBlock($pos3)->getId();
		$bpos4       = $level->getBlock($pos4)->getId();
		$bpos5       = $level->getBlock($pos5)->getId();
		$bpos6       = $level->getBlock($pos6)->getId();
		$bpos7       = $level->getBlock($pos7)->getId();
		$bpos8       = $level->getBlock($pos8)->getId();
		$bpos9       = $level->getBlock($pos9)->getId();

		$this->surroundings = array ($bpos1, $bpos2, $bpos3, $bpos4, $bpos5, $bpos6, $bpos7, $bpos8, $bpos9);    
	}

	public function CheckFly($event){
		$player = $event->getPlayer();
		$oldPos = $event->getFrom();
		$newPos = $event->getTo();
		if(!$player->isCreative() and !$player->isSpectator() and !$player->getAllowFlight()){
			if ($oldPos->getY() <= $newPos->getY()){
				if($player->GetInAirTicks() > 350){
				   $maxY = $player->getLevel()->getHighestBlockAt(((int) $newPos->getX()), ((int) $oldPos->getZ()));
				   if($newPos->getY() - 2 > $maxY){
					   $this->point[$player->getName()]["fly"] += (float) 1;
					   if((float) $this->point[$player->getName()]["fly"] > (float) 3){
						   foreach(Elemental::getInstance()->getServer()->getOnlinePlayers() as $onlinePlayers) {
							   if($onlinePlayers->getRank()->getIdentifier() >= Rank::TRAINEE){
								   $onlinePlayers->sendMessage("§8(§4§lWATCHDOG§r§8) §r§b" . $player->getName() . " §r§chas been detected for high jump and bhop! §8(§c§lLVL:6§r§8)");
							   }
						   }
					   }
				   }
				}
			}else{
				$this->point[$player->getName()]["fly"] = (float) 0;
			}
		}
	}

	public function CheckNoClip($event){
		$player = $event->getPlayer();
		$level = $player->getLevel();
		$pos = new Vector3($player->getX(), $player->getY(), $player->getZ());
		$BlockID = $level->getBlock($pos)->getId();
		
		 if (
		 //BUILDING MATERIAL
		$BlockID == 1
		or $BlockID == 2
		or $BlockID == 3
		or $BlockID == 4
		or $BlockID == 5
		or $BlockID == 7
		or $BlockID == 17
		or $BlockID == 18
		or $BlockID == 20
		or $BlockID == 43
		or $BlockID == 45
		or $BlockID == 47
		or $BlockID == 48
		or $BlockID == 49
	    or $BlockID == 79
		or $BlockID == 80
		or $BlockID == 87
		or $BlockID == 89
		or $BlockID == 97
		or $BlockID == 98
		or $BlockID == 110
		or $BlockID == 112
		or $BlockID == 121
		or $BlockID == 155
		or $BlockID == 159
		or $BlockID == 161
		or $BlockID == 162
		or $BlockID == 170
		or $BlockID == 172
		or $BlockID == 174
		or $BlockID == 243
		 //ORES TODO 
		 or $BlockID == 14
		 or $BlockID == 15
		 or $BlockID == 16
		 or $BlockID == 21
		 or $BlockID == 56
		 or $BlockID == 73
		 or $BlockID == 129
		 ){
			 ////if(    !in_array(Block::SLAB                , $this->surroundings ) 
				/////and !in_array(Block::WOOD_STAIRS         , $this->surroundings )
				////and !in_array(Block::COBBLE_STAIRS       , $this->surroundings )
				//and !in_array(Block::BRICK_STAIRS        , $this->surroundings )
				//and !in_array(Block::STONE_BRICK_STAIRS  , $this->surroundings )
				//and !in_array(Block::NETHER_BRICKS_STAIRS, $this->surroundings )
				//and !in_array(Block::SPRUCE_WOOD_STAIRS  , $this->surroundings )
				//and !in_array(Block::BIRCH_WOODEN_STAIRS , $this->surroundings )
				//and !in_array(Block::JUNGLE_WOOD_STAIRS  , $this->surroundings )
				//and !in_array(Block::QUARTZ_STAIRS       , $this->surroundings )
				////and !in_array(Block::WOOD_SLAB           , $this->surroundings )
				//and !in_array(Block::ACACIA_WOOD_STAIRS  , $this->surroundings )
				//and !in_array(Block::DARK_OAK_WOOD_STAIRS, $this->surroundings )
				////and !in_array(Block::SNOW                , $this->surroundings )){  
				   
				   $this->point[$player->getName()]["noclip"] += (float) 1;
				   if((float) $this->point[$player->getName()]["noclip"] > (float) 250){
						$event->setCancelled(); 
						foreach(Elemental::getInstance()->getServer()->getOnlinePlayers() as $onlinePlayers) {
							if($onlinePlayers->getRank()->getIdentifier() >= Rank::TRAINEE) {
								$onlinePlayers->sendMessage("§8(§4§lWATCHDOG§r§8) §r§b" . $player->getName() . " §r§chas been detected for noclip! §8(§c§lLVL:5§r§8)");
							}
						}
				   }
			 //}else{
				 //$this->point[$player->getName()]["noclip"] = (float) 0;
			 //}
		}else{
		   $this->point[$player->getName()]["noclip"] = (float) 0;
		}
	 }

    /**
     * @priority NORMAL
     * @param DataPacketReceiveEvent $event
     *
     * @throws TranslationException
     */
    public function antiAutoClicker(DataPacketReceiveEvent $event): void {
        $packet = $event->getPacket();
        $player = $event->getPlayer();
        if(!$player instanceof ElementalPlayer) {
            return;
		}

        //if($packet instanceof InventoryTransactionPacket) {
            //if($packet->transactionType === InventoryTransactionPacket::TYPE_USE_ITEM_ON_ENTITY) {
                //++$player->cps;
                //if($this->autoClickTime !== time()) {
                    //$multiplier = $this->autoClickTime - time();
                    //if($multiplier >= 1) {
                        //foreach($this->core->getServer()->getOnlinePlayers() as $player) {
                            //if($player instanceof ElementalPlayer) {
                                //if($player->cps > (30 * $multiplier)) {
                                    //$cps = floor($player->cps / $multiplier);
                                    //$this->core->getServer()->broadcastMessage(Translation::getMessage("kickBroadcast", [
                                        //"name" => $player->getName(),
                                        //"effector" => "Watchdog",
                                        //"reason" => "Auto-clicking. CPS: $cps"
                                    //]));
                                    //$player->close(null, Translation::getMessage("kickMessage", [
                                        //"name" => "Watchdog",
                                        //"reason" => "Auto-clicking. CPS: $cps"
                                    //]));
                                //}
                                //$player->cps = 0;
                            //}
                        //}
                        //$this->autoClickTime = time();
                    //}
                //}
            //}
		//}

		if($packet instanceof InventoryTransactionPacket) {
			//$player->sendMessage("1");
			if($packet->transactionType === InventoryTransactionPacket::TYPE_USE_ITEM_ON_ENTITY) {
				//$player->sendMessage("2");
				++$player->cps;
				if($this->autoClickTime !== time()) {
					//$player->sendMessage("3");
					if($player->cps >= 1000) {
						foreach(Elemental::getInstance()->getServer()->getOnlinePlayers() as $onlinePlayers) {
							if($onlinePlayers->getRank()->getIdentifier() >= Rank::TRAINEE) {
								$onlinePlayers->sendMessage("§8(§4§lWATCHDOG§r§8) §r§b" . $player->getName() . " §r§chas been detected for auto-clicking or double clicking! §8(§c§lLVL:2§r§8)");
								$player->cps = 0;
							}
						}
					}
				}
			}
		}

	}

	public function antiReachHacks(EntityDamageEvent $event) {
		$entity = $event->getEntity();

		if($entity instanceof PrimedTNT) {
			return;
		}

		if($event instanceof EntityDamageByEntityEvent and $entity instanceof ElementalPlayer) {
			$damager = $event->getDamager();
			if($damager instanceof ElementalPlayer) {
				if($damager->getGamemode() == ElementalPlayer::CREATIVE or $damager->getGamemode() == ElementalPlayer::SPECTATOR){
					return;
				}
			}

			if($entity == null || $entity === null || $damager == null || $damager === null) {
				return;
			}

			if($entity instanceof ElementalPlayer){

				if($damager instanceof ElementalPlayer){

					$distance = $damager->distance($entity);

					$maxDistance = 8;

					if($distance > $maxDistance) {

						foreach(Elemental::getInstance()->getServer()->getOnlinePlayers() as $onlinePlayers) {
							if($onlinePlayers->getRank()->getIdentifier() >= Rank::TRAINEE) {
								$onlinePlayers->sendMessage("§8(§4§lWATCHDOG§r§8) §r§b" . $damager->getName() . " §r§chas been detected for reach or hitbox! §8(§c§lLVL:8§r§8)");
							}
						}

					}
				}
			}

		}
	}

	public function antiCheatChecksOnJoin(PlayerJoinEvent $event) {
		$player = $event->getPlayer();
	}

	public function onPlayerPMMPCheat(PlayerCheatEvent $event) {

		$player = $event->getPlayer();

		foreach(Elemental::getInstance()->getServer()->getOnlinePlayers() as $onlinePlayers) {
			if($onlinePlayers->getRank()->getIdentifier() >= Rank::TRAINEE) {

				$onlinePlayers->sendMessage("§8(§4§lWATCHDOG§r§8) §r§b" . $player->getName() . " §r§chas been detected for cheating by the Server AntiCheat! §8(§c§lLVL:1§r§8)");

			}
		}

	}

	public function onPlayerIllegalMoveEventPMMP(PlayerIllegalMoveEvent $event) {

		$player = $event->getPlayer();
		$originalPosition = $event->getOriginalPosition();
		$expectedPosition = $event->getAttemptedPosition();
		$attemptedPosition = $event->getAttemptedPosition();

		foreach(Elemental::getInstance()->getServer()->getOnlinePlayers() as $onlinePlayers) {
			if($onlinePlayers->getRank()->getIdentifier() >= Rank::TRAINEE) {

				$onlinePlayers->sendMessage("§8§l(§4§lWATCHDOG§r§8) §r§b" . $player->getName() . " §r§chas been detected for illegal movement by the Server AntiCheat! §8(§c§lLVL:1§r§8)");

			}
		}

	}

	public function antiCheatMovementChecks(PlayerMoveEvent $event) {
		$player = $event->getPlayer();
		$this->CheckFly($event);
		$this->checkNoClip($event);
	}

}
