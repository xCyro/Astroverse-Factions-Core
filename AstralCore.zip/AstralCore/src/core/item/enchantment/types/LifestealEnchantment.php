<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;

class LifestealEnchantment extends Enchantment {

    /**
     * LifestealEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::LIFESTEAL, "Lifesteal", self::RARITY_MYTHIC, "Has a chance to regain lots of health but chance to get weakness at the same time.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }
            $random = mt_rand(1, 350);
			$chance = $level * 2;
            if($chance >= $random) {
				$randomHeal = mt_rand(1, 2);
				$randomDamage = mt_rand(1, 2);
				$enchant = "null";

				if($level == 1){
					$randomDamage = mt_rand(1, 2);
					$randomHeal = mt_rand(2, 3);
					$enchant = "§eLifesteal§r";
				}
				if($level == 2){
					$randomDamage = mt_rand(1, 3);
					$randomHeal = mt_rand(2, 4);
					$enchant = "§9Lifesteal§r";
				}
				if($level == 3){
					$randomDamage = mt_rand(2, 3);
					$randomHeal = mt_rand(2, 5);
					$enchant = "§6Lifesteal§r";
				}
				if($level == 4){
					$randomDamage = 3;
					$randomHeal = mt_rand(4, 6);
					$enchant = "§cLifesteal§r";
				}
				if($level == 5){
					$randomDamage = mt_rand(4, 5);
					$randomHeal = mt_rand(5, 7);
					$enchant = "§4Lifesteal§r";
				}

				$entity->setHealth($entity->getHealth() - $randomDamage);
                $damager->setHealth($damager->getHealth() + $randomHeal);
				$damager->addEffect(new EffectInstance(Effect::getEffect(Effect::WEAKNESS), 5 * 20, 1));
				$damager->addEffect(new EffectInstance(Effect::getEffect(Effect::WITHER), 2 * 20, 1));
                $damager->sendMessage($enchant . " §r§7has Activated!");
            }
        };
    }
}