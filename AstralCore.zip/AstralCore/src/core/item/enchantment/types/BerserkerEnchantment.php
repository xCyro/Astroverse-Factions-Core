<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;

class BerserkerEnchantment extends Enchantment {

    /**
     * BerserkerEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::BERSERKER, "Berserker", self::RARITY_UNCOMMON, "Has a 20 percent chance when under 5 hearts to heal a certain amount and can heal more depending on the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }
            $random = mt_rand(1, 100);
            $chance = 20;
            if($chance >= $random) {
				$randomHeal = mt_rand(2, 4);
				$enchant = "null";
				if($level == 1){
					$randomHeal = mt_rand(4, 8);
					$enchant = "§eBerserker§r";
				}
				if($level == 2){
					$randomHeal = mt_rand(8, 12);
					$enchant = "§9Berserker§r";
				}
				if($level == 3){
					$randomHeal = mt_rand(12, 16);
					$enchant = "§6Berserker§r";
				}
				if($level == 4){
					$randomHeal = mt_rand(16, 18);
					$enchant = "§cBerserker§r";
				}
				if($level == 5){
					$randomHeal = mt_rand(18, 20);
					$enchant = "§4Berserker§r";
				}
				if($damager->getHealth() <= 5){
					$damager->setHealth($entity->getHealth() + $randomHeal);
					$damager->sendMessage($enchant . " §r§7has Activated!" . " §r§a+§2$randomHeal §ahealth§r");
				}
            }
        };
    }
}