<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\item\types\Head;
use core\item\ItemListener;
use core\item\ItemManager;
use core\item\CustomItem;
use core\ElementalPlayer;
use core\Elemental;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class GuillotineEnchantment extends Enchantment {

    /**
     * GuillotineEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::GUILLOTINE, "HeadBanger", self::RARITY_MYTHIC, "Have a chance to obtain your opponent's head and have a higher chance to do so depending on the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$damager instanceof ElementalPlayer) or (!$entity instanceof ElementalPlayer)) {
                return;
            }
            if($event->getFinalDamage() < $entity->getHealth()) {
                return;
            }
            $random = mt_rand(1, 5);
            if($level >= $random) {
                //$head = Item::get(Item::SKULL, mt_rand(50, 100), 1);
                //$head->setCustomName(TextFormat::AQUA . $entity->getName() . "'s head");
                //$head->setLore([TextFormat::GRAY . "\nSell this head to get 10% of your opponent's balance!\n"]);
                //$nbt = $head->getNamedTag();
                //$nbt->setString("head", $entity->getNameTag());
                //$nbt->setString("type", "human";
				//$head->setNamedTag($nbt);
				$head = new Head($entity);
                $damager->getInventory()->addItem($head);
            }
        };
    }
}