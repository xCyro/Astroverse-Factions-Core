<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;

class RageEnchantment extends Enchantment {

    /**
     * RageEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::RAGE, "Rage", self::RARITY_MYTHIC, "Has a chance to do more damage in combat and can have a higher chance and more damage depending on the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }
            $random = mt_rand(1, 450);
            $chance = $level * 2;
            if($chance >= $random) {
				$randomDamage = 1;
				$enchant = "§cRage";
				if($level == 1){
					$randomDamage = mt_rand(1, 5);
					$enchant = "§eRage§r";
				}
				if($level == 2){
					$randomDamage = mt_rand(2, 5);
					$enchant = "§9Rage§r";
				}
				if($level == 3){
					$randomDamage = mt_rand(3, 5);
					$enchant = "§6Rage§r";
				}
				if($level == 4){
					$randomDamage = mt_rand(4, 5);
					$enchant = "§cRage§r";
				}
				if($level == 5){
					$randomDamage = 5;
					$enchant = "§4Rage§r";
				}
				$entity->setHealth($entity->getHealth() - $randomDamage);
                $damager->sendMessage($enchant . " §r§7has Activated!");
            }
        };
    }
}