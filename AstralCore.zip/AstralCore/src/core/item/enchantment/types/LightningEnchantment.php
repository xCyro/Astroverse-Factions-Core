<?php



namespace core\item\enchantment\types;



use core\item\enchantment\Enchantment;

use core\ElementalPlayer;

use core\Elemental;

use core\translation\Translation;

use pocketmine\block\Block;

use pocketmine\entity\Entity;

use pocketmine\Server;

use pocketmine\entity\EntityIds;

use pocketmine\level\Position;

use pocketmine\network\mcpe\protocol\AddActorPacket;

use pocketmine\event\entity\EntityDamageByEntityEvent;



class LightningEnchantment extends Enchantment {



    /**

     * LightningEnchantment constructor.

     */

    public function __construct() {

        parent::__construct(self::LIGHTNING, "Lightning", self::RARITY_MYTHIC, "Has a chance to strike your opponent with lightning dealing a total of 3 hearts of damage and can have a higher chance of doing so depending on the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 5);

        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {

            $entity = $event->getEntity();
            $damager = $event->getDamager();

            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }

            $random = mt_rand(1, 100);
            $chance = $level * 1.8;

            if($chance >= $random) {

				$damage = 3;
				$enchant = "null";

				if($level == 1)
				{
					$enchant = "§eLightning§r";
				}
				if($level == 2)
				{
					$enchant = "§9Lightning§r";
				}
				if($level == 3)
				{
					$enchant = "§6Lightning§r";
				}
				if($level == 4)
				{
					$enchant = "§cLightning§r";
				}
				if($level == 5)
				{
					$enchant = "§4Lightning§r";
				}
				$entity->setHealth($entity->getHealth() - $damage);
				$pk = new AddActorPacket();
            	$pk->type = AddActorPacket::LEGACY_ID_MAP_BC[EntityIds::LIGHTNING_BOLT];
            	$pk->entityRuntimeId = Entity::$entityCount++;
            	$pk->position = $entity->add(0, 1);
            	$pk->yaw = 0;
            	$pk->pitch = 0;
				$entity->sendDataPacket($pk);

				foreach($damager->getServer()->getOnlinePlayers() as $players){

					$players->sendDataPacket($pk);

				}
                $damager->sendMessage($enchant . " §r§7has Activated!");

            }

        };

    }

}