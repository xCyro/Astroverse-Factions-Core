<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\entity\{Effect, EffectInstance};

class LustEnchantment extends Enchantment {

    /**
     * RageEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::LUST, "Lust", self::RARITY_COMMON, "Has a chance to take away maximum -10 food bars from your opponent and can have a higher chance and more food depending on the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }
            $random = mt_rand(1, 300);
            $chance = $level * 2.5;
            if($chance >= $random) {
				$randomDamage = 1;
				$enchant = "null";
				if($level == 1){
					$randomDamage = 4;
					$enchant = "§eLust§r";
				}
				if($level == 2){
					$randomDamage = 8;
					$enchant = "§9Lust§r";
				}
				if($level == 3){
					$randomDamage = 10;
					$enchant = "§6Lust§r";
				}
				if($level == 4){
					$randomDamage = 12;
					$enchant = "§cLust§r";
				}
				if($level == 5){
					$randomDamage = 16;
					$enchant = "§4Lust§r";
				}
				//$entity->setFood($entity->getFood() - $randomDamage);
				$entity->addEffect(new EffectInstance(Effect::getEffect(Effect::HUNGER), $level * 20, $randomDamage));
                $damager->sendMessage($enchant . " §r§7has Activated!");
            }
        };
    }
}