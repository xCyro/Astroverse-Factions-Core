<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\item\Durable;
use pocketmine\entity\{Effect, EffectInstance};
use pocketmine\Player;

class CleanseEnchantment extends Enchantment {

    /**
     * CleanseEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::CLEANSE, "Cleanse", self::RARITY_RARE, "Have a chance to repair random peices of your armor mid combat but do 50% less damage for 2 seconds when it activates", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
			$entity = $event->getEntity();
			$damager = $event->getDamager();
            if(!$damager instanceof Player) {
                return;
			}
			$repair = mt_rand(20, 40) * $level;
			$random = mt_rand(1, 600);
			$chance = $level * 3;
			if($chance >= $random){
                foreach($damager->getArmorInventory()->getContents() as $armor) {
                    if($armor instanceof Durable) {
						$enchant = "null";
						$distance = 1;
						if($level == 1){
							$enchant = "§eCleansing§r";
							$distance = 5;
						}
						if($level == 2){
							$enchant = "§9Cleansing§r";
							$distance = 10;
						}
						if($level == 3){
							$enchant = "§6Cleansing§r";
							$distance = 13;
						}
						if($level == 4){
							$enchant = "§cCleansing§r";
							$distance = 15;
						}
						if($level == 5){
							$enchant = "§4Cleansing§r";
							$distance = 20;
						}
						$armorPeiece = array_rand(['helmet', 'chestplate', 'leggings', 'boots']);
						if($armorPeiece == 'helmet'){
							$helmet = $damager->getArmorInventory()->getHelmet();
							$damager->getArmorInventory()->setHelmet($helmet->setDamage($repair));
						}
						if($armorPeiece == 'chestplate'){
							$chestplate = $damager->getArmorInventory()->getChestplate();
							$damager->getArmorInventory()->setChestplate($chestplate->setDamage($repair));
						}
						if($armorPeiece == 'leggings'){
							$leggings = $damager->getArmorInventory()->getLeggings();
							$damager->getArmorInventory()->setLeggings($leggings->setDamage($repair));
						}
						if($armorPeiece == 'boots'){
							$boots = $damager->getArmorInventory()->getBoots();
							$damager->getArmorInventory()->setBoots($boots->setDamage($repair));
						}
						$event->setBaseDamage(0);
						$damager->setHealth($damager->getHealth() - 2);
						$damager->addEffect(new EffectInstance(Effect::getEffect(Effect::WEAKNESS), 60, $level));
					    $damager->sendMessage($enchant . " §r§7has Activated!");
                    }
			    }
		    }
            return;
        };
    }
}
