<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\level\Level;

class FullmoonEnchantment extends Enchantment {

    /**
     * FullmoonEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::FULLMOON, "Fullmoon", self::RARITY_MYTHIC, "Have a chance to multiply your damage only at night time and can have a higher chance of doing so depending on the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 10);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }
            $random = mt_rand(1, 100);
            $chance = $level * 1.8;
            if($chance >= $random) {
				$enchant = "null";
				if($level == 1){
					$enchant = "§eFullMoon§r";
				}
				if($level == 2){
					$enchant = "§9FullMoon§r";
				}
				if($level == 3){
					$enchant = "§6FullMoon§r";
				}
				if($level == 4){
					$enchant = "§cFullMoon§r";
				}
				if($level == 5){
					$enchant = "§4FullMoon§r";
				}
				if($damager->getLevel()->getTime() >= Level::TIME_NIGHT){
                	$event->setBaseDamage($event->getBaseDamage() * 1.75);
					$damager->sendMessage($enchant . " §r§7has Activated!");
				}
				
            }
        };
    }
}