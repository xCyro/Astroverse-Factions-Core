<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\entity\{Effect, EffectInstance};

class ToxicEnchantment extends Enchantment {

    /**
     * ToxicEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::TOXIC, "Toxic", self::RARITY_RARE, "Has a chance to poison nearby enemies for 5 seconds and can have a higher chance of doing so depending on the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }
            $random = mt_rand(1, 225);
            $chance = $level * 1.7;
            if($chance >= $random) {
				$enchant = "null";
				$distance = 1;
				if($level == 1){
					$enchant = "§eToxic§r";
					$distance = 5;
				}
				if($level == 2){
					$enchant = "§9Toxic§r";
					$distance = 10;
				}
				if($level == 3){
					$enchant = "§6Toxic§r";
					$distance = 13;
				}
				if($level == 4){
					$enchant = "§cToxic§r";
					$distance = 15;
				}
				if($level == 5){
					$enchant = "§4Toxic§r";
					$distance = 20;
				}
				foreach($damager->getLevel()->getPlayers() as $players){
					if(($players != $damager) and ($damager->distance($players) <= $distance)){
						$players->addEffect(new EffectInstance(Effect::getEffect(Effect::POISON), $level * 30, $level));
					}
				}

                $damager->sendMessage($enchant . " §r§7has Activated!");
            }
        };
    }
}