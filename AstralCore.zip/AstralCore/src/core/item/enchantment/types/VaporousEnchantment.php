<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use core\ElementalPlayer;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\entity\{Effect, EffectInstance};

class VaporousEnchantment extends Enchantment {

    /**
     * VaporousEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::VAPOROUS, "Vaporous", self::RARITY_RARE, "Has a chance to vaporise your soul into the air and can have a higher chance of doing so depending on the level of the enchant.", self::DAMAGE_BY, self::SLOT_ARMOR, 1);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            if(!$entity instanceof ElementalPlayer) {
                return;
            }
            $random = mt_rand(1, 1000);
            $chance = 15;
            if($chance >= $random) {
				//$event->setCancelled();
				//$event->setBaseDamage(0);
				//$event->setKnockBack($event->getKnockBack() - 0.5);
				$enchant = "§9Vaporous";
				$distance = 1;
				if($level == 1){
					$enchant = "§9Vaporous§r";
					$distance = 5;
				}
                $entity->sendMessage($enchant . " §r§7has Activated!");
				$damager = $event->getDamager();

				$entity->addEffect(new EffectInstance(Effect::getEffect(Effect::INVISIBILITY), 5 * 20, 5 * 20));
				$entity->setMotion($entity->getDirectionVector()->normalize()->multiply(3));
				$damager->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 5 * 20, 5 * 20));
				$damager->addEffect(new EffectInstance(Effect::getEffect(Effect::SLOWNESS), 5 * 20, 5 * 20));

            }
        };
    }
}