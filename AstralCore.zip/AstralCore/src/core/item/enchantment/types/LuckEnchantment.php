<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\item\types\Artifact;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\block\Block;
use pocketmine\event\block\BlockBreakEvent;

class LuckEnchantment extends Enchantment {

    /**
     * LuckEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::LUCK, "Clover", self::RARITY_MYTHIC, "Increase your chances of getting an artifact", self::BREAK, self::SLOT_DIG, 1);
        $this->callable = function(BlockBreakEvent $event, int $level) {
            $block = $event->getBlock();
            $player = $event->getPlayer();
            if(!$player instanceof ElementalPlayer) {
                return;
            }
            if($event->isCancelled()) {
                return;
            }
            if($block->getId() === Block::STONE) {
                if(mt_rand(1, 12000) <= 5) {
					$item = new Artifact();
					$player->getInventory()->addItem($item);
					$enchant = "Clover";
					if($level == 1){
						$enchant = "§eClover§r";
					}
					if($level == 2){
						$enchant = "§9Clover§r";
					}
					if($level == 3){
						$enchant = "§6Clover§r";
					}
					if($level == 4){
						$enchant = "§cClover§r";
					}
					if($level == 5){
						$enchant = "§4Clover§r";
					}
                    $player->sendMessage($enchant . " §r§7has Activated!");
                }
            }
        };
    }
}