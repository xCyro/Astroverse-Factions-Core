<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\translation\Translation;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\Player;

class HazeEnchantment extends Enchantment {

    /**
     * HazeEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::HAZE, "Haze", self::RARITY_RARE, "Has a chance to give Nausea for 5 seconds in a radius and can have a higher chance of doing so and higher radius depending of the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof Player) or (!$damager instanceof Player)) {
                return;
            }
            if($entity->hasEffect(Effect::NAUSEA)) {
                return;
            }
            $random = mt_rand(1, 225);
            $chance = $level * 1.7;
            if($chance >= $random) {
				$enchant = "null";
				$distance = 1;
				if($level == 1){
					$enchant = "§eHaze§r";
					$distance = 5;
				}
				if($level == 2){
					$enchant = "§9Haze§r";
					$distance = 10;
				}
				if($level == 3){
					$enchant = "§6Haze§r";
					$distance = 13;
				}
				if($level == 4){
					$enchant = "§cHaze§r";
					$distance = 15;
				}
				if($level == 5){
					$enchant = "§4Haze§r";
					$distance = 20;
				}
				foreach($damager->getLevel()->getPlayers() as $players){
					if(($players != $damager) and ($damager->distance($players) <= $distance)){
						$players->addEffect(new EffectInstance(Effect::getEffect(Effect::NAUSEA), $level * 30, $level));
					}
				}
                $damager->sendMessage($enchant . " §r§7has Activated!");
            }
        };
    }
}