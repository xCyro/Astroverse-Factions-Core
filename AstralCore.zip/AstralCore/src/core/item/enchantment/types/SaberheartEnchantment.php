<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use pocketmine\utils\TextFormat;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\player\PlayerMoveEvent;

class SaberheartEnchantment extends Enchantment {

    /**
     * SaberheartEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::SABERHEART, "SaberHeart", self::RARITY_UNCOMMON, "Obtain permanent Regeneration and obtain a higher level of the effect depending on the level of the enchant.", self::MOVE, self::SLOT_ARMOR, 2);
        $this->callable = function(PlayerMoveEvent $event, int $level) {
			$player = $event->getPlayer();

			if($player->hasEffect(Effect::REGENERATION)) {
				return;
			}

			$player->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 120, 1));
			//$player->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 120, $level));
            return;
        };
    }
}
