<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;

class CloverineEnchantment extends Enchantment {

    /**
     * CloverineEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::CLOVERINE, "Cloverine", self::RARITY_RARE, "Earn money by just hitting an entity (Player, Mob etc) and have a higher chance to do so depending on the level of the enchant", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
			$entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
			}
			if($event->isCancelled()){
				return;
			}
            $random = mt_rand(1, 150);
            $chance = $level * 3;
            if($chance >= $random) {
				$enchant = "null";
				$distance = 1;
				if($level == 1){
					$enchant = "§eCloverine§r";
					$distance = 5;
				}
				if($level == 2){
					$enchant = "§9Cloverine§r";
					$distance = 10;
				}
				if($level == 3){
					$enchant = "§6Cloverine§r";
					$distance = 13;
				}
				if($level == 4){
					$enchant = "§cCloverine§r";
					$distance = 15;
				}
				if($level == 5){
					$enchant = "§4Cloverine§r";
					$distance = 20;
				}
				$randomMoney = mt_rand(100, 500);
				$randomXp = mt_rand(20, 40) * $level;
				$damager->sendMessage($enchant . " §r§7has Activated!");
				$damager->sendPopup("§a+ $$randomMoney");
				$damager->addXp($randomXp);
				$damager->addToBalance($randomMoney);
            }
        };
    }
}