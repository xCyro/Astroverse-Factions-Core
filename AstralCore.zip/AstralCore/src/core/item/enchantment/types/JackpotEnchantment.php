<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use pocketmine\block\Block;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\utils\TextFormat;

class JackpotEnchantment extends Enchantment {

    /**
     * JackpotEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::JACKPOT, "Jackpot", self::RARITY_RARE, "Has a chance to earn money while mining and have a higher chance to do so depending on the level of the enchant.", self::BREAK, self::SLOT_DIG, 5);
        $this->callable = function(BlockBreakEvent $event, int $level) {
            $block = $event->getBlock();
            $player = $event->getPlayer();
            if(!$player instanceof ElementalPlayer) {
                return;
            }
            if($event->isCancelled()) {
                return;
            }
            $amount = mt_rand(3500, 10000);
            $amount *= $level;
            if($block->getId() === Block::STONE) {
                if(mt_rand(1, 200) === mt_rand(1, 200)) {
                    $player->addToBalance($amount);
					$player->sendMessage(TextFormat::GREEN . " + $$amount");
					$player->sendPopup(TextFormat::GREEN . " + $$amount");
                }
            }
        };
    }
}