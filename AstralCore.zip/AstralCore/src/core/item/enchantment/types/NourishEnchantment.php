<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\Player;

class NourishEnchantment extends Enchantment {

    /**
     * NourishEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::NOURISH, "Nourish", self::RARITY_COMMON, "Has a chance to restore hunger and the higher the enchant level the more chance you have of this enchant activating.", self::DAMAGE_BY, self::SLOT_ARMOR, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            if(!$entity instanceof Player) {
                return;
            }
            if($entity->getFood() === $entity->getMaxFood()) {
                return;
            }
            $random = mt_rand(1, 500);
            $chance = $level * 5;
            if($chance >= $random) {
                $pk = new LevelSoundEventPacket();
                $pk->position = $entity;
                $pk->sound = LevelSoundEventPacket::SOUND_BURP;
                $entity->sendDataPacket($pk);
				$entity->setFood($entity->getMaxFood());
				$enchant = "§9Nourish";
				if($level == 1){
					$enchant = "§eNourish§r";
				}
				if($level == 2){
					$enchant = "§9Nourish§r";
				}
				if($level == 3){
					$enchant = "§6Nourish§r";
				}
				if($level == 4){
					$enchant = "§cNourish§r";
				}
				if($level == 5){
					$enchant = "§4Nourish§r";
				}
				$entity->sendMessage($enchant . " §r§7has Activated!");
            }
        };
    }
}