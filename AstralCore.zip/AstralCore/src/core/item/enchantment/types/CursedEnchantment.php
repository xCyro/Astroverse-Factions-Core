<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\entity\{Effect, EffectInstance};
use core\ElementalPlayer;
use pocketmine\Player;

class CursedEnchantment extends Enchantment {

    /**
     * CursedEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::CURSED, "Cursed", self::RARITY_RARE, "Has a chance to effect your opponent with blindness for maximum 5 seconds and can have a higher chance of doing so depending on the level of the enchant.", self::DAMAGE_BY, self::SLOT_ARMOR, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
			$entity = $event->getEntity();
			$damager = $event->getDamager();
            if(!$entity instanceof ElementalPlayer) {
                return;
			}
			if(!$damager instanceof ElementalPlayer){
				return;
			}
            $random = mt_rand(1, 350);
            $chance = $level * 3;
            if($chance >= $random) {
				$damager->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), $level * 5, $level));
				$enchant = "§4Cursed§r";
				$distance = 1;
				if($level == 1){
					$enchant = "§eCursed§r";
					$distance = 5;
				}
				if($level == 2){
					$enchant = "§9Cursed§r";
					$distance = 10;
				}
				if($level == 3){
					$enchant = "§6Cursed§r";
					$distance = 13;
				}
				if($level == 4){
					$enchant = "§cCursed§r";
					$distance = 15;
				}
				if($level == 5){
					$enchant = "§4Cursed§r";
					$distance = 20;
				}
                $entity->sendMessage($enchant . " §r§7has Activated!");
            }
        };
    }
}