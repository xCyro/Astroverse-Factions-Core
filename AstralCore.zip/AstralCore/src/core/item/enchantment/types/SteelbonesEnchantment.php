<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\entity\{Effect, EffectInstance};
use core\ElementalPlayer;
use pocketmine\Player;

class SteelbonesEnchantment extends Enchantment {

    /**
     * SteelbonesEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::STEELBONES, "SteelBones", self::RARITY_RARE, "Has a chance to take less damage while in combat and can have a higher chance of doing so depending on the level of the enchant.", self::DAMAGE_BY, self::SLOT_ARMOR, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
			$entity = $event->getEntity();
			$damager = $event->getDamager();
            if(!$entity instanceof ElementalPlayer) {
                return;
			}
			if(!$damager instanceof ElementalPlayer){
				return;
			}
            $random = mt_rand(1, 350);
            $chance = $level * 1.5;
            if($chance >= $random) {
				$randomDamage = mt_rand(1, 3);
				if($randomDamage == 1){
					$event->setBaseDamage($event->getBaseDamage() * 0.6);
				}
				if($randomDamage == 2){
					$event->setBaseDamage($event->getBaseDamage() * 0.8);
				}
				if($randomDamage == 3){
					$event->setBaseDamage($event->getBaseDamage() * 0.4);
				}
				$enchant = "§4SteelBones";
				$distance = 1;
				if($level == 1){
					$enchant = "§eSteelBones§r";
					$distance = 5;
				}
				if($level == 2){
					$enchant = "§9SteelBones§r";
					$distance = 10;
				}
				if($level == 3){
					$enchant = "§6SteelBones§r";
					$distance = 13;
				}
				if($level == 4){
					$enchant = "§cSteelBones§r";
					$distance = 15;
				}
				if($level == 5){
					$enchant = "§4SteelBones§r";
					$distance = 20;
				}
                $entity->sendMessage($enchant . " §r§7has Activated!");
            }
        };
    }
}