<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\Player;

class DrainEnchantment extends Enchantment {

    /**
     * DrainEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::DRAIN, "Drain", self::RARITY_RARE, "Has a chance to steal health from your opponent and have a higher chance to do so depending on the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
			$damager = $event->getDamager();
			$entity = $event->getEntity();
            $maxHealth = $damager->getMaxHealth();
            if(!$damager instanceof ElementalPlayer) {
                return;
			}
			if(!$entity instanceof Elementalplayer){
				return;
			}
            if($damager->getHealth() === $maxHealth) {
                return;
            }
            $random = mt_rand(1, 300);
            $chance = $level * 6;
            if($chance >= $random) {
				$amount = mt_rand(2, 4);
				$enchant = "null";
				$distance = 1;
				if($level == 1){
					$enchant = "§eDrain§r";
					$distance = 5;
				}
				if($level == 2){
					$enchant = "§9Drain§r";
					$distance = 10;
				}
				if($level == 3){
					$enchant = "§6Drain§r";
					$distance = 13;
				}
				if($level == 4){
					$enchant = "§cDrain§r";
					$distance = 15;
				}
				if($level == 5){
					$enchant = "§4Drain§r";
					$distance = 20;
				}
				$damager->setHealth($damager->getHealth() + $amount);
				$entity->setHealth($entity->getHealth() - $amount);
                $damager->sendMessage($enchant . " §r§7has Activated!");
                return;
            }
        };
    }
}