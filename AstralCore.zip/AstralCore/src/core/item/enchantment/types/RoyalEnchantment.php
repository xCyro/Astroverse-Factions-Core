<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\entity\{Effect, EffectInstance};

class RoyalEnchantment extends Enchantment {

    /**
     * RoyalEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::ROYAL, "Royal", self::RARITY_COMMON, "Has a chance to teleport anyone in a maximum 8x8x8x area too you in combat and can have a higher chance of doing so and higher radius depending on the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }
            $random = mt_rand(1, 150);
            $chance = $level * 1.3;
            if($chance >= $random) {
				$enchant = "null";
				$distance = 1;
				if($level == 1){
					$enchant = "§eRoyal§r";
					$distance = 2;
				}
				if($level == 2){
					$enchant = "§9Royal§r";
					$distance = 3;
				}
				if($level == 3){
					$enchant = "§6Royal§r";
					$distance = 4;
				}
				if($level == 4){
					$enchant = "§cRoyal§r";
					$distance = 5;
				}
				if($level == 5){
					$enchant = "§4Royal§r";
					$distance = 8;
				}
				foreach($damager->getLevel()->getPlayers() as $players){
					if(($players != $damager) and ($damager->distance($players) <= $distance)){
						//$players->addEffect(new EffectInstance(Effect::getEffect(Effect::POISON), $level * 10, 10));
						$players->teleport(new Position($damager->getX(), $damager->getY(), $damager->getZ(), $damager->getLevel()));
						$players->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), $level * 20, 2));
					}
				}
                $damager->sendMessage($enchant . " §r§7has Activated!");
            }
        };
    }
}