<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;

class VampireEnchantment extends Enchantment {

    /**
     * VampireEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::VAMPIRE, "Vampire", self::RARITY_UNCOMMON, "Has a chance to regain your health while in combat and deal damage at the same time and have a higher chance of doing so depending on the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }
            $random = mt_rand(1, 100);
            $chance = $level * 1.3;
            if($chance >= $random) {
				$enchant = "null";
				if($level == 1){
					$enchant = "§eVampire§r";
				}
				if($level == 2){
					$enchant = "§9Vampire§r";
				}
				if($level == 3){
					$enchant = "§6Vampire§r";
				}
				if($level == 4){
					$enchant = "§cVampire§r";
				}
				if($level == 5){
					$enchant = "§4Vampire§r";
				}
				$healthAddition = mt_rand(2, 6);
				$damageAddition = mt_rand(2, 4);
				$damager->setHealth($damager->getHealth() + $healthAddition);
				$entity->setHealth($entity->getHealth() - $damageAddition);
                $damager->sendMessage($enchant . " §r§7has Activated!");
            }
        };
    }
}