<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityEffectAddEvent;

class ImmunityEnchantment extends Enchantment {

    /**
     * ImmunityEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::IMMUNITY, "Immunity", self::RARITY_MYTHIC, "Has a chance to remove negative effects while in combat and have a higher chance to do so depending on the level of the enchant.", self::EFFECT_ADD, self::SLOT_ARMOR, 5);
        $this->callable = function(EntityEffectAddEvent $event, int $level) {
            $effect = $event->getEffect();
            if(!$effect->getType()->isBad()) {
                return;
            }
            $entity = $event->getEntity();
            if(!$entity instanceof ElementalPlayer) {
                return;
            }
            $random = mt_rand(1, 300);
            if($level >= $random) {
				$event->setCancelled();
				$enchant = "§cImmunity";
				if($level == 1){
					$enchant = "§eImmunity§r";
				}
				if($level == 2){
					$enchant = "§9Immunity§r";
				}
				if($level == 3){
					$enchant = "§6Immunity§r";
				}
				if($level == 4){
					$enchant = "§cImmunity§r";
				}
				if($level == 5){
					$enchant = "§4Immunity§r";
				}
                $entity->sendMessage($enchant . " §r§7has Activated!");
                return;
            }
        };
    }
}