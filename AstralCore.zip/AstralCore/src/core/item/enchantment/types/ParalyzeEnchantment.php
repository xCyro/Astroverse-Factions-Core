<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\translation\Translation;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\Player;

class ParalyzeEnchantment extends Enchantment {

    /**
     * ParalyzeEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::PARALYZE, "Paralyze", self::RARITY_MYTHIC, "Has a chance to paralyze your opponent and has a higher chance to do so depending on the level of the enchant", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof Player) or (!$damager instanceof Player)) {
                return;
            }
            if($entity->hasEffect(Effect::BLINDNESS) and $entity->hasEffect(Effect::SLOWNESS)) {
                return;
            }
            $random = mt_rand(1, 750);
            $chance = $level * 3;
            if($chance >= $random) {
				if($level == 1){
					$enchant = "§eParalyze§r";
				}
				if($level == 2){
					$enchant = "§9Paralyze§r";
				}
				if($level == 3){
					$enchant = "§6Paralyze§r";
				}
				if($level == 4){
					$enchant = "§cParalyze§r";
				}
				if($level == 5){
					$enchant = "§4Paralyze§r";
				}
                $entity->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), $level * 25, $level));
				$entity->addEffect(new EffectInstance(Effect::getEffect(Effect::SLOWNESS), $level * 20, $level));
				$entity->addEffect(new EffectInstance(Effect::getEffect(Effect::NAUSEA), $level * 20, $level));
                $damager->sendMessage($enchant . " §r§7has Activated!");
            }
        };
    }
}