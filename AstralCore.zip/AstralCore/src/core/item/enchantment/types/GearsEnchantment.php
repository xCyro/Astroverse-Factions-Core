<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use pocketmine\utils\TextFormat;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\player\PlayerMoveEvent;

class GearsEnchantment extends Enchantment {

    /**
     * GearsEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::GEARS, "Gears", self::RARITY_MYTHIC, "Obtain permanent swiftness and obtain a higher level of the effect depending on the level of the enchant.", self::MOVE, self::SLOT_FEET, 5);
        $this->callable = function(PlayerMoveEvent $event, int $level) {
            $player = $event->getPlayer();
            if((!$player->hasEffect(Effect::SPEED)) or $player->getEffect(Effect::SPEED)->getDuration() <= 20) {
				if($level == 1){
					$player->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 120, 0));
				}
				if($level == 2){
					$player->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 120, 1));
				}
				if($level == 3){
					$player->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 120, 2));
				}
				if($level == 4){
					$player->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 120, 3));
				}
				if($level == 5){
					$player->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 120, 4));
				}
            }
            return;
        };
    }
}
