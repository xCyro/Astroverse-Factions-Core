<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;

class DoubleStrikeEnchantment extends Enchantment {

    /**
     * DoubleStrikeEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::DOUBLESTRIKE, "DoubleStrike", self::RARITY_MYTHIC, "Chance to attack twice in one swing and gain a mystery effect.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if(!$damager instanceof ElementalPlayer) {
                return;
            };
            $random = mt_rand(1, 250);
            $chance = $level * 2;
            if($chance >= $random) {
				$randomStrike = mt_rand(1, 2);
				$damager->addEffect(new EffectInstance(Effect::getEffect(Effect::HASTE), $level * 20, $randomStrike));
				$entity->setHealth($entity->getHealth() - 1);
				$entity->setHealth($entity->getHealth() - 1);
				$entity->setHealth($entity->getHealth() - 1);
				$entity->setHealth($entity->getHealth() - 1);

				// a

				$event->setKnockback($event->getKnockback() + 0.25);
				//$damager->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 5 * 20, 4));

				// a

				$enchant = "null";
				if($level == 1){
					$enchant = "§eDoubleStrike§r";
				}
				if($level == 2){
					$enchant = "§9DoubleStrike§r";
				}
				if($level == 3){
					$enchant = "§6DoubleStrike§r";
				}
				if($level == 4){
					$enchant = "§cDoubleStrike§r";
				}
				if($level == 5){
					$enchant = "§4DoubleStrike§r";
				}

                $damager->sendMessage($enchant . " §r§7has Activated!");
            }
        };
    }
}