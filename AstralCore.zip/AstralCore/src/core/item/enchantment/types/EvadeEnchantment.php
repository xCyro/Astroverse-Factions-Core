<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use core\ElementalPlayer;
use pocketmine\Player;

class EvadeEnchantment extends Enchantment {

    /**
     * EvadeEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::EVADE, "Shield", self::RARITY_RARE, "Has a chance to ignore an enemy attack and can have a higher chance of doing so depending on the level of the enchant.", self::DAMAGE_BY, self::SLOT_ARMOR, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            if(!$entity instanceof ElementalPlayer) {
                return;
            }
            $random = mt_rand(1, 350);
            $chance = $level * 3;
            if($chance >= $random) {
				//$event->setCancelled();
				$event->setBaseDamage(0);
				$event->setKnockBack($event->getKnockBack() - 0.5);
				$enchant = "§cShield";
				$distance = 1;
				if($level == 1){
					$enchant = "§eShield§r";
					$distance = 5;
				}
				if($level == 2){
					$enchant = "§9Shield§r";
					$distance = 10;
				}
				if($level == 3){
					$enchant = "§6Shield§r";
					$distance = 13;
				}
				if($level == 4){
					$enchant = "§cShield§r";
					$distance = 15;
				}
				if($level == 5){
					$enchant = "§4Shield§r";
					$distance = 20;
				}
                $entity->sendMessage($enchant . " §r§7has Activated!");
                $damager = $event->getDamager();
            }
        };
    }
}