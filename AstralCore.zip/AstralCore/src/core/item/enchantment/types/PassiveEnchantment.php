<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;

class PassiveEnchantment extends Enchantment {

    /**
     * PassiveEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::PASSIVE, "Passive", self::RARITY_UNCOMMON, "Has a chance to give Mining Fatigue to your opponent for 5 seconds and can have a higher chance of doing so depending on the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }
            $random = mt_rand(1, 100);
            $chance = $level * 1.2;
            if($chance >= $random) {
				$randomLevel = mt_rand(1, 6);
				$enchant = "null";
				if($level == 1){
					$enchant = "§ePassive§r";
				}
				if($level == 2){
					$enchant = "§9Passive§r";
				}
				if($level == 3){
					$enchant = "§6Passive§r";
				}
				if($level == 4){
					$enchant = "§cPassive§r";
				}
				if($level == 5){
					$enchant = "§4Passive§r";
				}
				$damager->sendMessage($enchant . " §r§7has Activated!");
				$entity->addEffect(new EffectInstance(Effect::getEffect(Effect::MINING_FATIGUE), 120, $randomLevel));
            }
        };
    }
}