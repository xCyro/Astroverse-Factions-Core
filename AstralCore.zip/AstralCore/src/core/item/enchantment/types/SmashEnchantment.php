<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\Elemental;
use core\translation\Translation;
use pocketmine\block\Block;
use pocketmine\entity\Entity;
use pocketmine\Server;
use pocketmine\entity\EntityIds;
use pocketmine\level\Position;
use pocketmine\network\mcpe\protocol\AddActorPacket;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\math\Vector3;
use pocketmine\entity\{Effect, EffectInstance};

class SmashEnchantment extends Enchantment {

    /**
     * SmashEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::SMASH, "Smash", self::RARITY_COMMON, "Has a chance to lift and smash your enemies in the air in a certain height and radius and can have a higher chance of doing so depending on the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }
            $random = mt_rand(1, 800);
            $chance = $level * 1.8;
            if($chance >= $random) {
				$damage = 4;
				$enchant = "null";
				$distance = 1;
				if($level == 1){
					$enchant = "§eSmash§r";
					$distance = 5;
				}
				if($level == 2){
					$enchant = "§9Smash§r";
					$distance = 10;
				}
				if($level == 3){
					$enchant = "§6Smash§r";
					$distance = 13;
				}
				if($level == 4){
					$enchant = "§cSmash§r";
					$distance = 15;
				}
				if($level == 5){
					$enchant = "§4Smash§r";
					$distance = 20;
				}
				//$entity->setHealth($entity->getHealth() - $damage);
				foreach($damager->getLevel()->getPlayers() as $players){
					if(($players != $damager) and ($damager->distance($players) <= $distance)){
						$players->addEffect(new EffectInstance(Effect::getEffect(Effect::LEVITATION), 3 * 20, 15));
						$players->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 3 * 20, 1));
						$players->setHealth($players->getHealth() - 4);
						$entity->setMotion($entity->getMotion()->add(0, 20, 0));
					}
				}
                $damager->sendMessage($enchant . " §r§7has Activated!");
            }
        };
    }
}