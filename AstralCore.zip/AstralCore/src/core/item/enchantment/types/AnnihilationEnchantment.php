<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use pocketmine\entity\Living;
use pocketmine\event\entity\EntityDamageByEntityEvent;

class AnnihilationEnchantment extends Enchantment {

    /**
     * AnnihilationEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::ANNIHILATION, "Annihilation", self::RARITY_MYTHIC, "Increase damage the lower your opponent's health and have a higher chance to do so depending on the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            if(!$entity instanceof Living) {
                return;
			}
			$random = mt_rand(1, 250);
            $chance = $level * 3;
            if($entity->getHealth() < 8) {
				if($chance >= $random){
                	$damager = $event->getDamager();
                	$randomisedDamage = mt_rand(2, 5);
					$event->setBaseDamage($event->getBaseDamage() + 1);
					$enchant = "null";
					$distance = 1;
					if($level == 1){
						$enchant = "§eAnnihilation§r";
						$distance = 5;
					}
					if($level == 2){
						$enchant = "§9Annihilation§r";
						$distance = 10;
					}
					if($level == 3){
						$enchant = "§6Annihilation§r";
						$distance = 13;
					}
					if($level == 4){
						$enchant = "§cAnnihilation§r";
						$distance = 15;
					}
					if($level == 5){
						$enchant = "§4Annihilation§r";
						$distance = 20;
					}
					$damager->sendMessage($enchant . " §r§7has Activated!");
				}
            }
        };
    }
}