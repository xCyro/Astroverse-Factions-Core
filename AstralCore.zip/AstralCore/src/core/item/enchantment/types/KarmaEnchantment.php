<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\level\Explosion;
use pocketmine\level\Position;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\entity\{Effect, EffectInstance};
use core\ElementalPlayer;
use pocketmine\Player;

class KarmaEnchantment extends Enchantment {

    /**
     * KarmaEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::KARMA, "Karma", self::RARITY_COMMON, "Has a chance to spawn a explosion when you die and deal maximum -4 hearts to enemies in a 4x4x4 radius and can have a higher chance of doing so depending on the level of the enchant.", self::DEATH, self::SLOT_ARMOR, 5);
        $this->callable = function(PlayerDeathEvent $event, int $level) {
			$cause = $event->getEntity()->getLastDamageCause();
            $random = mt_rand(1, 15);
            $chance = $level * 1.5;
            if($chance >= $random) {

				if($cause instanceof EntityDamageByEntityEvent){

					$player = $event->getPlayer();
					$killer = $event->getPlayer()->getLastDamageCause();
					if(!$player instanceof ElementalPlayer){
						return;
					}
					if(!$killer instanceof ElementalPlayer){
						return;
					}

					$explosion = new Explosion(new Position($player->getX(), $player->getY(), $player->getZ(), $player->getLevel()), 4, null);
					$explosion->explosionB();

					$enchant = "null";
					$distance = 1;
					if($level == 1){
						$enchant = "§eKarma§r";
						$distance = 2;
					}
					if($level == 2){
						$enchant = "§9Karma§r";
						$distance = 3;
					}
					if($level == 3){
						$enchant = "§6Karma§r";
						$distance = 4;
					}
					if($level == 4){
						$enchant = "§cKarma§r";
						$distance = 6;
					}
					if($level == 5){
						$enchant = "§4Karma§r";
						$distance = 8;
					}
					foreach($player->getLevel()->getPlayers() as $players){
						if(($players != $player) and ($player->distance($players) <= $distance)){
							$players->addEffect(new EffectInstance(Effect::getEffect(Effect::POISON), $level * 40, 5));
						}
					}
					$player->sendMessage($enchant . " §r§7has Activated!");
				}
            }
        };
    }
}