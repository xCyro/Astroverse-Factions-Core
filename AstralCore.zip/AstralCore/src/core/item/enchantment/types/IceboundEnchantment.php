<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\item\enchantment\tasks\FreezeTask;
use core\ElementalPlayer;
use core\Elemental;
use core\command\utils\Command;
use pocketmine\Server;
use core\translation\Translation;
use pocketmine\scheduler\TaskScheduler;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\entity\{Effect, EffectInstance};

class IceboundEnchantment extends Enchantment {

    /**
     * IceboundEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::ICEBOUND, "IceBound", self::RARITY_RARE, "Has a chance to freeze your enemy for 3 seconds and can have a higher chance and more damage depending on the level of the enchant.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }
            $random = mt_rand(1, 600);
            $chance = $level * 2.5;
            if($chance >= $random) {
				$randomDamage = 1;
				$enchant = "null";
				if($level == 1){
					$randomDamage == mt_rand(0, 1);
					$enchant = "§eIcebound§r";
				}
				if($level == 2){
					$randomDamage == mt_rand(1, 2);
					$enchant = "§9Icebound§r";
				}
				if($level == 3){
					$randomDamage == mt_rand(2, 3);
					$enchant = "§6Icebound§r";
				}
				if($level == 4){
					$randomDamage == mt_rand(3, 4);
					$enchant = "§cIcebound§r";
				}
				if($level == 5){
					$randomDamage == mt_rand(3, 5);
					$enchant = "§4Icebound§r";
				}
				//Elemental::getInstance()->getScheduler()->scheduleRepeatingTask(new FreezeTask($entity, 5), 20);
				$entity->addEffect(new EffectInstance(Effect::getEffect(Effect::SLOWNESS), 4 * 20, 5));
                $damager->sendMessage($enchant . " §r§7has Activated!");
            }
        };
    }
}