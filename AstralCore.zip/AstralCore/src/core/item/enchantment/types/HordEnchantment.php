<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\Elemental;
use core\translation\Translation;
use pocketmine\entity\Effect;
use core\combat\boss\Boss;
use core\combat\boss\types\{Alien, Witcher, CorruptedKing, HordEntity};
use pocketmine\entity\EffectInstance;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\entity\Entity;
use pocketmine\level\Position;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\Player;

class HordEnchantment extends Enchantment {

    /**
     * HordEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::HORD, "Hord", self::RARITY_MYTHIC, "Spawn a hord of warriors, blind your opponent and poison them and regenerate health.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }
            $random = mt_rand(1, 800);
            $chance = $level * 3;
            if($chance >= $random) {
				$randomDamage = mt_rand(1, 4);
				$entity->setHealth($entity->getHealth() - $randomDamage);
				$entity->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 3 * 20, 1));
				$entity->addEffect(new EffectInstance(Effect::getEffect(Effect::POISON), 6 * 20, 1));
				$damager->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 2 * 20, 1));
				$damager->addEffect(new EffectInstance(Effect::getEffect(Effect::POISON), 2 * 20, 1));
				$damager->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 10 * 20, 1));
				$damager->setHealth($damager->getHealth() + 4);
				//$this->hadesBoss($entity->getLevel(), $entity->getPosition());
				//$entity->sendMessage(Translation::ORANGE . "Your opponent's Hord has been Spawned and they are now regenerating health!");
				$enchant = "null";
				if($level == 1){
					$enchant = "§eHord§r";
				}
				if($level == 2){
					$enchant = "§9Hord§r";
				}
				if($level == 3){
					$enchant = "§6Hord§r";
				}
				if($level == 4){
					$enchant = "§cHord§r";
				}
				if($level == 5){
					$enchant = "§4Hord§r";
				}
				$damager->sendMessage($enchant . " §r§7has Activated!");
				$this->summonHord($entity, $entity->getX() - 3, $entity->getY() + 1, $entity->getZ() - 3, $entity->getLevel()->getName());
				$this->summonHord($entity, $entity->getX() - 4, $entity->getY() + 1, $entity->getZ() - 3, $entity->getLevel()->getName());
				$this->summonHord($entity, $entity->getX() - 4, $entity->getY() + 2, $entity->getZ() - 4, $entity->getLevel()->getName());
				//$this->summonHord($entity, $entity->getX() - 2, $entity->getY() + 2, $entity->getZ() - 4, $entity->getLevel()->getName());
				//$this->summonHord($entity, $entity->getX() - 5, $entity->getY() + 3, $entity->getZ() - 5, $entity->getLevel()->getName());
				//$this->summonHord($entity, $entity->getX() - 5, $entity->getY() + 3, $entity->getZ() - 5, $entity->getLevel()->getName());
				//$this->summonHord($entity, $entity->getX() - 4, $entity->getY() + 4, $entity->getZ() - 4, $entity->getLevel()->getName());
				//$this->summonHord($entity, $entity->getX() - 4, $entity->getY() + 4, $entity->getZ() - 4, $entity->getLevel()->getName());
				//$this->summonHord($entity, $entity->getX() - 1, $entity->getY() + 5, $entity->getZ() - 1, $entity->getLevel()->getName());
				//$this->summonHord($entity, $entity->getX() - 1, $entity->getY() + 5, $entity->getZ() - 1, $entity->getLevel()->getName());
            }
        };
	}

	//public function hadesBoss(Level $level, Position $pos)
    //{
        //$entity = Entity::createEntity("Zombie", $level, Entity::createBaseNBT($pos));
        //$entity->setMaxHealth(50);
       // $entity->setHealth(50);
        //$entity->setNameTag("§c§lHades§r\n§f" . $entity->getHealth() . " §c❤");
        //$entity->setNameTagAlwaysVisible();
        //$entity->spawnToAll();
	//}
	
	public function summonHord(ElementalPlayer $player, $x, $y, $z, $level) : void {
        $class = Elemental::getInstance()->getCombatManager()->getBossNameByIdentifier(20);
        $lvl = Server::getInstance()->getLevelByName($level);
        $pos = new Vector3($x, $y, $z);
        //$lvl->loadChunk($pos->x >> 4, $pos->z >> 4, true);
        $nbt = Entity::createBaseNBT($pos);
        /** @var Boss $entity */
        $entity = new $class($lvl, $nbt);
        $entity->spawnToAll();
	}
}