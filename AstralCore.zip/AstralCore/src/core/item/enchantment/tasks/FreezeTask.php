<?php

declare(strict_types = 1);

namespace core\item\enchantment\tasks;

use core\Elemental;
use core\ElementalPlayer;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\level\Position;
use pocketmine\level\sound\EndermanTeleportSound;
use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat;

class FreezeTask extends Task {

    /** @var ElementalPlayer|null */
    private $player;

    /** @var Position */
    private $position;

    /** @var Position */
    private $originalLocation;

    /** @var int */
    private $time;

    /** @var int */
    private $maxTime;

    /**
     * FreezeTask constructor.
     *
     * @param ElementalPlayer $player
     * @param Position      $position
     * @param int           $time
     */
    public function __construct(ElementalPlayer $player, int $time) {
        $this->player = $player;
		$player->addTitle(TextFormat::AQUA . "Frozen");
        $this->player = null;
        return;
        $this->originalLocation = $player->asPosition();
        $this->time = $time;
        $this->maxTime = $time;
    }

    /**
     * @param int $currentTick
     */
    public function onRun(int $currentTick) {
        if($this->player === null or $this->player->isClosed()) {
            Elemental::getInstance()->getScheduler()->cancelTask($this->getTaskId());
            return;
        }
        if($this->player->distance($this->originalLocation) >= 1) {
			$this->player->teleport($this->originalLocation);
		}
        if($this->time >= 0) {
            $this->time--;
            return;
        }
		$this->player->addTitle(TextFormat::DARK_AQUA . "Unfrozen");
        $this->player->getLevel()->addSound(new EndermanTeleportSound($this->player));
        Elemental::getInstance()->getScheduler()->cancelTask($this->getTaskId());
        return;
    }
}
