<?php

declare(strict_types = 1);

namespace core\item\enchantment;

interface EnchantmentIdentifiers {
}
