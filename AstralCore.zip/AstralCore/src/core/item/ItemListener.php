<?php



declare(strict_types=1);



namespace core\item;



use core\command\utils\Command;

use pocketmine\command\CommandSender;

use core\crate\task\GreekCrateTask;

use core\event\EventManager;

use core\item\enchantment\Enchantment;

use core\item\task\HolyBoxAnimationTask;

use core\item\types\BossEgg;

use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;

use pocketmine\entity\Effect;

use pocketmine\entity\EffectInstance;

use core\item\types\ChestKit;

use core\item\types\CrateKeyNote;

use core\item\types\Drops;

use core\item\types\GreekCrate;

use core\item\types\Head;

use core\item\types\HolyBox;

use core\item\types\MoneyNote;

use core\item\types\PhoenixBone;

use core\item\types\Present;

use core\item\types\Artifact;

use core\item\types\SellWand;

use core\item\types\XPNote;

use core\item\types\MoneyPouch;

use core\item\types\BloodyNote;

use core\item\types\KothFlare;

use core\item\types\RankShard;

use core\item\types\VoteLootbox;

use core\item\types\ImmortalityRune;

use core\item\types\AsteroidSpell;

use core\item\types\ZombieHead;

use core\item\types\TNTLauncher;

use core\item\types\CreeperEgg;

use core\item\types\WallGenerator;

use core\item\types\SoulsBottle;

use core\item\types\NitroGem;

use core\command\types\MaskCommand;

use core\rank\Rank;

use core\faction\Faction;

use core\faction\FactionManager;

use core\Elemental;

use core\ElementalPlayer;

use core\price\event\ItemSellEvent;

use core\translation\Translation;

use core\translation\TranslationException;

use core\utils\UtilsException;

use pocketmine\block\Block;

use pocketmine\entity\Entity;

use pocketmine\entity\Living;

use pocketmine\event\block\BlockBreakEvent;

use pocketmine\event\entity\EntityDamageByEntityEvent;

use pocketmine\event\entity\EntityDamageEvent;

use pocketmine\event\inventory\InventoryTransactionEvent;

use pocketmine\event\Listener;

use pocketmine\event\player\PlayerChatEvent;

use pocketmine\event\player\PlayerInteractEvent;

use pocketmine\event\player\PlayerItemHeldEvent;

use pocketmine\event\player\PlayerJoinEvent;

use pocketmine\inventory\ArmorInventory;

use pocketmine\inventory\transaction\action\SlotChangeAction;

use pocketmine\item\Item;

use pocketmine\level\Position;

use pocketmine\level\sound\AnvilBreakSound;

use pocketmine\level\sound\AnvilUseSound;

use pocketmine\level\sound\BlazeShootSound;

use pocketmine\nbt\BigEndianNBTStream;

use pocketmine\nbt\tag\CompoundTag;

use pocketmine\nbt\tag\IntTag;

use pocketmine\nbt\tag\ListTag;

use pocketmine\nbt\tag\StringTag;

use pocketmine\scheduler\Task;

use pocketmine\tile\Chest as TileChest;

use pocketmine\tile\Container;

use pocketmine\tile\Tile;

use pocketmine\utils\TextFormat;



class ItemListener implements Listener

{



    /** @var Elemental */

    private $core;



    /** @var array */

    private $ids = [

        Block::COAL_ORE,

        Block::DIAMOND_ORE,

        Block::EMERALD_ORE,

        Block::REDSTONE_ORE,

        Block::LAPIS_ORE,

        Block::NETHER_QUARTZ_ORE

    ];



    /** @var int */

    private $sellWandCooldown = [];



    /**

     * ItemListener constructor.

     *

     * @param Elemental $core

     */

    public function __construct(Elemental $core)

    {

        $this->core = $core;

    }



    /**

     * @priority NORMAL

     * @param PlayerJoinEvent $event

     */

    public function onPlayerJoin(PlayerJoinEvent $event)

    {

        $player = $event->getPlayer();

        if (!$player instanceof ElementalPlayer) {

            return;

        }

        if ($player->getArmorInventory() !== null)

            $player->setActiveArmorEnchantments();

    }



    /**

     * @priority LOWEST

     * @param PlayerChatEvent $event

     */

    public function onPlayerChat(PlayerChatEvent $event)

    {

        $player = $event->getPlayer();

        if (!$player instanceof ElementalPlayer) {

            return;

        }

        $item = $player->getInventory()->getItemInHand();

        $name = TextFormat::RESET . TextFormat::WHITE . $item->getName();

        if ($item->hasCustomName()) {

            $name = $item->getCustomName();

        }

        $replace = TextFormat::DARK_GRAY . "[" . $name . TextFormat::RESET . TextFormat::GRAY . " * " . TextFormat::WHITE . $item->getCount() . TextFormat::DARK_GRAY . "]" . TextFormat::RESET . $player->getRank()->getChatColor();

        $message = $event->getMessage();

        $message = str_replace("[item]", $replace, $message);

        $event->setMessage($message);

    }



    /**

     * @priority NORMAL

     * @param PlayerItemHeldEvent $event

     */

    public function onPlayerItemHeld(PlayerItemHeldEvent $event)

    {

        $player = $event->getPlayer();

        if (!$player instanceof ElementalPlayer) {

            return;

        }

        $item = $event->getItem();

        if ($item->hasEnchantments()) {

            if ($item->hasEnchantment(Enchantment::KNOCKBACK)) {

                $player->getInventory()->removeItem($item);

                $item->removeEnchantment(Enchantment::KNOCKBACK);

                $player->getInventory()->addItem($item);

            }

        }

//        if ($item->getId() === Item::BUCKET) {

//            $player->getInventory()->removeItem($item);

//            return;

//        }

        $player->setActiveHeldItemEnchantments();

    }



    /**

     * @priority HIGHEST

     * @param PlayerInteractEvent $event

     *

     * @throws TranslationException

     * @throws UtilsException

     */

    public function onPlayerInteract(PlayerInteractEvent $event): void

    {

        $item = $event->getItem();

        $player = $event->getPlayer();

        $block = $event->getBlock();

        if (!$player instanceof ElementalPlayer) {

            return;

        }

        $inventory = $player->getInventory();

        if ($item->getId() === Item::EXPERIENCE_BOTTLE) {

            $xp = 0;

            for ($i = 0; $i <= $item->getCount(); ++$i) {

                $xp += mt_rand(6, 18);

            }

			$player->addXp($xp);

            $inventory->removeItem($item);

            $event->setCancelled();

            return;

        }

        $tag = $item->getNamedTagEntry(CustomItem::CUSTOM);

        if ($tag === null) {

            return;

        }

        if ($tag instanceof CompoundTag) {

            if ($tag->hasTag(CrateKeyNote::CRATE, StringTag::class) and $tag->hasTag(CrateKeyNote::AMOUNT, IntTag::class)) {

                $crate = $tag->getString(CrateKeyNote::CRATE);

                $amount = $tag->getInt(CrateKeyNote::AMOUNT);

                $crate = $this->core->getCrateManager()->getCrate($crate);

                $player->addKeys($crate, $amount);

                $player->sendMessage("§l§8(§a!§8)§r §7You've successfully claimed §a" . $amount . " §2" . $crate->getName() . " §7crate key(s)!§r");

                $player->playXpLevelUpSound();

                $player->getLevel()->addSound(new BlazeShootSound($player));

                $inventory->setItemInHand($item->setCount($item->getCount() - 1));

                $event->setCancelled();

            }

            if ($tag->hasTag(ChestKit::KIT, StringTag::class)) {

                $kit = $tag->getString(ChestKit::KIT);

                $kit = $this->core->getKitManager()->getKitByName($kit);

                if ($kit->giveTo($player)) {

                    $player->addTitle("§7Equipped Kit§r\n", "§l§8[§6+§8]§r §l§6" . $kit->getName() . "§r §l§8[§6+§8]§r");

                    $player->sendMessage("§l§8[§6+§8]§r§7You've successfully §6redeemed §7a §l§6" . $kit->getName() . "§r §7kit!§r");

                    $player->getLevel()->addSound(new AnvilBreakSound($player));

                    $inventory->setItemInHand($item->setCount($item->getCount() - 1));

                }

                $event->setCancelled();

            }

            if ($tag->hasTag(XPNote::XP, IntTag::class)) {

                $amount = $tag->getInt(XPNote::XP);

                $player->sendMessage("§l§8(§a!§8)§r §7You've successfully redeemed §a" . $amount . " XP!§r");

                $player->playXpLevelUpSound();

                $player->addXp($amount);

                $inventory->setItemInHand($item->setCount($item->getCount() - 1));

                $event->setCancelled();

            }

            if ($tag->hasTag(MoneyNote::BALANCE, IntTag::class)) {

				if($tag->hasTag(Head::PLAYER, StringTag::class)){

					return;

				}

                $amount = $tag->getInt(MoneyNote::BALANCE);

                $player->sendMessage("§l§8(§a!§8)§r §7You've successfully redeemed §a$" . $amount . "!§r");

                $player->getLevel()->addSound(new BlazeShootSound($player));

                $player->addToBalance($amount);

                $inventory->setItemInHand($item->setCount($item->getCount() - 1));

                $event->setCancelled();

			}

			if($tag->hasTag(ZombieHead::ZOMBIE, StringTag::class)){

				$amount = $tag->getInt("MoneyE");

				$item = $player->getInventory()->getItemInHand();



				$player->playXpLevelUpSound();

				$player->getInventory()->setItemInHand($item->setCount($item->getCount() - 1));



				$player->addToBalance($amount);



				$event->setCancelled();



			}

            if ($tag->hasTag(Artifact::ARTIFACT, StringTag::class)) {

				if(mt_rand(1, 8) == 3){

					$kits = $this->core->getKitManager()->getSacredKits();

                    $kit = $kits[array_rand($kits)];

                    $player->getLevel()->addSound(new BlazeShootSound($player));

					$player->getInventory()->addItem((new HolyBox($kit))->getItemForm());

					$player->sendMessage("§8§l(§3!§8) §r§7You got lucky with this Artifact! You have received your Box!");

				} else {

					$player->getLevel()->addSound(new AnvilUseSound($player));

					$inventory->addItem(new BloodyNote(100000));

					$player->sendMessage("§8§l(§c!§8) §r§7You got unlucky with this Artifact! Since you got unlucky with your Artifact you have been given a bloody note. Figure out how much you've made!");

				}

				$inventory->setItemInHand($item->setCount($item->getCount() - 1));

                $event->setCancelled();

			}

			if($tag->hasTag(MoneyPouch::MONEY, IntTag::class)){

				$item = $player->getInventory()->getItemInHand();

				$amount = $tag->getInt(MoneyPouch::MONEY);

				$name = $player->getName();



				$player->getLevel()->addSound(new AnvilUseSound($player));



				$amountToGive = mt_rand(0, $amount);



				$player->getInventory()->setItemInHand($item->setCount($item->getCount() - 1));



				$player->addTitle("§2$" . "§a$amountToGive");

				$player->getServer()->broadcastMessage("§8§l(§b!§8) §r§b$name §r§7has just won §2$" . "§a$amountToGive §r§7from a §r§7money pouch!");

				$player->addToBalance($amountToGive);



				$event->setCancelled();



			}

			if($tag->hasTag(BloodyNote::MAMOUNT, IntTag::class)){

				$item = $player->getInventory()->getItemInHand();

				$amount = $tag->getInt(BloodyNote::MAMOUNT);

				$name = $player->getName();



				$player->getLevel()->addSound(new BlazeShootSound($player));



				$amountToGive = mt_rand(0, $amount);



				$player->getInventory()->setItemInHand($item->setCount($item->getCount() - 1));



				$player->addTitle("§4$" . "§c$amountToGive");

				$player->addToBalance($amountToGive);



				$event->setCancelled();



			}

			if($tag->hasTag(KothFlare::KOTH, IntTag::class)){

				$item = $player->getInventory()->getItemInHand();

				$amount = $tag->getInt(KothFlare::KOTH);

				$name = $player->getName();



				$player->getLevel()->addSound(new BlazeShootSound($player));



				$player->getInventory()->setItemInHand($item->setCount($item->getCount() - 1));



				$player->addTitle("§c§lK§eO§bT§dH\n§r§b§lSTARTED!");



				//Code to start a koth



				$event->setCancelled();



			}

			if($tag->hasTag(RankShard::RANK, StringTag::class)){

				$item = $player->getInventory()->getItemInHand();

				$rank = $tag->getString(RankShard::RANK);

				$name = $player->getName();

				$rankMan = $this->core->getRankManager()->getRankByName($rank);



				$player->getLevel()->addSound(new BlazeShootSound($player));



				$player->getInventory()->setItemInHand($item->setCount($item->getCount() - 1));



				$player->addTitle("§b§l$rank\n§r§bRedeemed");



				$player->setRank($rankMan);



				$event->setCancelled();



            }
            
            if($tag->hasTag(NitroGem::NITRO_GEM, StringTag::class))
            {

                $inventory->setItemInHand($item->setCount($item->getCount() - 1));

                $player->addTitle("§a§lNitro Gem§r");

                $player->getLevel()->addSound(new BlazeShootSound($player));

                $player->addToBalance(100000);

                $player->setRank($this->core->getRankManager()->getRankByName("Nitro-Booster"));

                $player->getInventory()->addItem((new Artifact())->getItemForm());

                $player->addKeys($this->core->getCrateManager()->getCrate("Astronomic"), 1);

                $event->setCancelled();

            }

            if ($tag->hasTag(Present::PRESENT, StringTag::class)) {

                $inventory->setItemInHand($item->setCount($item->getCount() - 1));

                $reward = EventManager::getGiftChooser()->getReward();

                $player->addTitle("§cYou've been gifted...", "§7" . $reward->getName());

                $player->getLevel()->addSound(new BlazeShootSound($player));

                $callable = $reward->getCallback();

                $callable($player);

                $event->setCancelled();

			}

			if($tag->hasTag(VoteLootbox::VLOOTBOX, StringTag::class)){

				$inventory->setItemInHand($item->setCount($item->getCount() - 1));

				$reward = EventManager::getLootboxChooser()->getReward();

				$player->addTitle("§2§l" . $reward->getName());

				$player->getLevel()->addSound(new AnvilUseSound($player));

				$callable = $reward->getCallBack();

				$callable($player);

				$event->setCancelled();

			}

			if($tag->hasTag(ImmortalityRune::RAMOUNT, IntTag::class)) {



				$inventory->setItemInHand($item->setCount($item->getCount() - 1));



				$amount = $tag->getInt(ImmortalityRune::RAMOUNT);



				$player->addTitle("§5§l§kiii§r§d§l Immortality Rune §r§5§l§kiii§r");



				$pk = new LevelSoundEventPacket();

				$pk->position = $player;

				$pk->sound = LevelSoundEventPacket::SOUND_RAID_HORN;

				//$player->sendDataPacket($pk);



				foreach($player->getLevel()->getPlayers() as $onPlayers) {



					$onPlayers->sendDataPacket($pk);



				}



				$player->addEffect(new EffectInstance(Effect::getEffect(Effect::RESISTANCE), $amount * 20, 255));



				$event->setCancelled();



			}

			if($tag->hasTag(AsteroidSpell::SPELL_ASTEROID, StringTag::class)) {



				$inventory->setItemInHand($item->setCount($item->getCount() - 1));



				$player->addTitle("§4§l§kiii§r§c§l BLASTED §r§4§l§kiii§r");



				//$player->setMotion($player->getMotion()->add(5, 5, 5));

				$player->setMotion($player->getDirectionVector()->normalize()->multiply(8));



				$pk = new LevelSoundEventPacket();

				$pk->position = $player;

				$pk->sound = LevelSoundEventPacket::SOUND_BLAST;



				foreach($player->getLevel()->getPlayers() as $onPlayers) {



					$onPlayers->sendDataPacket($pk);



				}



				$player->addEffect(new EffectInstance(Effect::getEffect(Effect::LEVITATION), 10 * 20, 5));



				$event->setCancelled();



			}

			if($tag->hasTag(SoulsBottle::SOULSBOTTLE, StringTag::class)) {



				if($player->isSneaking()) {



					$amount = $tag->getInt(SoulsBottle::SOULSBOTTLEAMOUNT) * $item->getCount();



					$player->addTitle("§d" . $amount);



					$player->addSouls($amount);



					$inventory->setItemInHand($item->setCount($item->getCount() - $item->getCount()));



				} else {



					$inventory->setItemInHand($item->setCount($item->getCount() - 1));



					$amount = $tag->getInt(SoulsBottle::SOULSBOTTLEAMOUNT);

	

					$player->addTitle("§d" . $amount);

	

					$player->addSouls($amount);



				}



				if($player->getSouls() >= 100000) {
                    
                    $player->setSouls($player->getSouls() - 100000);

					$item = MaskCommand::getMaskCharmItem();

					$player->getInventory()->addItem($item);

				}

				$event->setCancelled();



			}

            if ($tag->hasTag(BossEgg::BOSS_ID, IntTag::class)) {

                if ($player->getLevel()->getFolderName() !== "bossarena") {

                    $player->sendMessage(Translation::getMessage("canOnlySpawnInArena"));

                    return;

                }

                $areaManager = $this->core->getAreaManager();

                $areas = $areaManager->getAreasInPosition($player->asPosition());

                if ($areas !== null) {

                    foreach ($areas as $area) {

                        if ($area->getPvpFlag() === false) {

                            $player->sendMessage(Translation::getMessage("canOnlySpawnInArena"));

                            return;

                        }

                    }

                }

                $inventory->setItemInHand($item->setCount($item->getCount() - 1));

                $this->core->getCombatManager()->createBoss($tag->getInt(BossEgg::BOSS_ID), $player->getLevel(), Entity::createBaseNBT($player->asPosition()));

                $this->core->getServer()->broadcastMessage(Translation::getMessage("bossSpawned"));

                $event->setCancelled();

            }

            if ($tag->hasTag(SellWand::USES, IntTag::class)) {

                if (isset($this->sellWandCooldown[$player->getRawUniqueId()]) and (time() - $this->sellWandCooldown[$player->getRawUniqueId()]) < 3) {

                    $seconds = 3 - (time() - $this->sellWandCooldown[$player->getRawUniqueId()]);

                    $player->sendMessage(Translation::getMessage("actionCooldown", [

                        "amount" => TextFormat::RED . $seconds

                    ]));

                    return;

                }

                if ($event->isCancelled()) {

                    $player->sendMessage(Translation::getMessage("blockProtected"));

                    return;

                }

                $tile = $block->getLevel()->getTile($block);

                if (!$tile instanceof Container) {

                    $player->sendMessage(Translation::getMessage("invalidBlock"));

                    return;

                }

                $content = $tile->getInventory()->getContents();

                /** @var Item[] $items */

                $items = [];

                $sellable = false;

                $sellables = $this->core->getPriceManager()->getSellables();

                $entries = [];

                foreach ($content as $i) {

                    if (!isset($sellables[$i->getId()])) {

                        continue;

                    }

                    $entry = $sellables[$i->getId()];

                    if (!$entry->equal($i)) {

                        continue;

                    }

                    if ($sellable === false) {

                        $sellable = true;

                    }

                    if (!isset($entries[$entry->getName()])) {

                        $entries[$entry->getName()] = $entry;

                        $items[$entry->getName()] = $i;

                    } else {

                        $items[$entry->getName()]->setCount($items[$entry->getName()]->getCount() + $i->getCount());

                    }

                }

                if ($sellable === false) {

                    $event->setCancelled();

                    $player->sendMessage(Translation::getMessage("nothingSellable"));

                    $this->sellWandCooldown[$player->getRawUniqueId()] = time();

                    return;

                }

                $price = 0;

                foreach ($entries as $entry) {

                    $i = $items[$entry->getName()];

                    $price += $i->getCount() * $entry->getSellPrice();

                    $tile->getInventory()->removeItem($i);

                    $ev = new ItemSellEvent($player, $i, $price);

                    $ev->call();

                    $player->sendMessage(Translation::getMessage("sell", [

                        "amount" => TextFormat::GREEN . $i->getCount(),

                        "item" => TextFormat::DARK_GREEN . $entry->getName(),

                        "price" => TextFormat::LIGHT_PURPLE . "$" . $price

                    ]));

                }

                $player->addToBalance($price);

                $amount = $tag->getInt(SellWand::USES);

                $player->playXpLevelUpSound();

                --$amount;

                if ($amount <= 0) {

                    $player->getLevel()->addSound(new AnvilBreakSound($player));

                    $inventory->setItemInHand($item->setCount($item->getCount() - 1));

                } else {

                    $tag->setInt(SellWand::USES, $amount);

                    $lore = [];

                    $lore[] = "";

                    $lore[] = TextFormat::RESET . TextFormat::AQUA . "Uses: " . TextFormat::WHITE . $amount;

                    $lore[] = "";

                    $lore[] = TextFormat::RESET . TextFormat::WHITE . "Tap a chest to sell all It's sellable contents.";

                    $item->setLore($lore);

                    $inventory->setItemInHand($item);

                }

                $event->setCancelled();

                $this->sellWandCooldown[$player->getRawUniqueId()] = time();

			}

			if($tag->hasTag(TNTLauncher::TNTLauncher, StringTag::class)) {



				if($player->getLevel()->getFolderName() !== Faction::CLAIM_WORLD) {

					$player->sendMessage("§8§l(§c!§8) §r§7TNT Launchers may only be used in the wilderness!");

					return;

				}



				$uses = $tag->getInt(TNTLauncher::TLUses);

				$tier = $tag->getInt(TNTLauncher::TLTier);

				$requiredTnt = $tag->getInt(TNTLauncher::TNTReq);



				$tntItem = Item::get(Item::TNT);



				if($player->getInventory()->contains($tntItem)) {



					$tnt = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

					$tnt->setMotion($player->getDirectionVector()->normalize()->multiply($tier));

					$tnt->spawnToAll();



					$inventory->removeItem($tntItem);



					--$uses;



					if($uses <= 0) {



						$player->getLevel()->addSound(new AnvilBreakSound($player));

						$inventory->setItemInHand($item->setCount($item->getCount() - 1));



					} else {



						$tag->setInt(TNTLauncher::TLUses, $uses);



						$lore = [];

						$lore[] = "";

						$lore[] = "§eThe greater the tier, the larger radius and tnt required.";

						$lore[] = "";

						$lore[] = "§r§cUses: §e$uses";

						$lore[] = "§r§cTier: §e$tier";

						$lore[] = "";

						$lore[] = "§r§7Each fire will require §e$requiredTnt §7TNT!";

						$item->setLore($lore);

						$inventory->setItemInHand($item);



					}



					$event->setCancelled(true);



				} else {

					$player->sendMessage("§8§l(§c!§8) §r§7You must have atleast §e$requiredTnt TNT §r§7to use this §cTNT Launcher!§r");

					return;

				}



			}

			if($tag->hasTag(CreeperEgg::CREEPER_EGG, StringTag::class)) {



				if($player->getLevel()->getFolderName() !== Faction::CLAIM_WORLD) {

					$player->sendMessage("§8§l(§c!§8) §r§7Creeper Eggs may only be used in the wilderness.");

					return;

				}



				$explosion = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion->spawnToAll();

				$explosion2 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion2->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion2->spawnToAll();

				$explosion3 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion3->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion3->spawnToAll();

				$explosion4 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion4->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion4->spawnToAll();

				$explosion5 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion5->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion5->spawnToAll();

				$explosion6 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion6->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion6->spawnToAll();

				$explosion7 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion7->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion7->spawnToAll();

				$explosion8 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion8->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion8->spawnToAll();

				$explosion9 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion9->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion9->spawnToAll();

				$explosion10 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion10->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion10->spawnToAll();



				$explosion11 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion11->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion11->spawnToAll();

				$explosion12 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion12->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion12->spawnToAll();

				$explosion13 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion13->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion13->spawnToAll();

				$explosion14 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion14->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion14->spawnToAll();

				$explosion15 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion15->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion15->spawnToAll();

				$explosion16 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion16->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion16->spawnToAll();

				$explosion17 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion17->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion17->spawnToAll();

				$explosion18 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion18->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion18->spawnToAll();

				$explosion19 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion19->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion19->spawnToAll();

				$explosion20 = Entity::createEntity("PrimedTNT", $player->getLevel(), Entity::createBaseNBT($player));

				$explosion20->setMotion($player->getDirectionVector()->normalize()->multiply(2));

				$explosion20->spawnToAll();



				$player->sendMessage("§8§l(§4!§8) §r§c§lBOOM! A MASSIVE EXPLOSION!§r");

				$player->addTitle("§4§lBOOM!§r");



				$player->getLevel()->addSound(new AnvilBreakSound($player));

				$inventory->setItemInHand($item->setCount($item->getCount() - 1));



				$event->setCancelled();



			}

            if ($tag->hasTag(HolyBox::SACRED_KIT, StringTag::class)) {

                $event->setCancelled();

                if ($player->getLevel()->getFolderName() !== $this->core->getServer()->getDefaultLevel()->getFolderName()) {

                    $player->sendMessage(Translation::getMessage("onlyInSpawn"));

                    return;

                }

                if ($block->getId() !== Block::AIR) {

                    $position = Position::fromObject($block->add(0, 1, 0), $player->getLevel());

                    if ($player->getLevel()->getBlock($position)->getId() === Block::AIR) {

                        $inventory->setItemInHand($item->setCount($item->getCount() - 1));

                        $faces = [

                            0 => 4,

                            1 => 2,

                            2 => 5,

                            3 => 3

                        ];

                        $face = $faces[$player->getDirection()];

                        $position->getLevel()->setBlock($position, Block::get(Block::CHEST, $face));

                        $this->core->getScheduler()->scheduleRepeatingTask(new HolyBoxAnimationTask($player, $position, $this->core->getKitManager()->getKitByName($tag->getString(HolyBox::SACRED_KIT))), 7);

                    }

                }

            }

            if ($tag->hasTag(Drops::ITEM_LIST, ListTag::class)) {

                $list = $tag->getListTag(Drops::ITEM_LIST);

                $inventory->setItemInHand($item->setCount($item->getCount() - 1));

                foreach ($list->getAllValues() as $tag) {

                    $item = Item::nbtDeserialize($tag);

                    if ($inventory->canAddItem($item)) {

                        $inventory->addItem($item);

                    }

                }

                $player->getLevel()->addSound(new BlazeShootSound($player->asPosition()));

                $event->setCancelled();

            }

            if ($tag->hasTag(PhoenixBone::PHOENIX_BONE, StringTag::class)) {

                $areaManager = $this->core->getAreaManager();

                $areas = $areaManager->getAreasInPosition($player->asPosition());

                if (!is_null($areas)) {

                    foreach ($areas as $area) {

                        if ($area->getPvpFlag() === false) {

                            $player->sendMessage(Translation::getMessage("canOnlySpawnInArena"));

                            return;

                        }

                    }

                }



                if ($block->getId() !== Block::AIR) {

                    $inventory->setItemInHand($item->setCount($item->getCount() - 1));





                    if (!$player->getLevel()->isChunkLoaded($block->x >> 4, $block->z >> 4)) {

                        $player->getLevel()->loadChunk($block->x >> 4, $block->z >> 4, true);

                    }

                    $phoenix = Entity::createEntity("Phoenix", $player->getLevel(), Entity::createBaseNBT($block));

                    $phoenix->spawnToAll();

                    // $event->setCancelled();

                }

            }

            if ($tag->hasTag(GreekCrate::GREEK_CRATE, StringTag::class)) {

                $event->setCancelled(true);

                if ($block->getId() !== Block::AIR) {

                    $position = Position::fromObject($block->add(0, 1, 0), $player->getLevel());

                    if ($player->getLevel()->getBlock($position)->getId() === Block::AIR) {

                        $inventory->setItemInHand($item->setCount($item->getCount() - 1));

                        $faces = [

                            0 => 4,

                            1 => 2,

                            2 => 5,

                            3 => 3

                        ];

                        $face = $faces[$player->getDirection()];

                        $position->getLevel()->setBlock($position, Block::get(Block::CHEST, $face));

                        $nbt = TileChest::createNBT($position, $face, $item, $player);

                        $tile = Tile::createTile(Tile::CHEST, $player->getLevelNonNull(), $nbt);

                        $slot = 0;

                        if ($tile instanceof TileChest) {

                            foreach (Elemental::getInstance()->getCrateManager()->getGreekCrate()->getRewards() as $reward) {

                                $tile->getInventory()->setItem($slot, $reward->getItem()->setCustomName($reward->getName()));

                                ++$slot;

                            }

                            new GreekCrateTask($player, $position);

                        }

                    }

                }

			}

			if($tag->hasTag(WallGenerator::WALL_GENERATOR, StringTag::class)) {



				$event->setCancelled(true);



				if($player->getLevel()->getName() !== Faction::CLAIM_WORLD) {

					$player->sendMessage("§8§l(§c!§8) §r§7Wall Generators can only be used in your own faction claims.");

					return;

				}



				$type = $tag->getString(WallGenerator::WALL_TYPE);



				if($block->getId() !== Block::AIR) {

					$position = Position::fromObject($block->add(0, 1, 0), $player->getLevel());

					if($player->getLevel()->getBlock($position)->getId() === Block::AIR) {



						$factionManager = Elemental::getInstance()->getFactionManager();



						if($factionManager->getClaimInPosition($player) === null) {

							$player->sendMessage("§8§l(§c!§8) §r§7You can't use Wall Generators while not inside your own faction claims.");

							return;

						}



						if($factionManager->getClaimInPosition($player)->getFaction()->getName() == $player->getFaction()->getName()) {



							$inventory->setItemInHand($item->setCount($item->getCount() - 1));



							$faces = [

								0 => 4,

								1 => 2,

								2 => 5,

								3 => 3,

							];



							$face = $faces[$player->getDirection()];



							if($type == "Cobblestone"){

								$position->getLevel()->setBlock($position, Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 1, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 2, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 3, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 4, 0), Block::get(Block::COBBLESTONE, $face));

								//sleep(1);

								$position->getLevel()->setBlock($position->add(0, 5, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 6, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 7, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 8, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 9, 0), Block::get(Block::COBBLESTONE, $face));

								//sleep(1);

								$position->getLevel()->setBlock($position->add(0, 10, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 11, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 12, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 13, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 14, 0), Block::get(Block::COBBLESTONE, $face));

								//sleep(1);

								$position->getLevel()->setBlock($position->add(0, 15, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 16, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 17, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 18, 0), Block::get(Block::COBBLESTONE, $face));

								$position->getLevel()->setBlock($position->add(0, 19, 0), Block::get(Block::COBBLESTONE, $face));

								//sleep(1);

								$player->sendMessage("§8§l(§a!§8) §r§7Your wall has been successfully generated!");

							}

							if($type == "Obsidian"){

								$position->getLevel()->setBlock($position, Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 1, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 2, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 3, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 4, 0), Block::get(Block::OBSIDIAN, $face));

								//sleep(1);

								$position->getLevel()->setBlock($position->add(0, 5, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 6, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 7, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 8, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 9, 0), Block::get(Block::OBSIDIAN, $face));

								//sleep(1);

								$position->getLevel()->setBlock($position->add(0, 10, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 11, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 12, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 13, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 14, 0), Block::get(Block::OBSIDIAN, $face));

								//sleep(1);

								$position->getLevel()->setBlock($position->add(0, 15, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 16, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 17, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 18, 0), Block::get(Block::OBSIDIAN, $face));

								$position->getLevel()->setBlock($position->add(0, 19, 0), Block::get(Block::OBSIDIAN, $face));

								//sleep(1);

								$player->sendMessage("§8§l(§a!§8) §r§7Your wall has been successfully generated!");

							}



						} else {

							$player->sendMessage(Translation::getMessage("noPermission"));

							return;

						}

					}

				}



			}

        }

    }



    /**

     * @priority LOWEST

     * @param BlockBreakEvent $event

     */

    public function onBlockBreak(BlockBreakEvent $event): void

    {

        if ($event->isCancelled()) {

            return;

        }

        $item = $event->getItem();

        $player = $event->getPlayer();

        $block = $event->getBlock();

        if (!$player instanceof ElementalPlayer) {

            return;

        }

        $blockId = $block->getId();

        if (($level = $item->getEnchantmentLevel(Enchantment::FORTUNE)) > 0) {

            if (!in_array($blockId, $this->ids)) {

                return;

            }

            $id = 0;

            switch ($blockId) {

                case Block::COAL_ORE:

                    $id = Item::COAL;

                    break;

                case Block::DIAMOND_ORE:

                    $id = Item::DIAMOND;

                    break;

                case Block::EMERALD_ORE:

                    $id = Item::EMERALD;

                    break;

                case Block::REDSTONE_ORE:

                    $id = Item::REDSTONE;

                    break;

                case Block::LAPIS_ORE:

                    $id = Item::DYE;

                    break;

                case Block::NETHER_QUARTZ_ORE:

                    $id = Item::NETHER_QUARTZ;

                    break;

            }

            $item = Item::get($id, 0, 1 + mt_rand(0, $level + 2));

            if ($item->getId() === Item::DYE) {

                $item->setDamage(4);

                $item->setCount(2 + mt_rand(0, $level + 2) * 2);

            }

            $drops = [$item];

            $event->setDrops($drops);

        }

    }



    /**

     * @priority HIGHEST

     * @param EntityDamageEvent $event

     */

    public function onEntityDamage(EntityDamageEvent $event): void

    {

        if ($event->isCancelled()) {

            return;

        }

        if ($event instanceof EntityDamageByEntityEvent) {

            $damager = $event->getDamager();

            if (!$damager instanceof ElementalPlayer) {

                return;

            }

            $item = $damager->getInventory()->getItemInHand();

            /** @var Living $entity */

            $entity = $event->getEntity();

            if ($entity instanceof ElementalPlayer) {

                return;

            }

            if ($event->getFinalDamage() >= $entity->getHealth()) {

                foreach ($entity->getDrops() as $drop) {

                    $drop->setCount($drop->getCount() + mt_rand(1, $item->getEnchantmentLevel(Enchantment::LOOTING)));

                    $entity->getLevel()->dropItem($entity, $drop);

                }

            }

        }

    }



    /**

     * @priority HIGHEST

     * @param InventoryTransactionEvent $event

     */

    public function onInventoryTransaction(InventoryTransactionEvent $event)

    {

        $transaction = $event->getTransaction();

        foreach ($transaction->getActions() as $action) {

            if ($action instanceof SlotChangeAction) {

                $inventory = $action->getInventory();

                if ($action->getSourceItem()->hasEnchantments() or $action->getTargetItem()->hasEnchantments()) {

                    if ($inventory instanceof ArmorInventory) {

                        $holder = $inventory->getHolder();

                        if ($holder instanceof ElementalPlayer) {

                            $this->core->getScheduler()->scheduleDelayedTask(new class($holder) extends Task

                            {



                                /** @var ElementalPlayer */

                                private $player;



                                /**

                                 *  constructor.

                                 *

                                 * @param ElementalPlayer $player

                                 */

                                public function __construct(ElementalPlayer $player)

                                {

                                    $this->player = $player;

                                }



                                /**

                                 * @param int $currentTick

                                 */

                                public function onRun(int $currentTick)

                                {

                                    if ($this->player->isOnline()) {

                                        $this->player->setActiveArmorEnchantments();

                                    }

                                }

                            }, 1);

                        }

                        return;

                    }

                }

            }

        }

    }

}

