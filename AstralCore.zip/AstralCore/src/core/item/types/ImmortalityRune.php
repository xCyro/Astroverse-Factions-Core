<?php

declare(strict_types = 1);

namespace core\item\types;

use core\item\CustomItem;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class ImmortalityRune extends CustomItem {

    const RAMOUNT = "RAmount";

    /**
     * ImmortalityRune constructor.
     *
     * @param int $amount
     */
    public function __construct(int $amount) {
        $customName = TextFormat::RESET . TextFormat::LIGHT_PURPLE . TextFormat::BOLD . "Immortality Rune" . TextFormat::RESET . TextFormat::GRAY . " (Right Click)";
        $lore = [];
        $lore[] = "";
		$lore[] = "§7This powerful rune is able to protect you from death when activated so you can rule the §cWarzone§r";
		$lore[] = "";
		$lore[] = "§d§lEffects§5:§r";
		$lore[] = "  §d§l* §r§7You will not take damage while you are in the §cWarzone.§r";
		$lore[] = "  §d§l* §r§7Your attack damage will be decreased by §c0.25x§r";
		$lore[] = "  §d§l* §r§7This rune will be active for §c$amount seconds.§r";
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        $tag->setInt(self::RAMOUNT, $amount);
        parent::__construct(self::PRISMARINE_SHARD, $customName, $lore);
    }
}