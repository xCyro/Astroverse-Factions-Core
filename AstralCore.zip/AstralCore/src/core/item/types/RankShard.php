<?php

declare(strict_types = 1);

namespace core\item\types;

use core\item\CustomItem;
use pocketmine\nbt\tag\CompoundTag;
use core\rank\Rank;
use pocketmine\utils\TextFormat;

class RankShard extends CustomItem {

	const RANK = "Rank";

    /**
     * RankShard constructor.
     *
     * @param string $rank
     */
    public function __construct(string $rank) {
		$customName = "§r§3§l$rank §r§b§lRank Shard";
        $lore = [];
        $lore[] = "";
		$lore[] = "§7Gain access to the §b$rank §r§7Rank and ALL\nperks that are givin with the Rank!";
		$lore[] = "";
		$lore[] = "§f§lRank Information§7:";
		$lore[] = "§b§f* §r§7Rank Type: §b§lPermanent§r";
		$lore[] = "";
		$lore[] = "§c§lWarning: §r§7This item can only be used ONCE\nand is not able to be Refunded if lost";
		$lore[] = "";
		$lore[] = "§eTap anywhere to redeem this rank shard.";
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        $tag->setString(self::RANK, $rank);
        parent::__construct(self::PRISMARINE_SHARD, $customName, $lore);
    }
}