<?php

declare(strict_types = 1);

namespace core\item\types;

use core\item\CustomItem;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class KothFlare extends CustomItem {

    const KOTH = "Koth";

    /**
     * KothFlare constructor.
     *
     * @param int $amount
     */
    public function __construct(int $amount) {
        $customName = "§c§lK§6.§eO§a.§bT§5.§dH §cFlare";
        $lore = [];
        $lore[] = "";
		$lore[] = "§7Right Click this flare to instantly start a koth.";
		$lore[] = "";
		$lore[] = "§c§lWARNING: Don't use if theres a koth currently running.";
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        $tag->setInt(self::KOTH, $amount);
        parent::__construct(self::DYE, $customName, $lore);
    }
}