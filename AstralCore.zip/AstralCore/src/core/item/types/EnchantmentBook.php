<?php

declare(strict_types = 1);

namespace core\item\types;

use core\item\CustomItem;
use core\item\ItemManager;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class EnchantmentBook extends CustomItem {

    const ENCHANTMENT = "Enchantment";

    /**
     * EnchantmentBook constructor.
     *
     * @param Enchantment $enchantment
     */
    public function __construct(Enchantment $enchantment) {
		$enchantments = ItemManager::getEnchantments();
		//if($enchantment instanceof Enchantment and (!in_array($enchantment->getId(), $enchantments))) {
		$customName = TextFormat::RESET . TextFormat::DARK_PURPLE . TextFormat::BOLD . "{$enchantment->getName()} " . TextFormat::RESET  . TextFormat::GRAY . "Enchantment book";
		$lore = [];
		$lore[] = "";
		$lore[] = "§r§7Drag and drop onto your item to enchant\n§r§7Execute §b/ceinfo §r§7for more information";
		$lore[] = "";
		//$lore[] = "§r§bApplicable items: §r§7" . ItemManager::flagToString($enchantment->getPrimaryItemFlags());
		//$lore[] = "§r§bRarity: §r§7" . ItemManager::rarityToString($enchantment->getRarity());
		//$lore[] = "§r§bMax level: §r§7" . $enchantment->getMaxLevel();
		//$lore[] = "";
		//} else {
		//$customName = TextFormat::RESET . TextFormat::DARK_PURPLE . TextFormat::BOLD . "{$enchantment->getName()} " . TextFormat::RESET  . TextFormat::GRAY . "Enchantment book";
		//$lore = [];
		//$lore[] = "";
		//$lore[] = "§r§bVanilla Enchantment";
		//$lore[] = "";
		//}
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        $tag->setInt(self::ENCHANTMENT, $enchantment->getId());
        $tag->setString("UniqueId", uniqid());
        parent::__construct(self::ENCHANTED_BOOK, $customName, $lore);
    }

    public function getMaxStackSize(): int{
        return 1;
    }
}
