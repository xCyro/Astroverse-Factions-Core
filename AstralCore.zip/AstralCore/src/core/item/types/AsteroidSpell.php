<?php

declare(strict_types = 1);

namespace core\item\types;

use core\item\CustomItem;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class AsteroidSpell extends CustomItem {

    const SPELL_ASTEROID = "AsteroidSpell";

    /**
     * AsteroidSpell constructor.
     *
     * @param int $amount
     */
    public function __construct() {
        $customName = TextFormat::RESET . "§cA§4s§ct§4e§cr§4o§ci§4d §cSpell" . TextFormat::RESET . TextFormat::GRAY . " (Right Click)";
        $lore = [];
        $lore[] = "";
		$lore[] = "§7When you feel endangered use this\n§cA§4s§ct§4e§cr§4o§ci§4d §cSpell §r§7to blast through the sky\nand attempt to escape your enemy.";
		//$lore[] = "";
		//$lore[] = "§7Right-Click to use the §cA§4s§ct§4e§cr§4o§ci§4d's §cSpell";
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        $tag->setString(self::SPELL_ASTEROID, "AsteroidSpell");
        parent::__construct(self::PRISMARINE_CRYSTALS, $customName, $lore);
    }
}