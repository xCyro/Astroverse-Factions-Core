<?php

declare(strict_types=1);

namespace core\item\types;

use core\item\CustomItem;
use core\ElementalPlayer;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class ZombieHead extends CustomItem {

	const ZOMBIE = "Zombie";

	/**
	 * ZombieHead constructor.
	 *
	 * @param ElementalPlayer $player
	 */
	public function __construct(){
		$customName = "§2§lZombie §r§7Head§r";
		$lore = [];
		$lore[] = TextFormat::RESET . TextFormat::YELLOW . "Tap anywhere to redeem.";
		$this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
		/** @var CompoundTag $tag */
		$tag = $this->getNamedTagEntry(self::CUSTOM);
		$tag->setString(self::ZOMBIE, "ZombieHead");
		$tag->setInt("MoneyE", 5);
		parent::__construct(self::MOB_HEAD, $customName, $lore, [], [], 2);
	}
}