<?php

declare(strict_types = 1);

namespace core\item\types;

use core\item\CustomItem;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class MoneyPouch extends CustomItem {

	const MONEY = "Money";
	//const TIER = "Tier";

    /**
     * MoneyPouch constructor.
     *
     * @param int $amount
	 * @param int $tier
     */
    public function __construct(int $amount) {
		$tier = 0;
		if($amount > 50000){
			$tier = 1;
		}
		if($amount > 100000){
			$tier = 2;
		}
		if($amount > 500000){
			$tier = 3;
		}
		if($amount > 1000000){
			$tier = 4;
		}
		if($amount > 2500000){
			$tier = 5;
		}
        $customName = TextFormat::RESET . TextFormat::GREEN . TextFormat::BOLD . "Money Pouch" . TextFormat::RESET . TextFormat::DARK_GRAY . " [" . TextFormat::GOLD . TextFormat::BOLD . $tier . TextFormat::RESET . TextFormat::DARK_GRAY . "]";
        $lore = [];
        $lore[] = "";
		$lore[] = "§bUncover this Money Pouch to gain either a huge fortune or nothing at all";
		$lore[] = "";
		$lore[] = "§8§l* §r§bTier§3: §b$tier";
		$lore[] = "§8§l* §r§bAmount§3: §b0 §8- §b$amount";
		$lore[] = "";
		$lore[] = "§eTap any where to uncover this pouch";
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        $tag->setInt(self::MONEY, $amount);
        parent::__construct(self::ENDER_CHEST, $customName, $lore);
    }
}