<?php

declare(strict_types = 1);

namespace core\item\types;

use core\item\CustomItem;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class SoulsBottle extends CustomItem {

	const SOULSBOTTLE = "SoulsBottle";
	const SOULSBOTTLEAMOUNT = "SoulBottleAmount";

    /**
     * SoulsBottle constructor.
     */
    public function __construct($amount) {
        $customName = "§l§5§kiii§r§d§l Souls Bottle §r§l§5§kiii§r";
        $lore = [];
        $lore[] = "";
        $lore[] = "§7This bottle contains the §b$amount §r§7souls\nof the dead...\n\n§bRight-Click to use.§r";
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        $tag->setString(self::SOULSBOTTLE, self::SOULSBOTTLE);
        $tag->setInt(self::SOULSBOTTLEAMOUNT, $amount);
        parent::__construct(self::DRAGON_BREATH, $customName, $lore);
    }
}
