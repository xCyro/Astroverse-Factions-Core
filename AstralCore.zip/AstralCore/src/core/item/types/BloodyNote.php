<?php

declare(strict_types = 1);

namespace core\item\types;

use core\item\CustomItem;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class BloodyNote extends CustomItem {

    const MAMOUNT = "MAmount";

    /**
     * BloodyNote constructor.
     *
     * @param int $amount
     */
    public function __construct(int $amount) {
        $customName = TextFormat::RESET . TextFormat::RED . TextFormat::BOLD . "Bloody Note" . TextFormat::RESET . TextFormat::GRAY . " (Right Click)";
        $lore = [];
        $lore[] = "";
		$lore[] = "§3Uncover this Bloody Note to gain either a small fortune or nothing at all";
		$lore[] = "";
		$lore[] = "§b§l* Note Worth: §k$amount §r";
		$lore[] = "";
		$lore[] = "§eTap to uncover this Bloody Note";
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        $tag->setInt(self::MAMOUNT, $amount);
        parent::__construct(self::PAPER, $customName, $lore);
    }
}