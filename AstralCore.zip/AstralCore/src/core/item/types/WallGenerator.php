<?php

namespace core\item\types;

use core\item\CustomItem;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class WallGenerator extends CustomItem
{
	const WALL_GENERATOR = "WallGenerator";
	const WALL_TYPE = "WallType";

    /**
     * WallGenerator constructor.
     */
    public function __construct($type) {

        $customName = "§l§f$type §0Wall Generator";
		$lore = [];
		$lore[] = "\n§7Use this to make walls.. yeah\nPerfect for making §0wall §7bases.\nMake sure to put water!\n\n§bRight-Click to use.§r";
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
		$tag->setString(self::WALL_GENERATOR, self::WALL_GENERATOR);
		$tag->setString(self::WALL_TYPE, $type);
		if($type == "Cobblestone"){
			parent::__construct(self::COBBLESTONE, $customName, $lore);
			return;
		}
		if($type == "Obsidian"){
			parent::__construct(self::OBSIDIAN, $customName, $lore);
			return;
		} else {
			return;
		}
        //parent::__construct(self::NULL, $customName, $lore);
    }
}
