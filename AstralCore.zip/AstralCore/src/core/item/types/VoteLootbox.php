<?php

declare(strict_types = 1);

namespace core\item\types;

use core\item\CustomItem;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class VoteLootbox extends CustomItem {

    const VLOOTBOX = "VoteLootBox";

    /**
     * VoteLootBox constructor.
     */
    public function __construct() {
        $customName = "§3§l*§b*§3* §bVote Lootbox §3*§b*§3*§r";
        $lore = [];
        $lore[] = "";
        $lore[] = TextFormat::RESET . TextFormat::GREEN . TextFormat::BOLD . "Possible rewards:";
        $lore[] = TextFormat::RESET . TextFormat::WHITE .  TextFormat::BOLD . " * " . TextFormat::RESET . TextFormat::GRAY . "Special Box";
        $lore[] = TextFormat::RESET . TextFormat::WHITE .  TextFormat::BOLD . " * " . TextFormat::RESET . TextFormat::GRAY . "Enchantment Book";
        $lore[] = TextFormat::RESET . TextFormat::WHITE .  TextFormat::BOLD . " * " . TextFormat::RESET . TextFormat::GRAY . "Artifact";
        $lore[] = TextFormat::RESET . TextFormat::WHITE .  TextFormat::BOLD . " * " . TextFormat::RESET . TextFormat::GRAY . "Lucky Block";
        $lore[] = TextFormat::RESET . TextFormat::WHITE .  TextFormat::BOLD . " * " . TextFormat::RESET . TextFormat::GRAY . "Sell Wand";
        $lore[] = TextFormat::RESET . TextFormat::WHITE .  TextFormat::BOLD . " * " . TextFormat::RESET . TextFormat::GRAY . "Money";
		$lore[] = TextFormat::RESET . TextFormat::WHITE .  TextFormat::BOLD . " * " . TextFormat::RESET . TextFormat::GRAY . "Crate Keys";
		$lore[] = "§r§f§l * §r§7Koth Flare";
		$lore[] = "§r§f§l * §r§7Bloody Note";
		$lore[] = "§r§f§l * §r§7Money Pouch";
        $lore[] = "";
        $lore[] = TextFormat::RESET . TextFormat::AQUA . "Tap anywhere to claim your Lootbox.";
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        $tag->setString(self::VLOOTBOX, "VLootBox");
        parent::__construct(self::BEACON, $customName, $lore);
    }
}
