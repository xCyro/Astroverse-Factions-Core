<?php

declare(strict_types = 1);

namespace core\item\types;

use core\item\CustomItem;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class EnchantmentScroll extends CustomItem {

	const EnchantmentScroll = "EnchantmentScroll";
	const EScrollAmount = "EScrollAmount";

    /**
     * EnchantmentScroll constructor.
     *
     * @param int $amount
	 * @param int $tier
     */
    public function __construct(int $amount = 14) {

        $customName = "§5§l§kiii§r§d§l Enchantment Scroll §5§l§kiii§r";
        $lore = [];
        $lore[] = "";
		$lore[] = "§dForge this enchantment scroll with an item to\nhack the system and gain a higher enchantment limit!";
		$lore[] = "";
		$lore[] = "§r§5Enchantments: §d$amount";
		$lore[] = "";
		$lore[] = "§dApply this to your item by forging it.";
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
		$tag = $this->getNamedTagEntry(self::CUSTOM);
		$tag->setInt(self::EScrollAmount, $amount);
		$tag->setString(self::EnchantmentScroll, "EnchantmentScroll");
        parent::__construct(self::ENDER_EYE, $customName, $lore);
    }
}