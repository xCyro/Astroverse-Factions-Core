<?php

namespace core\item\types;

use core\item\CustomItem;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class CreeperEgg extends CustomItem
{
    const CREEPER_EGG = "CreeperEgg";

    /**
     * CreeperEgg constructor.
     */
    public function __construct() {
        $customName = "§a§lCreeper Egg§r";
		$lore = [];
		$lore[] = "\n§7Hello there, im a creeper.\nOh sorry you thought i am?\nIm just an creeper egg\nand when you tap me i create\na VERY big explosion.\nso jokes on you.\n\n§bRight-Click to use.§r";
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        $tag->setString(self::CREEPER_EGG, self::CREEPER_EGG);
        parent::__construct(383, $customName, $lore);
    }
}
