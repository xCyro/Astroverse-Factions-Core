<?php

declare(strict_types = 1);

namespace core\item\types;

use core\item\CustomItem;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class NitroGem extends CustomItem {

    const NITRO_GEM = "NitroGem";

    /**
     * NitroGem constructor.
     */
    public function __construct() {
        $customName = "§d§lNitro §aGem§r";
        $lore = [];
        $lore[] = "";
        $lore[] = "§dYou receive this gem when boosting our discord server§r";
        $lore[] = "§a§lRewards§2:§r";
        $lore[] = " §2§l* §r§7100,000 Money§r";
        $lore[] = " §2§l* §r§7Nitro Booster Rank§r";
        $lore[] = " §2§l* §r§7Artifact x1§r";
        $lore[] = " §2§l* §r§7Astronomic Key x1§r";
        $lore[] = "";
        $lore[] = "§aTap anywhere to claim your nitro gem!";
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        $tag->setString(self::NITRO_GEM, self::NITRO_GEM);
        $tag->setString("UniqueId", uniqid());
        parent::__construct(self::EMERALD, $customName, $lore);
    }
}
