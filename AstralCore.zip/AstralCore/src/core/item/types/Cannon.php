<?php

declare(strict_types=1);

namespace core\item\types;

use core\item\CustomItem;
use core\ElementalPlayer;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class Cannon extends CustomItem{

    const PLAYER = "Player";
    public const CANON_META = 3;

    /**
     * Head constructor.
     *
     * @param ElementalPlayer $player
     */
    public function __construct(){
        $customName = TextFormat::BOLD . TextFormat::LIGHT_PURPLE . "Cannon";
        $lore = [];
        $lore[] = "";
		$lore[] = TextFormat::RED . "Place down to summon a Portable Cannon of the artistic war!";
		$lore[] = "";
		$lore[] = "§8[§c§lINCOMPLETE§r§8]§r";
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        parent::__construct(self::HORSE_ARMOR_DIAMOND, $customName, $lore, [], [], 3);
    }
}
