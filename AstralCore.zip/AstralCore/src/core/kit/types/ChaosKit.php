<?php

declare(strict_types = 1);

namespace core\kit\types;

use core\item\CustomItem;
use core\item\enchantment\Enchantment;
use core\kit\Kit;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;

class ChaosKit extends Kit {

	/**
     * Artis constructor.
     */
    public function __construct() {
     
        $name = "§l§1AS§bTER§3OPE§r ";
        $items =  [
            (new CustomItem(Item::DIAMOND_HELMET, $name . "§r§7Helmet§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 10),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EVADE), 4),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::NOURISH), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::IMMUNITY), 3),
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_CHESTPLATE, $name . "§r§7Chestplate§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 10),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EVADE), 4),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::NOURISH), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::IMMUNITY), 3),
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_LEGGINGS, $name . "§7§r§7Leggings§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 10),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EVADE), 4),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::NOURISH), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::IMMUNITY), 3),
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_BOOTS, $name . "§r§7Boots§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 10),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EVADE), 4),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::GEARS), 3),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::HOPS), 3),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::NOURISH), 5),
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_SWORD, $name . "§r§7Sword§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 16),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::BLEED), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::ANNIHILATION), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FLING), 2),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::RAGE), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::VAMPIRE), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::MONOPOLIZE), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::LIFESTEAL), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::LEVIOPARD), 3),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::CLOVERINE), 4),
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_SHOVEL, $name . "§r§7Shovel§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 8),
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 5),
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_PICKAXE, $name . "§r§7Pickaxe§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 19),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::AMPLIFY), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::CHARM), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::JACKPOT), 3),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::HASTE), 3),
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_AXE, $name . "§r§7Axe", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 9),
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 8),
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 5),
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_HOE, $name . "§r§7Hoe§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 8),
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 5),
            ]))->getItemForm(),
            Item::get(Item::STEAK, 0, 64),
            Item::get(Item::ENCHANTED_GOLDEN_APPLE, 0, 64),
            Item::get(Item::OBSIDIAN, 0, 256)
            
        ];
        parent::__construct("Asterope", self::MYTHIC, $items, 21600);
    }
}
