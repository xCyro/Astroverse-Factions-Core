<?php

declare(strict_types = 1);

namespace core\kit\types;

use core\item\CustomItem;
use core\kit\Kit;
use core\item\enchantment\Enchantment;
//use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;

class ErosKit extends Kit {

    /**
     * Mystic constructor.
     */
    public function __construct() {
        $name = "§l§9A§bL§3P§bH§9A§r ";
        $random = mt_rand(8,13);
        $items =  [
            (new CustomItem(Item::DIAMOND_HELMET, $name . "§r§7Helmet§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 10),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 10),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::IMMUNITY), 2),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EVADE), 1),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::NOURISH), 5),
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_CHESTPLATE, $name . "§r§7Chestplate§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 10),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 10),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::IMMUNITY), 2),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EVADE), 1),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::NOURISH), 5),
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_LEGGINGS, $name . "§r§7Leggings§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 10),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 10),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::IMMUNITY), 2),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EVADE), 1),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::NOURISH), 5),
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_BOOTS, $name . "§r§7Boots§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 10),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 10),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::GEARS), 4),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EVADE), 1),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::HOPS), 2),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::IMMUNITY), 2),
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_SWORD, $name . "§r§7Sword§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), $random),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 10),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::BLEED), 5),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::ANNIHILATION), 3),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::RAGE), 4),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::LEVIOPARD), 3),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::CLOVERINE), 3)
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_SHOVEL, $name . "§r§7Shovel§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 16),
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 10),
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_PICKAXE, $name . "§r§7Pickaxe§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 16),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 10),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::CHARM), 3),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::HASTE), 3),
				new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::JACKPOT), 1)
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_AXE, $name . "§r§7Axe§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), $random),
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 8),
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 10),
            ]))->getItemForm(),
            (new CustomItem(Item::DIAMOND_HOE, $name . "§r§7Hoe§r", [], [
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 8),
                new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 5),
            ]))->getItemForm(),
            Item::get(Item::STEAK, 0, 64),
			Item::get(Item::ENCHANTED_GOLDEN_APPLE, 0, 64),
			Item::get(Item::TNT, 0, 256),
			Item::get(Item::OBSIDIAN, 0, 256),
			Item::get(Item::BEDROCK, 0, 128),
        ];
        parent::__construct("Alpha", self::RARE, $items, 21600);
    }
}
