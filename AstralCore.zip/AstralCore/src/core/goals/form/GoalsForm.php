<?php

namespace core\goals\form;

use core\Elemental;
use core\ElementalListener;
use core\ElementalPlayer;
use core\libs\form\MenuForm;
use core\libs\form\MenuOption;
use core\translation\Translation;
use pocketmine\entity\Skin;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class GoalsForm extends MenuForm
{
    public function __construct()
    {
        $title = TextFormat::LIGHT_PURPLE.TextFormat::BOLD."Community Goals";
        $text = "".TextFormat::RESET;
		$options[] = new MenuOption("§c§lTnT§r");
		$options[] = new MenuOption("§c§lN§4e§ct§4h§ce§4r§r");
        parent::__construct($title, $text, $options);
    }

    public function onSubmit(Player $player, int $selectedOption): void
    {
        if (!$player instanceof ElementalPlayer) {
            return;
		}
		
		$option = $this->getOption($selectedOption)->getText();

	}
}