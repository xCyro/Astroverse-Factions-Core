<?php

namespace core\goals\form\tnt;

use core\Elemental;
use core\ElementalListener;
use core\ElementalPlayer;
use core\libs\form\CustomForm;
use core\libs\form\CustomFormResponse;
use core\translation\Translation;
use pocketmine\entity\Skin;
use pocketmine\Player;
use core\libs\form\element\Dropdown;
use core\libs\form\element\Input;
use core\libs\form\element\Label;
use pocketmine\utils\TextFormat;

class TnTGoalForm extends CustomForm
{

    public function __construct()
    {

		$zero = 0;

		$this->needed = 5000000;
        $title = TextFormat::LIGHT_PURPLE.TextFormat::BOLD."TnT Goal";
		$elements = [];

		$stmt = Elemental::getInstance()->getMySQLProvider()->getDatabase()->prepare("SELECT tntGoal FROM server");
		$stmt->execute();
		$stmt->bind_result($donated);
		$stmt->fetch();
		$stmt->close();

		if($donated == null)
		{

			$stmt = Elemental::getInstance()->getMySQLProvider()->getDatabase()->prepare("INSERT INTO server(tntGoal) VALUES(?)");
			$stmt->bind_param("s", $zero);
			$stmt->execute();
			$stmt->close();

		} 

		$elements[] = new Label("Information", "§e" . $donated . "§r§8/§e" . $this->needed);
		$elements[] = new Input("Amount", "§7How much would you like to donate?");
        parent::__construct($title, $elements);
    }

    public function onSubmit(Player $player, CustomFormResponse $data): void
    {
        if (!$player instanceof ElementalPlayer) {
            return;
		}

		$amount = $data->getString("Amount");

		if(!is_numeric($amount)) {

            $player->sendMessage(Translation::getMessage("invalidAmount"));

            return;

        }

        $amount = (int)$amount;

        if($amount <= 0) {

            $player->sendMessage(Translation::getMessage("invalidAmount"));

            return;

		}
		
		$balance = $player->getBalance();

		if($amount > $balance)
		{

			$player->sendMessage(Translation::getMessage("invalidAmount"));

			return;

		}

		$player->subtractFromBalance($amount);

		$stmt = Elemental::getInstance()->getMySQLProvider()->getDatabase()->prepare("SELECT tntGoal FROM server");
		$stmt->execute();
		$stmt->bind_result($donated);
		$stmt->fetch();
		$stmt->close();

		if($donated >= 5000000)
		{

			$player->sendMessage("§a§lAeryn §r§8| §r§7This goal has already been achieved!");

			return;

		}

		$stmt = Elemental::getInstance()->getMySQLProvider()->getDatabase()->prepare("UPDATE server SET tntGoal = tntGoal + ?");
		$stmt->bind_param("s", $amount);
		$stmt->execute();
		$stmt->close();

	}
}