<?php

declare(strict_types=1);

namespace core\goals;

use core\Elemental;
use pocketmine\event\Listener;

class GoalsManager implements Listener
{

	public function __construct()
	{

		Elemental::getInstance()->getPluginManager()->registerEvents($this, $this);

	}

}
