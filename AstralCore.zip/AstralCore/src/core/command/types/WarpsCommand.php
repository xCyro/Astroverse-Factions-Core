<?php

declare(strict_types = 1);

namespace core\command\types;

use core\command\task\TeleportTask;
use core\command\menus\WarpsMenu;
use core\command\utils\Command;
use core\ElementalPlayer;
use core\Elemental;
use core\ElementalListener;
use core\translation\Translation;
use core\translation\TranslationException;
use pocketmine\command\CommandSender;

class WarpsCommand extends Command {

    /**
     * WarpsCommand constructor.
     */
    public function __construct() {
		parent::__construct("warps", "Warp to an area.", "/warp", ["warp"]);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     *
     * @throws TranslationException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if($sender instanceof ElementalPlayer) {

			$menu = new WarpsMenu($sender);

			$menu->sendMenu();

            return;
        }
        $sender->sendMessage(Translation::getMessage("noPermission"));
        return;
    }
}