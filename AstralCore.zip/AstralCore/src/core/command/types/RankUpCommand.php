<?php

declare(strict_types = 1);

namespace core\command\types;

use core\command\utils\Command;
use core\ElementalPlayer;
use core\rank\Rank;
use core\item\types\RankShard;
use core\translation\Translation;
use core\translation\TranslationException;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;

class RankUpCommand extends Command {

    /**
     * RankUpCommand constructor.
     */
    public function __construct() {
        parent::__construct("rankup", "Rank up", "/rankup", ["ru"]);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     *
     * @throws TranslationException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if(!$sender instanceof ElementalPlayer) {
            $sender->sendMessage(Translation::getMessage("noPermission"));
            return;
        }
        $rank = $sender->getRank();
        switch($rank->getIdentifier()) {
            case Rank::ASTRONAUT:
                $price = 200000;
                $rankId = Rank::ASTER;
                break;
            case Rank::ASTER:
                $price = 1000000;
                $rankId = Rank::SIRIUS;
                break;
            case Rank::SIRIUS:
                $price = 5000000;
                $rankId = Rank::ARPINA;
                break;
            case Rank::ARPINA:
                $price = 20000000;
                $rankId = Rank::AURORA;
                break;
            default:
                if(!$sender->hasPermission("permission.starter")) {
                    $price = 200000;
                    $permission = "permission.aster";
                }
                elseif(!$sender->hasPermission("permission.aster")) {
                    $price = 1000000;
                    $permission = "permission.sirius";
                }
                elseif(!$sender->hasPermission("permission.sirius")) {
                    $price = 5000000;
                    $permission = "permission.arpina";
                }
                elseif(!$sender->hasPermission("permission.arpina")) {
                    $price = 20000000;
                    $permission = "permission.aurora";
                }
                else {
                    $price = null;
                    $permission = null;
                }
        }
        if((!isset($price)) or $price === null) {
            $sender->sendMessage(Translation::getMessage("maxRank"));
            return;
        }
        if($price > $sender->getBalance()) {
            $sender->sendMessage(Translation::getMessage("notEnoughMoneyRankUp", [
                "amount" => TextFormat::RED . "$$price"
            ]));
            return;
        }
        if(isset($rankId)) {
            $sender->subtractFromBalance($price);
            $sender->setRank(($rank = $sender->getCore()->getRankManager()->getRankByIdentifier($rankId)));
            $this->getCore()->getServer()->broadcastMessage(Translation::getMessage("rankUp", [
                "name" => TextFormat::AQUA . $sender->getName(),
                "rank" => TextFormat::YELLOW . $rank->getName()
            ]));
        }
        elseif(isset($permission)) {
            $sender->subtractFromBalance($price);
            $sender->getSession()->addPermissions((string)$permission);
            $rank = ucfirst(explode(".", $permission)[1]);
            $this->getCore()->getServer()->broadcastMessage(Translation::getMessage("rankUp", [
                "name" => TextFormat::AQUA . $sender->getName(),
                "rank" => TextFormat::YELLOW . $rank
            ]));
        }
        else {
            $sender->sendMessage(Translation::getMessage("errorOccurred"));
        }
    }
}
