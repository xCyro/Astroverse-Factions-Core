<?php

declare(strict_types = 1);

namespace core\command\types;

use core\command\utils\Command;
use core\Elemental;
use core\ElementalPlayer;
use core\discord\DiscordManager;
use core\translation\Translation;
use core\translation\TranslationException;
use pocketmine\command\CommandSender;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class EventCommand extends Command {

    /**
     * EventCommand constructor.
     */
    public function __construct() {
        parent::__construct("event", "Start or End an event!", "/event <start/end> <type>");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     *
     * @throws TranslationException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if(!$sender->isOp()) {
            $sender->sendMessage(Translation::getMessage("noPermission"));
            return;
        }

        $webhook = "776161736859713547/Q3e0bXU4Hek7pq6ASX-dxqxwBH6HBJmYiTsitggAoObU2JHAi0_V-56MAfxLMA3FO4wo";

        if(isset($args[0])){

            if($args[0] == "start")
            {

                if(isset($args[1]))
                {

                    if($args[1] == "asteroid")
                    {

                        $factionListener = Elemental::getInstance()->getFactionListener();

                        $factionListener->setAsteroidStrikeKills(0);

                        $sender->sendMessage("§b§lAstral §r§8| §r§7You have started the §cMeteorite §7event!");

                        Elemental::getInstance()->getServer()->broadcastMessage("\n§8§l(§b!§8) §r§7The §cA§4s§ct§4e§cr§4o§ci§4d §r§cStrike §r§7event has just begun! Everyone will now gain 50 faction power and $50,000 per kill while near the asteroid! This event will last until 1000 faction power is given away!\n\n");

                        Elemental::getInstance()->getServer()->broadcastTitle("§cA§4s§ct§4e§cr§4o§ci§4d §cStrike");
    
                        //DiscordManager::postWebhook($webhook, "@Events", "Astrobaut");
    
                        DiscordManager::postWebhook($webhook, "@Events", "Astrobaut", [
    
                            [
    
                                "color" => 0xFF0004,
    
                                "title" => "THE ASTEROID STRIKE EVENT HAS BEGUN",
    
                                "description" => "Hello there fellow astronauts! An asteroid has struck the planet!\nGet your faction ready and use the asteroid's power to earn **50** faction power and $50,000 power per kill!\n\nJoin now with the following information:\n\n**IP**: astralmc.ml\n**PORT**: 19132 (Default)"
    
                            ]
    
                        ]);

                        $factionListener->setAstroidEventStatus(true);

                    }

                } else {

                    $sender->sendMessage(Translation::getMessage("usageMessage", [
                        "usage" => $this->getUsage()
                    ]));

                    return;

                }

                return;

            }

            if($args[0] == "end")
            {

                $sender->sendMessage("incomplete - turnaizy");

                return;

            }

        } else {
            $sender->sendMessage(Translation::getMessage("usageMessage", [
                "usage" => $this->getUsage()
            ]));
        }
    }
}
