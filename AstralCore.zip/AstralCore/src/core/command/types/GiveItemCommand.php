<?php

declare(strict_types = 1);

namespace core\command\types;

use core\command\utils\Command;
use core\item\types\BossEgg;
use core\item\types\HolyBox;
use core\item\types\MoneyPouch;
use core\item\types\BloodyNote;
use core\item\types\KothFlare;
use core\item\types\RankShard;
use core\item\types\VoteLootbox;
use core\item\types\ImmortalityRune;
use core\item\types\AsteroidSpell;
use core\item\types\TNTLauncher;
use core\item\types\EnchantmentScroll;
use core\item\types\SoulsBottle;
use core\item\types\NitroGem;
use core\ElementalPlayer;
use core\translation\Translation;
use core\translation\TranslationException;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;

class GiveItemCommand extends Command {

    /**
     * GiveItemCommand constructor.
     */
    public function __construct() {
        parent::__construct("giveitem", "Give item to a player.", "/giveitem <player> <item>");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     *
     * @throws TranslationException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (($sender instanceof ElementalPlayer && $sender->isOp()) || $sender instanceof ConsoleCommandSender) {
            if(!isset($args[1])) {
                $sender->sendMessage(Translation::getMessage("usageMessage", [
                    "usage" => $this->getUsage()
                ]));
                return;
            }
            $player = $this->getCore()->getServer()->getPlayer($args[0]);
            if(!$player instanceof ElementalPlayer) {
                $sender->sendMessage(Translation::getMessage("invalidPlayer"));
                return;
            }
            switch($args[1]) {
                case "artisticbox":
                    if(!isset($args[2])) {
                        $kits = $this->getCore()->getKitManager()->getSacredKits();
                        $kit = $kits[array_rand($kits)];
                    }
                    else {
                        $kit = $this->getCore()->getKitManager()->getKitByName($args[2]);
                    }
                    if($kit === null) {
                        $sender->sendMessage(Translation::getMessage("invalidKit"));
                    }
                    $player->getInventory()->addItem((new HolyBox($kit))->getItemForm());
                    $sender->sendMessage("§l§8(§a!§8)§r §7You received a Artistic Box!");
                    break;
                case "kit":
                    if(!isset([$args[2]]))
                    {

                        $kits = $this->getCore()->getKitManager()->getKits();
                        $kit = $kits[array_rand($kits)];

                    }
                    break;
				case "moneypouch":
					if($args[2] === null){
						return;
					};
					$player->getInventory()->addItem((new MoneyPouch((int)$args[2]))->getItemForm());
					return;
					break;
				case "bloodynote":
					if($args[2] === null){
						return;
					}
					$player->getInventory()->addItem((new BloodyNote((int)$args[2]))->getItemForm());
					break;
				case "kothflare":
					if($args[2] === null){
						return;
					}
					$player->getInventory()->addItem((new KothFlare((int)$args[2]))->getItemForm());
					return;
					break;
				case "rankshard":
					if($args[2] === null){
						return;
					}
					$player->getInventory()->addItem((new RankShard($args[2]))->getItemForm());
					return;
					break;
				case "votelootbox":
					if($args[2] === null){
						return;
					}
					$player->getInventory()->addItem((new VoteLootbox())->getItemForm());
					return;
					break;
				case "immortalityrune":
					if($args[2] === null){
						return;
					}
					$player->getInventory()->addItem((new ImmortalityRune((int)$args[2]))->getItemForm());
					return;
					break;
				case "asteroidspell":
					if($args[2] === null) {
						return;
					}
					$player->getInventory()->addItem((new AsteroidSpell())->getItemForm());
					return;
					break;
				case "tntlauncher":
					if($args[2] === null || $args[3] === null) {
						return;
					}
					$player->getInventory()->addItem((new TNTLauncher((int)$args[2], (int)$args[3]))->getItemForm());
					return;
					break;
				case "enchantmentscroll":
					if($args[2] === null) {
						return;
					}
					$player->getInventory()->addItem((new EnchantmentScroll((int)$args[2]))->getItemForm());
					return;
                    break;
                case "soulsbottle":
                    if($args[2] === null) {
                        return;
                    }
                    $player->getInventory()->addItem((new SoulsBottle((int)$args[2]))->getItemForm());
                    return;
                    break;
                case "nitrogem":
                    if($args[2] === null)
                    {
                        return;
                    }
                    $player->getInventory()->addItem((new NitroGem((int)$args[2]))->getItemForm());
                    return;
                    break;
                case "boss": 
                    if(!isset($args[2])) {
                        $sender->sendMessage(Translation::getMessage("usageMessage", [
                            "usage" => "/giveitem <player> boss <type>"
                        ]));
                        return;
                    }
                    $boss = $this->getCore()->getCombatManager()->getBossNameByIdentifier((int)$args[2]);
                    if($boss === null) {
                        $sender->sendMessage(Translation::getMessage("invalidBoss"));
                        return;
                    }
                    $boss = $this->getCore()->getCombatManager()->getIdentifierByName($boss);
                    $player->getInventory()->addItem((new BossEgg($boss))->getItemForm());
                    $sender->sendMessage("§l§8(§a!§8)§r §7You received a boss egg!");
                    break;
                default:
                    //$types = ["artisticbox", "boss", "kit"];
                    $sender->sendMessage("§l§8(§c!§8)§r §7Unknown item: $args[1]");
                    //$sender->sendMessage("§l§8(§c!§8)§r §7Available items:§r"." ".implode("§r, ", $types));
                    break;
            }
            return;
        }
        $sender->sendMessage(Translation::getMessage("noPermission"));
    }
}