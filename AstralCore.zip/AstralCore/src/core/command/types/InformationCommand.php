<?php

declare(strict_types = 1);

namespace core\command\types;

use core\command\utils\Command;
use core\command\forms\InformationForm;
use core\ElementalPlayer;
use core\translation\Translation;
use core\translation\TranslationException;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;

class InformationCommand extends Command {

    /**
     * InformationCommand constructor.
     */
    public function __construct() {
        parent::__construct("information", "Gain information about the Astroverse.", "/information", ["info", "how", "howtoplay"]);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     *
     * @throws TranslationException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if(!$sender instanceof ElementalPlayer) {
            $sender->sendMessage(Translation::getMessage("noPermission"));
			return;
		}

		if($sender instanceof ElementalPlayer) {

			$sender->sendForm(new InformationForm($sender));

		}

    }
}