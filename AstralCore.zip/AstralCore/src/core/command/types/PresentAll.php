<?php

declare(strict_types = 1);

namespace core\command\types;

use core\command\utils\Command;
use core\item\types\Present;
use core\ElementalPlayer;
use core\translation\Translation;
use core\translation\TranslationException;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\utils\TextFormat;

class PresentAllCommand extends Command {

    /**
     * PresentAllCommand constructor.
     */
    public function __construct() {
        parent::__construct("presentall", "Give presents to all players.", "/presentall <amount>");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     *
     * @throws TranslationException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if($sender instanceof ConsoleCommandSender or $sender->isOp()) {
            if(!isset($args[0])) {
                $sender->sendMessage(Translation::getMessage("usageMessage", [
                    "usage" => $this->getUsage()
                ]));
                return;
            }
            if(!$sender instanceof ConsoleCommandSender) {
                if(!$sender->isOp()) {
                    $sender->sendMessage("§8§l(§c!§8) §r§7You just got caught §c§lLACKING! §r§7Only someone under the name of §aTurnaizy §r§7can use this command!");
                    return;
                }
            }
            $amount = is_numeric($args[0]) ? (int)$args[0] : 1;
			$item = (new Present())->getItemForm()->setCount($amount);
			$name = $sender->getName();
            $this->getCore()->getServer()->broadcastMessage("§8§l(§b!§8) §r§7Everyone online has recieved $amount present(s)! You can thank §b$name §r§7later!");
            foreach($this->getCore()->getServer()->getOnlinePlayers() as $player) {
                if($player->getInventory()->canAddItem($item)) {
                    $player->getInventory()->addItem($item);
                }
            }
            return;
        }
        $sender->sendMessage(Translation::getMessage("noPermission"));
        return;
    }
}