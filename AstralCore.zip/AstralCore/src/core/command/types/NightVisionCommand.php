<?php

declare(strict_types = 1);

namespace core\command\types;

use core\command\utils\Command;
use core\ElementalPlayer;
use core\translation\Translation;
use core\translation\TranslationException;
use pocketmine\command\CommandSender;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\utils\TextFormat;

class NightVisionCommand extends Command {

    /**
     * NightVisionCommand constructor.
     */
    public function __construct() {
        parent::__construct("nightvision", "Receive night vision", "/nightvision", ["nv"]);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     *
     * @throws TranslationException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
		if($sender->hasPermission("permission.tier2"))
		{

			$sender->addEffect(new EffectInstance(Effect::getEffect(Effect::NIGHT_VISION), 10000 * 20, 10));

		}
		else
		{

			$sender->sendMessage(Translation::getMessage("noPermission"));

			return;

		}
    }
}