<?php

namespace core\command\forms;

use core\Elemental;
use core\ElementalListener;
use core\ElementalPlayer;
use core\libs\form\MenuForm;
use core\libs\form\MenuOption;
use core\translation\Translation;
use pocketmine\entity\Skin;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class CapeForm extends MenuForm
{
    public function __construct()
    {
        $title = TextFormat::AQUA.TextFormat::BOLD."CAPES";
        $text = TextFormat::DARK_AQUA."Select a Cape";
        foreach (Elemental::getInstance()->capeData->get("capes") as list($cape_name)) {
            $options[] = new MenuOption($cape_name);
            $options[] = new MenuOption("Reset");
        }
        parent::__construct($title, $text, $options);
    }

    public function onSubmit(Player $player, int $selectedOption): void
    {
        if (!$player instanceof ElementalPlayer) {
            return;
        }

        foreach (Elemental::getInstance()->capeData->get("capes") as list($cape_name, $permission, $image))
        {
            if (!$player->hasPermission($permission) || !$player->isOp()) {
                $player->sendMessage(Translation::getMessage("noPermission"));
                return;
            }
            $option = $this->getOption($selectedOption)->getText();
            if ($option === "Reset") {
                $cl = new ElementalListener(Elemental::getInstance());
                //$player->setSkin($cl->skin[$player->getName()]);
                $player->sendMessage(Translation::RED."Your cape and skin have been successfully reset to when you joined the server.");
				return;
            }
            $this->applyCape($cape_name,$player,$image);
        }
    }

    public function applyCape($name, Player $player, $cape_image) {
        if (!$player instanceof ElementalPlayer) {
            return false;
        }
        $skin = $player->getSkin();
        $path = Elemental::getInstance()->getDataFolder()."cape/$cape_image.png";
        if (!file_exists(Elemental::getInstance()->getDataFolder()."cape/$cape_image.png")) {
            $player->sendMessage(Translation::RED."I can't find {$cape_image} Image :(");
			return;
        }
        $img = @imagecreatefrompng($path);
        $skinbytes = "";
        $s = (int)@getimagesize($path)[1];

        for($y = 0; $y < $s; $y++) {
            for($x = 0; $x < 64; $x++) {
                $colorat = @imagecolorat($img, $x, $y);
                $a = ((~((int)($colorat >> 24))) << 1) & 0xff;
                $r = ($colorat >> 16) & 0xff;
                $g = ($colorat >> 8) & 0xff;
                $b = $colorat & 0xff;
                $skinbytes .= chr($r) . chr($g) . chr($b) . chr($a);
            }
        }

        //@imagedestroy($img);

        //$player->setSkin(new Skin($skin->getSkinId(), "",$skinbytes, $skin->getGeometryName(), $skin->getGeometryData()));
        //$player->sendSkin();
        //$player->sendMessage(Translation::AQUA."You've Successfully Equipped the $name!");
		$player->sendMessage(Translation::RED . "You don't have permission to use this cape.");
        return true;
    }
}
