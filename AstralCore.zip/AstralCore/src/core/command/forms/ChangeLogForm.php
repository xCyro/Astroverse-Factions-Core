<?php

declare(strict_types = 1);

namespace core\command\forms;

use core\libs\form\CustomForm;
use core\libs\form\element\Label;
use pocketmine\utils\TextFormat;

class ChangeLogForm extends CustomForm {

    /**
     * ChangeLogForm constructor.
     */
    public function __construct() {
        $title = TextFormat::BOLD . TextFormat::AQUA . "Changelog";
        $elements = [];
        $elements[] = new Label("Changes",  "There has been a complete revamp of\nthe server. Everything has changed,\ngo look for yourselves!\n\n- New anticheat\n- Not pay to win at ALL\n- Many new features / changes, enjoy\n- Alot of custom enchantments");
        parent::__construct($title, $elements);
    }
}