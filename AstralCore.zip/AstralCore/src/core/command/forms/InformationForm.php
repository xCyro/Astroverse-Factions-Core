<?php

declare(strict_types = 1);

namespace core\command\forms;

use core\item\enchantment\Enchantment;
use core\item\ItemManager;
use libs\form;
use core\libs\form\CustomForm;
use core\libs\form\element\Label;
use core\libs\form\element\Button;

use pocketmine\utils\TextFormat;

class InformationForm extends CustomForm {

    /**
     * InformationForm constructor.
     */
    public function __construct() {
        $title = TextFormat::LIGHT_PURPLE . TextFormat::BOLD . "Server Information";
		$elements = [];
		$elements[] = new Label("MainLabel", "§b§lIntroduction§r\n\n§7Welcome to §bAstral OP Factions. §r§7You are probably wondering how you can become Over Powered. You can start off by claiming the §4§lOnce §r§7Kit. It will include an OP kit with a §4§lCoal Mining Generator §r§7for you to use. Start exploring by doing §e/wild §r§7where you can discover and raid other people's bases and also create your own.\n\n§b§lRanks§r\n\n§7In our server, you can obtain better ranks through hard work and effort. These ranks will help you unlock more homes, vaults, shop items and more! You can rank up by doing §e/rankup!§r\n\n§b§lEnchantment§r\n\n§7You are probably clueless about how to get enchantments on our server. You can get enchantments in many ways. The main way is to trade XP for enchantment books by visiting the §1§lCastor §r§7located at the server spawn. You get one book per §e5000 XP. §r§7You can apply an enchantment by dragging an enchantment book on top of an item. If you want to take off an enchantment, you can trade a book to the §2§lAlchemist §r§7for an §5§lEnchantment Remover. §r§7You remove the enchantment by tapping the item you want enchantments removed on against the §2§lAlchemist §r§7with an enchantment remover in your inventory.\n\n§b§lGod Kits§r\n\n§7God Kits are OP kits that you can get through opening special §eBoxes§r§e. §r§7You can manage your GKits by doing §e/skit. §r§7Special Boxes are obtained through opening §b§lArti§ffacts§r§f. §r§7Artifacts are obtained through §emining §r§7and also artifact alls that are automatically executed every §e150 §r§7votes. Artifacts have a 1 in 5 chance of uncovering a Special Box.\n\n§b§lClasses§r\n\n§7Classes are a way to give yourself special effects and advantages. When you pick a class it cannot be changed. You will use that class for the rest of the season until it ends then next season you will be able to change it.\n\n§b§lFeatures§r\n\n§dBasic list of features you should know:\n§r§7Bounties, Crates, Bosses, Classes, CoinFlips, Gambling, Auctions, Monthly Crates, Spawners, Mining and Auto Generators, KOTH, Envoys, Lucky Blocks, Trading, Vaults and an amazing anti-cheat known as §4§lWatchdog§r§4.§r\n§dBasic list of commands you should know:§r\n§7/pvp, /boss, /envoys, /rewards, /kit, /koth, /list, /hub, /spawn, /ping, /pvphud, /ah, /rankup, /shop, /rules, /sell, /gkit, /tag, /trade, /trash, /vote, /wild, /withdraw and /xyz.");
        parent::__construct($title, $elements);
    }
}