<?php

declare(strict_types = 1);

namespace core\level;

use core\item\types\LuckyBlock;
use core\item\types\Artifact;
use core\level\tile\Generator;
use core\level\tile\MobSpawner;
use core\Elemental;
use core\ElementalPlayer;
use core\menu\HeadhuntingMainMenu;
use core\translation\Translation;
use core\translation\TranslationException;
use libs\utils\UtilsException;
use pocketmine\block\Block;
use pocketmine\item\Item;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\inventory\FurnaceSmeltEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\level\Position;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class LevelListener implements Listener {

    /** @var Elemental */
    private $core;

    /**
     * LevelListener constructor.
     *
     * @param Elemental $core
     */
    public function __construct(Elemental $core) {
        $this->core = $core;
    }

    /**
     * @param PlayerJoinEvent $event
     *
     * @throws UtilsException
     */
    public function onPlayerJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        if(!$player instanceof ElementalPlayer) {
            return;
		}

		// FTOP Ranking...

		$stmt = $this->core->getMySQLProvider()->getDatabase()->prepare("SELECT name, strength FROM factions ORDER BY strength DESC LIMIT 10");
		$stmt->execute();
		$stmt->bind_result($name, $strength);
		$place = 1;
		$powerText = $powerText = "";
		while($stmt->fetch()) {
			$powerText .= "\n" . TextFormat::BOLD . TextFormat::GOLD . "#" . TextFormat::YELLOW . $place . TextFormat::RESET . TextFormat::YELLOW . ": " . TextFormat::RESET . TextFormat::DARK_AQUA . $name . TextFormat::DARK_GRAY . " | " . TextFormat::AQUA  . $strength . " Power";
			$place++;
		}
		$stmt->close();

		$stmt = $this->core->getMySQLProvider()->getDatabase()->prepare("SELECT name, balance FROM factions ORDER BY balance DESC LIMIT 10");
		$stmt->execute();
		$stmt->bind_result($name, $balance);
		$place = 1;
		$valueText = $valueText = "";
		while($stmt->fetch()) {
			$valueText .= "\n" . TextFormat::BOLD . TextFormat::GOLD . "#" . TextFormat::YELLOW . $place . TextFormat::RESET . TextFormat::YELLOW . ": " . TextFormat::RESET . TextFormat::DARK_AQUA . $name . TextFormat::DARK_GRAY . " | " . TextFormat::AQUA  . $balance . " Value";
			$place++;
		}
		$stmt->close();

		$stmt = $this->core->getMySQLProvider()->getDatabase()->prepare("SELECT username, balance FROM players ORDER BY balance DESC LIMIT 10");
		$stmt->execute();
		$stmt->bind_result($username, $pBalance);
		$place = 1;
		$balanceText = $balanceText = "";
		while($stmt->fetch()) {
			$balanceText .= "\n" . TextFormat::BOLD . TextFormat::GOLD . "#" . TextFormat::YELLOW . $place . TextFormat::RESET . TextFormat::YELLOW . ": " . TextFormat::RESET . TextFormat::DARK_AQUA . $username . TextFormat::DARK_GRAY . " | " . TextFormat::AQUA . $pBalance . TextFormat::DARK_AQUA . "$";
			$place++;
		}
		$stmt->close();

        $level = $this->core->getServer()->getDefaultLevel();
		$player->addFloatingText(new Position(265.5, 7, 237.5, $level), "Welcome", "§b§lWELCOME TO ASTRAL OP FACTIONS§r\n§3-----------------------------------------------\n§7You can start your astronomic journey by creating your own\n§7faction with §b/f create §r§7or joining one!\n§7Enjoy fighting bosses, killing players and becoming\n§7the strongest faction in order to claim rewards!\n§7Type §b/wild §7to get started!\n§3-----------------------------------------------§r");
		$player->addFloatingText(new Position(257.5, 5.5, 255.5, $level), "Features", "§b§lOP FACTIONS FEATURES§r\n§3------------------------------------\n§8[§3-§8]§r §r§bOver 70 custom enchants §8[§3-§8]§r\n§8[§3-§8] §r§bVote Rewards & Vote Parties §8[§3-§8]§r\n§r§8[§3-§8] §r§bDaily Rewards! §8[§3-§8]§r\n§r§8[§3-§8] §r§bCustom Quests with many rewards §8[§3-§8]§r\n§r§8[§3-§8] §r§bFREE Ranks you can work for! §8[§3-§8]§r\n§r§8[§3-§8] §r§bAmazing boss fights! §8[§3-§8]§r\n§r§8[§3-§8] §r§bProgressive Ranking System! §8[§3-§8]§r\n§r§3---------------------------------§r");
        $player->addFloatingText(new Position(251.5, 5.3, 219.5, $level), "Links", "§b§lASTRALMC LINKS§r\n§3----------------------------\n§bStore§3: §r§7store.astralmc.ml\n§bDiscord§3: §r§7discord.io/Astroverse\n§bWebsite§3: §7astroverse.com\n§bVote§3:§r§7 vote.astralmc.ml\n§bIP§3: §r§7astralmc.ml§r\n§3-------------------------------§r");

        // Leader Boards

		$player->addFloatingText(new Position(287.5, 7, 192.5, $level), "FTopPower", "§b§lTop Factions §8(§3POWER§8)§r\n$powerText");
		$player->addFloatingText(new Position(291.5, 7, 196.5, $level), "FTopValue", "§b§lTop Factions §8(§3VALUE§8)§r\n$valueText");
		$player->addFloatingText(new Position(283.5, 7, 188.5, $level), "BalanceTop", "§b§lRichest Players §8(§3MONEY§8)§r\n$balanceText");

    }

    /**
     * @priority HIGHEST
     * @param PlayerInteractEvent $event
     */
    public function onPlayerInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        if(!$player instanceof ElementalPlayer) {
            return;
        }
        $block = $event->getBlock();
        $tile = $block->getLevel()->getTile($block);
        $item = $event->getItem();
        if($item->getNamedTag()->hasTag("EntityId")) {
            $entityId = $item->getNamedTag()->getInt("EntityId", -1);
            if($entityId < 10) {
                return;
            }
            if($tile instanceof MobSpawner and $tile->getEntityId() === $entityId and $tile->getStack() < 50) {
                $stack = $tile->getStack() + 1;
                $tile->setStack($stack);
				$player->sendMessage("§l§8(§a!§8)§r §7STACKED: " . $stack . "/50");
				$player->addTitle("§c" . $stack . "/50");
                $player->getInventory()->setItemInHand($item->setCount($item->getCount() - 1));
                $event->setCancelled();
            }
        }
        if($tile instanceof Generator and $block->getItemId() === $item->getId() and $tile->getStack() < 25) {
            $stack = $tile->getStack() + 1;
            $tile->setStack($stack);
			$player->sendMessage("§l§8(§a!§8)§r §7STACKED: " . $stack . "/25");
			$player->addTitle("§c" . $stack . "/25");
            $player->getInventory()->setItemInHand($item->setCount($item->getCount() - 1));
            $event->setCancelled();
		}

		//if($block->getId() === Block::CAULDRON_BLOCK){

			//new HeadhuntingMainMenu($player);

		//}

    }

    /**
     * @priority HIGHEST
     * @param BlockBreakEvent $event
     *
     * @throws TranslationException
     */
    public function onBlockBreak(BlockBreakEvent $event): void {
        if($event->isCancelled()) {
            return;
        }
        $player = $event->getPlayer();
        if(!$player instanceof ElementalPlayer) {
            return;
        }
        $block = $event->getBlock();
        if($block->getId() === Block::STONE) {
            if(mt_rand(1, 250) === mt_rand(1, 250)) {
                $item = new LuckyBlock(mt_rand(0, 100));
                if(!$player->getInventory()->canAddItem($item->getItemForm())){
                    $player->sendMessage("§l§8(§c!§8)§r §4Your inventory is full!§r");
                    return;
                }
                $player->getInventory()->addItem($item->getItemForm());
                $player->sendMessage(Translation::getMessage("luckyBlockFound"));
				$player->addLuckyBlocksMined();
			}
            if(mt_rand(0, 15000) <= 5) {
                $item = new Artifact();
                if(!$player->getInventory()->canAddItem($item->getItemForm())){
                    $player->sendMessage("§l§8(§c!§8)§r §4Your inventory is full!§r");
                    return;
                }
                $player->getInventory()->addItem($item->getItemForm());
                Server::getInstance()->broadcastMessage(Translation::AQUA . TextFormat::AQUA . $player->getName() . TextFormat::YELLOW . " discovered an §bArtifact §ewhile mining!§r");
            }
        }
	}

    /**
     * @priority LOWEST
     * @param FurnaceSmeltEvent $event
     */
    public function onFurnaceSmelt(FurnaceSmeltEvent $event): void {
        $id = $event->getResult()->getId();
        if($id >= Block::PURPLE_GLAZED_TERRACOTTA and $id <= Block::BLACK_GLAZED_TERRACOTTA) {
            $event->setCancelled();
        }
    }
}
