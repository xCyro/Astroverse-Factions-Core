<?php

namespace core\combat\boss;

interface ArtificialIntelligence {

}