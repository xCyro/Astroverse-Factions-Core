<?php

namespace core\combat\boss\types;

use core\combat\boss\Boss;
use core\item\ItemManager;
use core\item\types\EnchantmentBook;
use core\item\types\LuckyBlock;
use core\item\types\MoneyNote;
use core\item\types\Artifact;
use core\item\types\XPNote;
use core\item\types\MoneyPouch;
use core\item\types\BloodyNote;
use core\item\types\KothFlare;
use core\Elemental;
use core\ElementalPlayer;
use core\item\types\GreekCrate;
use core\utils\Utils;
use pocketmine\level\Level;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class Witcher extends Boss {

    const BOSS_ID = 3;

    /**
     * Witcher constructor.
     * @param Level $level
     * @param CompoundTag $nbt
     */
    public function __construct(Level $level, CompoundTag $nbt) {
        $path = Elemental::getInstance()->getDataFolder() . "npc/skins/" . Elemental::getInstance()->bossData->get("skin");
        $this->setSkin(Utils::createSkin(Utils::getSkinDataFromPNG($path)));
        parent::__construct($level, $nbt);
        $this->setMaxHealth(Elemental::getInstance()->bossData->get("stats")["health"]);
        $this->setHealth(Elemental::getInstance()->bossData->get("stats")["health"]);
        $this->setNametag(TextFormat::BOLD . TextFormat::DARK_PURPLE . "Hydro " . TextFormat::RESET . TextFormat::RED . $this->getHealth() . TextFormat::GRAY . "/" . TextFormat::RED . $this->getMaxHealth() . TextFormat::RESET);
        $this->setScale(Elemental::getInstance()->bossData->get("stats")["scale"]);
        $this->attackDamage = Elemental::getInstance()->bossData->get("stats")["attackDamage"];
        $this->speed = Elemental::getInstance()->bossData->get("stats")["speed"];
        $this->attackWait = Elemental::getInstance()->bossData->get("stats")["attackWait"];
        $this->regenerationRate = Elemental::getInstance()->bossData->get("stats")["regenerationRate"];
    }

    /**
     * @param int $tickDiff
     *
     * @return bool
     */
    public function entityBaseTick(int $tickDiff = 1): bool {
        $this->setNametag(TextFormat::BOLD . TextFormat::DARK_PURPLE . "Hydro " . TextFormat::RESET . TextFormat::RED . $this->getHealth() . TextFormat::GRAY . "/" . TextFormat::RED . $this->getMaxHealth() . TextFormat::RESET);
        return parent::entityBaseTick($tickDiff);
    }

    public function onDeath(): void {
		$randomArt = mt_rand(1, 10);
        $rewards = [
            (new EnchantmentBook(ItemManager::getRandomEnchantment()))->getItemForm(),
			(new XPNote(mt_rand(1500, 3000)))->getItemForm(),
			(new GreekCrate())->getItemForm(),
			(new MoneyPouch(350000))->getItemForm(),
			(new BloodyNote(75000))->getItemForm()
        ];
        $d = null;
        $p = null;
        foreach($this->damages as $player => $damage) {
            if(Server::getInstance()->getPlayer($player) === null) {
                continue;
            }
            $online = Server::getInstance()->getPlayer($player);
            if($damage > $d) {
                $d = $damage;
                $p = $online;
            }
        }
        if($p === null) {
            return;
        }
        //top
        $keys = ["Legendary" => 1, "Epic" => 2, "Rare" => 5];
        $rand = array_rand($keys);
        $crate = Elemental::getInstance()->getCrateManager()->getCrate($rand);
        if($p instanceof ElementalPlayer){
            $p->addKeys($crate, $keys[$rand]);
        }

        Server::getInstance()->broadcastMessage($p->getDisplayName() . TextFormat::GRAY . " has dealt the most damage " . TextFormat::DARK_GRAY . "(" . TextFormat::WHITE . $d . TextFormat::RED . TextFormat::BOLD . " DMG" . TextFormat::RESET . TextFormat::DARK_GRAY . ")" . TextFormat::GRAY . " to " . TextFormat::BOLD . TextFormat::DARK_PURPLE . "Hydro " . TextFormat::RESET . TextFormat::GRAY . "and received:");
        foreach($rewards as $item) {
            $name = TextFormat::RESET . TextFormat::WHITE . $item->getName();
            if($item->hasCustomName()) {
                $name = $item->getCustomName();
            }
            Server::getInstance()->broadcastMessage($name . TextFormat::RESET . TextFormat::GRAY . " * " . TextFormat::WHITE . $item->getCount());
            if($p->getInventory()->canAddItem($item)) {
                $p->getInventory()->addItem($item);
                continue;
            }
            $p->getLevel()->dropItem($p, $item);
        }


        //other
        foreach($this->damages as $player => $damage) {
            if($player === $p->getName()) {
                continue;
            }
            if(Server::getInstance()->getPlayer($player) === null) {
                continue;
            }
            $online = Server::getInstance()->getPlayer($player);
            $online->sendMessage(TextFormat::GRAY . "You dealt " . TextFormat::WHITE . $damage . TextFormat::RED . TextFormat::BOLD . " DMG" . TextFormat::GRAY . " to " . TextFormat::BOLD . TextFormat::DARK_PURPLE . "Hydro " . TextFormat::RESET . TextFormat::GRAY . "and received:");
            $rewards = [
                (new EnchantmentBook(ItemManager::getRandomEnchantment()))->getItemForm(),
				(new XPNote(mt_rand(1000, 2000)))->getItemForm(),
				(new BloodyNote(75000))->getItemForm()
            ];
            if($p instanceof ElementalPlayer){
                $crate = Elemental::getInstance()->getCrateManager()->getCrate("Rare");
                $p->addKeys($crate, 2);
            }
            foreach($rewards as $item) {
                $name = TextFormat::RESET . TextFormat::WHITE . $item->getName();
                if($item->hasCustomName()) {
                    $name = $item->getCustomName();
                }
                $online->sendMessage($name . TextFormat::RESET . TextFormat::GRAY . " * " . TextFormat::WHITE . $item->getCount());
                if($online->getInventory()->canAddItem($item)) {
                    $online->getInventory()->addItem($item);
                    continue;
                }
                $online->getLevel()->dropItem($online, $item);
            }
        }
    }
}
