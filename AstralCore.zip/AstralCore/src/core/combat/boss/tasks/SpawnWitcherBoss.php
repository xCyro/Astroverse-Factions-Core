<?php

namespace core\combat\boss\tasks;

use core\combat\boss\Boss;
use core\combat\boss\types\{Alien, Witcher, CorruptedKing, HordEntity};
use core\Elemental;
use pocketmine\entity\Entity;
use pocketmine\math\Vector3;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class SpawnWitcherBoss extends Task
{

    /** @var string */
    protected $prefix = "§l§8(§3!§8)§r §7";
    /** @var int */
    protected $time = 1800; // 30 minutes.
    /** @var bool */
    protected $sentWarning = false;

    /**
     * @param int $currentTick
     */
    public function onRun(int $currentTick)
    {
        if (!$this->sentWarning and $this->check()) {
            Server::getInstance()->broadcastMessage("§l§8(§3!§8)§r §7The §l§5Hydro§r §7boss spawning has been paused!§r");
            $this->sentWarning = true;
            return;
        }
        if ($this->check()) {
            return;
        }
        if ($this->sentWarning) {
            $this->sentWarning = false;
        }
        if (($this->time % 300) == 0) {
            $time = ($this->time >= 60) ? floor(($this->time / 60) % 60) . " §7minutes§r" : $this->time . " §7seconds§r";
            Server::getInstance()->broadcastMessage("§l§8(§3!§8)§r §7The §l§5Hydro§r §7boss is spawning in " . $time . "§7...§r");
        }
        if ($this->time <= 0) {
            if (!$this->check()) $this->summon();
            $this->time = 900;
        } else {
            --$this->time;
        }
    }

    /**
     * @return bool
     */
    public function check(): bool
    {
        $lvl = Server::getInstance()->getLevelByName("world");


        foreach ($lvl->getEntities() as $entity) {
            if ($entity instanceof Alien or $entity instanceof CorruptedKing or $entity instanceof Witcher) {
                return true;
            }
        }
        return false;
    }

    public function summon(): void
    {
        $position = Elemental::getInstance()->bossData->get("arena");
        $class = Elemental::getInstance()->getCombatManager()->getBossNameByIdentifier(3);
        $lvl = Server::getInstance()->getLevelByName($position["level"]);
        $pos = new Vector3($position["x"], $position["y"], $position["z"]);
        $lvl->loadChunk($pos->x >> 4, $pos->z >> 4, true);
        $nbt = Entity::createBaseNBT($pos);
        /** @var Boss $entity */
        $entity = new $class($lvl, $nbt);
		$entity->spawnToAll();
		//$this->summonHord($entity->getX() - 4, $entity->getY() + 2, $entity->getZ() - 1, $entity->getLevel()->getName());
		//$this->summonHord($entity->getX() - 3, $entity->getY() + 3, $entity->getZ() - 2, $entity->getLevel()->getName());
		//$this->summonHord($entity->getX() - 2, $entity->getY() + 4, $entity->getZ() - 3, $entity->getLevel()->getName());
		//$this->summonHord($entity->getX() - 1, $entity->getY() + 1, $entity->getZ() - 4, $entity->getLevel()->getName());
        Server::getInstance()->broadcastMessage("§l§8(§3!§8)§r §7The §l§5Hydro§r §7boss has been spawned in the boss arena. The player that deals the MOST damage gets 4 rewards! Everyone else gets 1 reward! To teleport to the boss arena, type /boss.§r");
	}
	
	//public function summonHord($x, $y, $z, $level) : void {
        //$class = Elemental::getInstance()->getCombatManager()->getBossNameByIdentifier(20);
        //$lvl = Server::getInstance()->getLevelByName($level);
        //$pos = new Vector3($x, $y, $z);
        //$lvl->loadChunk($x >> 4, $z >> 4, true);
        //$nbt = Entity::createBaseNBT($pos);
        ///** @var Boss $entity */
        //$entity = new $class($lvl, $nbt);
        //$entity->spawnToAll();
	//}
}
