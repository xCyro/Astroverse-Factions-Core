<?php

declare(strict_types = 1);

namespace core\announcement\task;

use core\Elemental;
use core\ElementalPlayer;
use core\translation\Translation;
use core\translation\TranslationException;
use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat;
use pocketmine\command\ConsoleCommandSender;
use jacknoordhuis\combatlogger\{EventListener, CombatLogger, MessageManager, TaggedHeartbeatTask};

class RestartTask extends Task {

    /** @var Elemental */
    private $core;

    /** @var int */
    private $time = 5400;

    /**
     * RestartTask constructor.
     *
     * @param Elemental $core
     */
    public function __construct(Elemental $core) {
        $this->core = $core;
    }

    /**
     * @param int $currentTick
     *
     * @throws TranslationException
     */
    public function onRun(int $currentTick) {
        $hours = floor($this->time / 3600);
        $minutes = floor(($this->time / 60) % 60);
        $seconds = $this->time % 60;
        if($minutes % 10 == 0 and $seconds == 0) {
            $this->core->getServer()->broadcastMessage(Translation::getMessage("restartMessage", [
                "hours" => $hours,
                "minutes" => $minutes,
                "seconds" => $seconds
            ]));
        }
        if($hours < 1) {
            if($minutes == 0 and $seconds == 30) {
                foreach($this->core->getServer()->getOnlinePlayers() as $player) {
                    if(!$player instanceof ElementalPlayer) {
                        continue;
                    }
                    $player->removeAllWindows();
                }
            }
        foreach($this->core->getServer()->getOnlinePlayers() as $player){
			if($minutes == 0 and $seconds == 59){
				$player->addTitle("§b§lASTROVERSE§r\n§bRebooting in 1 minute");
				$player->teleport(Elemental::getInstance()->getServer()->getDefaultLevel()->getSafeSpawn());
				if(Elemental::getInstance()->getServer()->getDefaultLevel()->getSafeSpawn() == null){
					return;
				}
			}
			if($minutes == 5 and $seconds == 1){
				$player->addTitle("§b§lASTROVERSE§r\n§bRebooting in 5 minutes\n");
				$player->getServer()->broadcastMessage("\n\n§8§l(§b!§8) §r§7The server will be rebooting in 5 minutes. You will be teleported to spawn a few seconds before it. It is recommended that you save everything like set your homes, exit combat and just do everything you need to get ready!\n\n\n");
			}
			if($minutes == 0 and $seconds == 3){
				$player->teleport(Elemental::getInstance()->getServer()->getDefaultLevel()->getSafeSpawn());
			}
			if($minutes == 0 and $seconds == 4){
				$player->addTitle("§b§lASTROVERSE§r\n§bRebooting...");
			}
        }
            if($minutes == 0 and $seconds == 0) {
                $this->core->getServer()->dispatchCommand(new ConsoleCommandSender(), 'save-all');
                foreach($this->core->getServer()->getOnlinePlayers() as $player) {
                    if(!$player instanceof ElementalPlayer) {
                        continue;
                    }
                    if($player->isTagged()) {
                        $player->combatTag(false);
                    }
                    $player->save();
                    $player->close("", "       §b§lSERVER REBOOTING\n§r§3Try reconnecting in a few seconds");
                }
                $this->core->getServer()->shutdown();
            }
        }
        $this->time--;
    }

    /**
     * @param int $time
     */
    public function setRestartProgress(int $time): void {
        $this->time = $time;
    }

    /**
     * @return int
     */
    public function getRestartProgress(): int {
        return $this->time;
    }
}
