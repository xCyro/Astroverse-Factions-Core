<?php

declare(strict_types = 1);

namespace core\announcement\task;

use core\Elemental;
use core\translation\Translation;
use core\translation\TranslationException;
use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat;

class BroadcastMessagesTask extends Task {

    /** @var Elemental */
    private $core;

    /**
     * BroadcastMessagesTask constructor.
     *
     * @param Elemental $core
     */
    public function __construct(Elemental $core) {
        $this->core = $core;
    }

    /**
     * @param int $currentTick
     *
     * @throws TranslationException
     */
    public function onRun(int $currentTick) {
        $message = $this->core->getAnnouncementManager()->getNextMessage();
        $this->core->getServer()->broadcastMessage(Translation::getMessage("broadcastMessage", [
            "message" => TextFormat::LIGHT_PURPLE . $message
        ]));
    }
}