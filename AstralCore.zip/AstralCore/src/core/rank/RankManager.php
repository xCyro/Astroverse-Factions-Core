<?php

declare(strict_types = 1);

namespace core\rank;

use core\Elemental;
use pocketmine\utils\TextFormat;

class RankManager {

    /** @var Elemental */
    private $core;

    /** @var Rank[] */
    private $ranks = [];

    /**
     * RankManager constructor.
     *
     * @param Elemental $core
     *
     * @throws RankException
     */
    public function __construct(Elemental $core) {
        $this->core = $core;
        $core->getServer()->getPluginManager()->registerEvents(new RankListener($core), $core);
        $this->init();
    }

    /**
     * @throws RankException
     */
    public function init(): void {
                $this->addRank(new Rank("Astronaut", TextFormat::RESET, TextFormat::RESET . "§7Astronaut§r", Rank::ASTRONAUT, // DEFAULT RANK
            "§f⚔ §8(§c{faction}§8)§r §7Astronaut §r§8[§4§l{kills}§r§8] {tag} §r§f{player}§8: §7{message}",
            "§8(§c{faction}§8)§r\n§7Astronaut {tag} §r§f{player} ", 5, 1, [
                "permission.starter",
				"permission.once",
				"playervaults.vault.1",
            ]));
                $this->addRank(new Rank("Aster", TextFormat::RESET, TextFormat::RESET . "§bAster§r", Rank::ASTER, // FREE RANK
            "§f⚔ §8(§c{faction}§8)§r §bAster§r §8[§4§l{kills}§r§8]§r {tag} §r§f{player}§8: §3{message}",
            "§8(§c{faction}§8)§r\n§bAster§r {tag} §r§f{player}", 7, 2,  [
                "permission.starter",
                "permission.aster",
				"permission.once",
				"playervaults.vault.1"
            ]));
                $this->addRank(new Rank("Sirius", TextFormat::RESET, TextFormat::RESET . "§aSirius§r", Rank::SIRIUS, // FREE RANK
            "§f⚔ §8(§c{faction}§8)§r §aSirius§r §8[§4§l{kills}§r§8]{tag}  §r§f{player}§8: §2{message}",
            "§8(§c{faction}§8)§r\n§aSirius§r {tag} §r§f{player}", 7, 2,  [
                "permission.starter",
                "permission.aster",
				"permission.sirius",
				"playervaults.vault.1",
				"permission.once"
            ]));
        $this->addRank(new Rank("Arpina", TextFormat::RESET, TextFormat::RESET . "§eArpina§r", Rank::ARPINA, // FREE RANK
            "§f⚔ §8(§c{faction}§8)§r §eArpina§r §8[§4§l{kills}§r§8] {tag} §r§f{player}§8: §6{message}",
            "§8(§c{faction}§8)§r\n§eArpina§r {tag} §r§f{player}", 11, 4, [
                "permission.starter",
                "permission.aster",
				"permission.sirius",
				"permission.arpina",
				"playervaults.vault.1",
                "permission.once"
            ]));
        $this->addRank(new Rank("Aurora", TextFormat::RESET, TextFormat::RESET . "§bA§3u§br§3o§br§3a§r", Rank::AURORA, // FREE RANK
            "§f⚔ §8(§c{faction}§8)§r §bA§3u§br§3o§br§3a§r §8[§4§l{kills}§r§8] {tag} §r§f{player}§8: §b{message}",
            "§8(§c{faction}§8)§r\n§bA§3u§br§3o§br§3a§r §8[§4§l{kills}§r§8] {tag} §r§f{player}", 13, 5, [
                "permission.starter",
                "permission.aster",
				"permission.sirius",
				"permission.arpina",
                "permission.aurora",
				"permission.tier1",
				"permission.tier2",
				"playervaults.vault.2",
				"playervaults.vault.1",
                "permission.once"
            ]));
        $this->addRank(new Rank("Alula", TextFormat::RESET, TextFormat::RESET . "§bA§9l§bu§9l§ba§r", Rank::ALULA,
            "§f⚔ §8(§c{faction}§8)§r §bA§9l§bu§9l§ba§r §8[§4§l{kills}§r§8] {tag} §r§f{player}§8: §9{message}",
            "§8(§c{faction}§8)§r\n§bA§9l§bu§9l§ba§r {tag} §r§f{player}", 15, 6, [
				"permission.starter",
				"permission.aster",
				"permission.sirius",
				"permission.arpina",
				"permission.aurora",
                "permission.alula",
				"permission.tier1",
				"playervaults.vault.1",
                "permission.once"
			]));
		$this->addRank(new Rank("Nitro-Booster", TextFormat::RESET, TextFormat::RESET . "§dNitro-Booster§r", Rank::NITRO_BOOSTER,
            "§f⚔ §8(§c{faction}§8)§r §dNitro-Booster§r §8[§4§l{kills}§r§8] {tag} §r§f{player}§8: §d{message}",
            "§8(§c{faction}§8)§r\n§dNitro-Booster§r {tag} §r§f{player}", 15, 6, [
				"permission.starter",
				"permission.aster",
				"permission.sirius",
				"permission.arpina",
				"permission.aurora",
                "permission.alula",
				"permission.tier1",
				"permission.tier2",
				"playervaults.vault.1",
                "permission.once"
			]));
        $this->addRank(new Rank("Almathea", TextFormat::RESET, TextFormat::RESET . "§dA§5l§dm§5a§dt§5h§de§5a§r", Rank::ALMATHEA,
            "§8(§c{faction}§8)§r §dA§5l§dm§5a§dt§5h§de§5a§r §8[§4§l{kills}§r§8] {tag} §r§f{player}§8: §d{message}",
            "§8(§c{faction}§8)§r\n§dA§5l§dm§5a§dt§5h§de§5a§r {tag} §r§f{player}", 15, 8, [
				"permission.starter",
				"permission.aster",
				"permission.sirius",
				"permission.arpina",
				"permission.aurora",
                "permission.alula",
                "permission.almathea",
                "permission.tier1",
				"permission.tier2",
				"playervaults.vault.1",
                "permission.once"
            ]));
        $this->addRank(new Rank("Adhara", TextFormat::RESET, TextFormat::RESET . "§dA§bd§5h§da§br§5a§r", Rank::ADHARA,
            "§8(§c{faction}§8)§r §dA§bd§5h§da§br§5a§r §8[§4§l{kills}§r§8] {tag} §r§f{player}§8: §d{message}",
            "§8(§c{faction}§8)§r\n§dA§bd§5h§da§br§5a§r {tag} §r§f{player}", 18, 10, [
                "permission.starter",
                "permission.tier1",
                "permission.aster",
                "permission.sirius",
                "permission.arpina",
                "permission.aurora",
                "permission.alula",
                "permission.almathea",
                "permission.adhara",
				"permission.tier2",
				"playervaults.vault.1",
                "permission.once"
            ]));
        $this->addRank(new Rank("Astronomer", TextFormat::RESET, TextFormat::RESET . "§bAs§dtr§bon§dom§ber§r", Rank::ASTRONOMER,
            "§8(§c{faction}§8)§r §bAs§dtr§bon§dom§ber§r §8[§4§l{kills}§r§8] {tag} §r§f{player}§8: §b{message}",
            "§8(§c{faction}§8)§r\n§bAs§dtr§bon§dom§ber§r {tag} §r§f{player}", 25, 15, [
                "permission.starter",
                "permission.aster",
                "permission.sirius",
                "permission.arpina",
                "permission.aurora",
                "permission.alula",
                "permission.almathea",
                "permission.adhara",
                "permission.astronomer",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
				"permission.once",
				"playervaults.vault.2",
				"playervaults.vault.1",
                "permission.join.full"
			]));
        $this->addRank(new Rank("YouTuber+", TextFormat::RESET, TextFormat::RESET . "§l§cYOU§fTUBER§r§f+", Rank::YOUTUBER_PLUS,
            "§8(§c{faction}§8)§r §l§cYOU§fTUBER§r§f+ §r§8[§4§l{kills}§r§8] §r{tag} §r§f{player}§7: §c{message}",
            "§8(§c{faction}§8)§r\n§l§cYOU§fTUBER§r§f+ §r{tag} §r§f{player}", 25, 15, [
                "permission.starter",
                "permission.aster",
                "permission.sirius",
                "permission.arpina",
                "permission.aurora",
                "permission.alula",
                "permission.almathea",
                "permission.adhara",
                "permission.astronomer",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
				"permission.once",
				"playervaults.vault.1",
                "permission.join.full"
            ]));
        $this->addRank(new Rank("Trainee", TextFormat::RESET, TextFormat::RESET . "§l§eTRAINEE§r", Rank::TRAINEE,
            "§8(§c{faction}§8)§r §l§eTRAINEE§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §6{message}",
            "§8(§c{faction}§8)§r\n§l§eTrainee§r {tag} §r§f{player}", 20, 10, [
            	"permission.starter",
                "permission.aster",
                "permission.sirius",
                "permission.arpina",
                "permission.aurora",
				"permission.alula",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.staff",
                "permission.join.full",
                "bansystem.command.kick",
				"bansystem.command.mutelist",
				"playervaults.vault.1",
                "permission.once"
            ]));
        $this->addRank(new Rank("Moderator", TextFormat::RESET, TextFormat::RESET . "§l§bMODERATOR§r", Rank::MODERATOR,
            "§8(§c{faction}§8)§r §l§bMODERATOR§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}: §3{message}",
            "§8(§c{faction}§8)§r\n§l§bModerator§r {tag} §r§f{player}", 25, 15, [
                "permission.starter",
                "permission.aster",
				"permission.sirius",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.mod",
                "permission.sirius",
                "permission.arpina",
                "permission.aurora",
				"permission.alula",
				"permission.almathea",
                "permission.join.full",
                "permission.staff",
                "bansystem.command.ban",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "bansystem.command.pardon",
				"bansystem.command.tempban",
				"playervaults.others.view",
				"playervaults.vault.1",
                "bansystem.command.tempmute",
                "bansystem.command.unmute",
                "permission.once",
                "invsee"
            ]));
        $this->addRank(new Rank("SrModerator", TextFormat::RESET, TextFormat::RESET . "§l§dSrModerator§r", Rank::SENIOR_MODERATOR,
            "§8(§c{faction}§8)§r §l§dSrMODERATOR§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}: §d{message}",
            "§8(§c{faction}§8)§r\n§l§dSrModerator§r {tag} §r§f{player}", 30, 20, [
				"permission.starter",
				"permission.aster",
                "permission.sirius",
				"permission.arpina",
				"permission.aurora",
                "permission.almathea",
                "permission.tier1",
                "permission.tier2",
                "permission.adhara",
                "permission.tier3",
                "permission.mod",
                "permission.join.full",
                "permission.staff",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
                "bansystem.command.tempmute",
				"bansystem.command.unmute",
                "permission.once",
                "invsee"
            ]));
        $this->addRank(new Rank("Administrator", TextFormat::RESET, TextFormat::RESET . "§l§4ADMIN§r", Rank::ADMINISTRATOR,
            "§8(§c{faction}§8)§r §l§4ADMINISTRATOR§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §c{message}",
            "§8(§c{faction}§8)§r\n§l§4Administrator§r {tag} §r§f{player}", 35, 25, [
				"permission.starter",
				"permission.aster",
                "permission.sirius",
                "permission.arpina",
                "permission.aurora",
                "permission.almathea",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.mod",
                "permission.join.full",
                "permission.staff",
                "pocketmine.command.teleport",
                "pocketmine.command.gamemode",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
                "bansystem.command.tempmute",
                "bansystem.command.unmute",
                "permission.once",
                "invsee"
            ]));
        $this->addRank(new Rank("SrAdministrator", TextFormat::RESET, TextFormat::RESET . "§l§cSr§4ADMIN§r", Rank::SENIOR_ADMINISTRATOR,
            "§8(§c{faction}§8)§r §l§cSr§4ADMINISTRATOR§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §c{message}",
            "§8(§c{faction}§8)§r\n§l§cSr§4Administrator§r {tag} §r§f{player}", 40, 30, [
				"permission.starter",
				"permission.aster",
                "permission.god",
                "permission.avatar",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.mod",
                "permission.join.full",
                "permission.staff",
                "pocketmine.command.teleport",
                "pocketmine.command.gamemode",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
                "bansystem.command.tempmute",
                "bansystem.command.unmute",
                "permission.once",
                "invsee"
            ]));
        $this->addRank(new Rank("Manager", TextFormat::RESET, TextFormat::RESET . "§l§5MANAGER§r", Rank::MANAGER,
            "§8(§c{faction}§8)§r §l§5MANAGER§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §d{message}",
            "§8(§c{faction}§8)§r\n§l§5Manager§r {tag} §r§f{player}", 45, 35, [
				"permission.starter",
				"permission.aster",
                "permission.god",
                "permission.avatar",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.mod",
                "permission.join.full",
                "permission.staff",
                "pocketmine.command.teleport",
                "pocketmine.command.gamemode",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
                "bansystem.command.tempmute",
                "bansystem.command.unmute",
                "permission.once",
                "invsee"
			]));
        $this->addRank(new Rank("Owner", TextFormat::RESET, TextFormat::RESET . "§l§4OWNER§r", Rank::OWNER,
            "§8(§c{faction}§8)§r §l§4OWNER§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}§7: §c{message}",
            "§8(§c{faction}§8)§r\n§l§4OWNER§r §r{tag} §r§f{player}", 50, 40, [
				"permission.starter",
				"permission.aster",
                "permission.god",
                "permission.avatar",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.mod",
                "permission.join.full",
                "permission.staff",
                "pocketmine.command.teleport",
                "pocketmine.command.gamemode",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
				"bansystem.command.tempmute",
				"playervaults.vault.3",
				"playervaults.others.view",
				"playervaults.others.edit",
                "bansystem.command.unmute",
				"permission.once",
				"astral.administrator",
                "invsee"
			]));
        $this->addRank(new Rank("YouTuber", TextFormat::RESET, TextFormat::RESET . "§l§cY§fT§r", Rank::YOUTUBER,
            "§c⚔ §8(§c{faction}§8)§r §l§cYOU§fTUBER§r §r§8[§4§l{kills}§r§8]§r {tag} §r§6{player}§7: §c{message}",
            "§8(§c{faction}§8)§r\n§l§cYou§fTuber§r {tag} §r§6{player}", 20, 10, [
				"permission.starter",
				"permission.aster",
                "permission.god",
                "permission.avatar",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
				"permission.join.full",
				"playervaults.vault.1",
                "permission.once"
            ]));
        $this->addRank(new Rank("Famous", TextFormat::RESET, TextFormat::RESET . "§l§4F§cA§4M§cO§4U§cS§r", Rank::FAMOUS,
            "§8(§c{faction}§8)§r §l§4F§cA§4M§cO§4U§cS§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §c{message}",
            "§8(§c{faction}§8)§r\n§l§4F§cA§4M§cO§4U§cS§r {tag} §r§f{player}", 25, 15, [
				"permission.starter",
				"permission.aster",
                "permission.god",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.avatar",
                "permission.tier2",
				"permission.tier3",
				"playervaults.vault.2",
                "permission.join.full",
                "permission.once"
                ]));
		$this->addRank(new Rank("Developer", TextFormat::RESET, TextFormat::RESET . "§l§bDEVELOPER§r", Rank::DEVELOPER,
            "§8(§c{faction}§8)§r §l§bDEVELOPER§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §3{message}",
            "§8(§c{faction}§8)§r\n§l§bDeveloper§r {tag} §r§f{player}", 35, 30, [
				"permission.starter",
				"permission.aster",
                "permission.god",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.mod",
                "permission.join.full",
                "permission.staff",
                "pocketmine.*",
                "pocketmine.command.teleport",
                "pocketmine.command.gamemode",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "permission.avatar",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
				"bansystem.command.tempmute",
				"playervaults.vault.5",
                "bansystem.command.unmute",
                "permission.once",
                "invsee"
            ]));
        $this->addRank(new Rank("Builder", TextFormat::RESET, TextFormat::RESET . "§l§9BUILDER§r", Rank::BUILDER,
            "§8(§c{faction}§8)§r §l§9BUILDER§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §b{message}",
            "§8(§c{faction}§8)§r\n§l§9BUILDER§r {tag} §r§f{player}", 45, 35, [
				"permission.starter",
				"permission.aster",
                "permission.god",
                "permission.warlord",
                "permission.overlord",
                "permission.avatar",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.mod",
                "permission.join.full",
                "permission.staff",
                "pocketmine.*",
                "pocketmine.command.teleport",
                "pocketmine.command.gamemode",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
				"bansystem.command.tempmute",
				"playervaults.vault.1",
                "bansystem.command.unmute",
                "permission.once",
                "invsee"
            ]));
    }

    /**
     * @param int $identifier
     *
     * @return Rank|null
     */
    public function getRankByIdentifier(int $identifier): ?Rank {
        return $this->ranks[$identifier] ?? null;
    }

    /**
     * @return Rank[]
     */
    public function getRanks(): array {
        return $this->ranks;
    }

    /**
     * @param string $name
     *
     * @return Rank
     */
    public function getRankByName(string $name): ?Rank {
        return $this->ranks[$name] ?? null;
    }

    /**
     * @param Rank $rank
     *
     * @throws RankException
     */
    public function addRank(Rank $rank): void {
        if(isset($this->ranks[$rank->getIdentifier()]) or isset($this->ranks[$rank->getName()])) {
            throw new RankException("Attempted to override a rank with the identifier of \"{$rank->getIdentifier()}\" and a name of \"{$rank->getName()}\".");
        }
        $this->ranks[$rank->getIdentifier()] = $rank;
        $this->ranks[$rank->getName()] = $rank;
    }
}