<?php

declare(strict_types = 1);

namespace core\rank;

use core\Elemental;
use core\ElementalPlayer;

class Rank {

    const ASTRONAUT = 0;

    const ASTER = 1;

    const SIRIUS = 2;

    const ARPINA = 3;

    const AURORA = 4;

	const ALULA = 5;
	
	const NITRO_BOOSTER = 6;

    const ALMATHEA = 7;

	const ADHARA = 8;
	
	const ASTRONOMER = 9;

	const YOUTUBER = 10;

	const YOUTUBER_PLUS = 11;

	const FAMOUS = 12;

	const BUILDER = 13;

    const TRAINEE = 14;

    const MODERATOR = 15;

    const SENIOR_MODERATOR = 16;

    const ADMINISTRATOR = 17;

	const SENIOR_ADMINISTRATOR = 18;
	
	const DEVELOPER = 19;

    const MANAGER = 20;

    const OWNER = 21;

    /** @var string */
    private $name;

    /** @var string */
    private $coloredName;

    /** @var int */
    private $identifier;

    /** @var string */
    private $chatFormat;

    /** @var string */
    private $tagFormat;

    /** @var array */
    private $permissions = [];

    /** @var int */
    private $homes;

    /** @var string */
    private $chatColor;

    /**
     * Rank constructor.
     *
     * @param string $name
     * @param string $chatColor
     * @param string $coloredName
     * @param int $identifier
     * @param string $chatFormat
     * @param string $tagFormat
     * @param int $homes
     * @param int $vaults
     * @param array $permissions
     */
    public function __construct(string $name, string $chatColor, string $coloredName, int $identifier, string $chatFormat, string $tagFormat, int $homes, int $vaults, array $permissions = []) {
        $this->name = $name;
        $this->chatColor = $chatColor;
        $this->coloredName = $coloredName;
        $this->identifier = $identifier;
        $this->chatFormat = $chatFormat;
        $this->tagFormat = $tagFormat;
        $this->homes = $homes;
        for($i = 1; $i <= $vaults; $i++) {
            $permissions = array_merge($permissions, ["playervaults.vault.$i"]);
        }
        $this->permissions = $permissions;
    }

    /**
     * @return string
     */
    public function getName(): string {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getColoredName(): string {
        return $this->coloredName;
    }

    /**
     * @return string
     */
    public function getChatColor(): string {
        return $this->chatColor;
    }

    /**
     * @return int
     */
    public function getIdentifier(): int {
        return $this->identifier;
    }

    /**
     * @param ElementalPlayer $player
     * @param string        $message
     * @param array         $args
     *
     * @return string
     */
    public function getChatFormatFor(ElementalPlayer $player, string $message, array $args = []): string {
        $man = Elemental::getInstance()->getTagManager();
        $tag = $man->getTag($player, true);
		if($tag == null){
        	$tag = "";
        } else {
			$tag = $man->getTagFormat($player, $man->getTag($player, true));
		}
        $format = $this->chatFormat;
        foreach($args as $arg => $value) {
            $format = str_replace("{" . $arg . "}", $value, $format);
		}
		//$tag = $man->getTagFormat($player, $man->getTag($player, true) . " ");
        $format = str_replace("{player}", $player->getDisplayName(), $format);
        $format = str_replace("{tag}", $tag, $format);
        return str_replace("{message}", $message, $format);
    }

    /**
     * @param ElementalPlayer $player
     * @param array         $args
     *
     * @return string
     */
    public function getTagFormatFor(ElementalPlayer $player, array $args = []): string {
        $man = Elemental::getInstance()->getTagManager();
        $tag = $man->getTag($player, true);
        if($tag == null){
            $tag = "";
        } else {
			$tag = $man->getTagFormat($player, $man->getTag($player, true));
		}
        $format = $this->tagFormat;
        foreach($args as $arg => $value) {
            $format = str_replace("{" . $arg . "}", $value, $format);
		}
        $format = str_replace("{tag}", $tag, $format);
        return str_replace("{player}", $player->getDisplayName(), $format);
    }

    /**
     * @return string[]
     */
    public function getPermissions(): array {
        return $this->permissions;
    }

    /**
     * @return int
     */
    public function getHomeLimit(): int {
        return $this->homes;
    }

    /**
     * @return string
     */
    public function __toString() {
        return $this->name;
    }
}
