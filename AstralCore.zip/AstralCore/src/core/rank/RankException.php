<?php

declare(strict_types = 1);

namespace core\rank;

use Exception;

class RankException extends Exception {

}