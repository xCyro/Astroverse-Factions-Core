<?php


namespace core\traits;


trait Tickable {

    public function tick($currentTick) : void {
        // Tik Tok
    }

}