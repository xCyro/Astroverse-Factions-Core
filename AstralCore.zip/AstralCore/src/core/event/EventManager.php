<?php

declare(strict_types = 1);

namespace core\event;

use core\event\christmas\PresentGiftChooser;
use core\event\lootbox\LootBoxChooser;
use core\Elemental;

class EventManager {

    /** @var Elemental */
    private $core;

    /** @var PresentGiftChooser */
	private static $giftChooser;
	
	/** @var LootBoxChooser */
	private static $lootBoxChooser;

    /**
     * ItemManager constructor.
     *
     * @param Elemental $core
     */
    public function __construct(Elemental $core) {
        $this->core = $core;
		self::$giftChooser = new PresentGiftChooser();
		self::$lootBoxChooser = new LootBoxChooser();
    }

    /**
     * @return PresentGiftChooser
     */
    public static function getGiftChooser(): PresentGiftChooser {
        return self::$giftChooser;
	}

	/**
	 * @return LootBoxChooser
	 */
	public static function getLootboxChooser(): LootBoxChooser {
		return self::$lootBoxChooser;
	}
}