<?php

declare(strict_types = 1);

namespace core\event\lootbox;

use core\crate\Reward;
use core\item\ItemManager;
use core\item\types\EnchantmentBook;
use core\item\types\HolyBox;
use core\item\types\LuckyBlock;
use core\item\types\Artifact;
use core\item\types\SellWand;
use core\item\types\{KothFlare, BloodyNote, MoneyPouch};
use core\Elemental;
use core\ElementalPlayer;
use core\rank\Rank;
use pocketmine\item\Item;

class LootBoxChooser {

    /** @var Reward[] */
    private $rewards = [];

    /**
     * Crate constructor.
     */
    public function __construct() {
        $this->rewards = [
            new Reward("Artifact", Item::get(Item::NETHER_QUARTZ, 0, 1), function(ElementalPlayer $player): void {
                $item = (new Artifact())->getItemForm();
                $player->getInventory()->addItem($item);
            }, 250),
            new Reward("Special Box", Item::get(Item::CHEST, 0, 1), function(ElementalPlayer $player): void {
                $kits = Elemental::getInstance()->getKitManager()->getSacredKits();
                $kit = $kits[array_rand($kits)];
                $item = (new HolyBox($kit))->getItemForm();
                $player->getInventory()->addItem($item);
            }, 50),
            new Reward( "$100,000", Item::get(Item::PAPER, 0, 1), function(ElementalPlayer $player): void {
                $player->addToBalance(100000);
            }, 350),
            new Reward("Sell Wand", Item::get(Item::DIAMOND_HOE, 0, 1), function(ElementalPlayer $player): void {
                $player->getInventory()->addItem((new SellWand(50))->getItemForm());
            }, 250),
            new Reward("Enchantment", Item::get(Item::ENCHANTED_BOOK, 0, 1), function(ElementalPlayer $player): void {
                $player->getInventory()->addItem((new EnchantmentBook(ItemManager::getRandomEnchantment()))->getItemForm());
			}, 300),
			new Reward("Koth Flare", Item::get(Item::DYE, 0, 1), function(ElementalPlayer $player): void {
				$player->getInventory()->addItem((new KothFlare(1))->getItemForm());
			}, 300),
			new Reward("Bloody Note", Item::get(Item::PAPER, 0, 1), function(ElementalPlayer $player): void {
				$player->getInventory()->addItem((new BloodyNote(175000))->getItemForm());
			}, 300),
			new Reward("Money Pouch", Item::get(Item::ENDER_CHEST, 0, 1), function(ElementalPlayer $player): void {
				$player->getInventory()->addItem((new MoneyPouch(1000000))->getItemForm());
			}, 150),
        ];
    }

    /**
     * @return Reward[]
     */
    public function getRewards(): array {
        return $this->rewards;
    }

    /**
     * @param int $loop
     *
     * @return Reward
     */
    public function getReward(int $loop = 0): Reward {
        $chance = mt_rand(0, 1000);
        $reward = $this->rewards[array_rand($this->rewards)];
        if($loop >= 20) {
            return $reward;
        }
        if($reward->getChance() <= $chance) {
            return $this->getReward($loop + 1);
        }
        return $reward;
    }
}
