<?php

declare(strict_types=1);

namespace core;

use core\discord\DiscordManager;
use core\faction\Faction;
use core\rank\Rank;
use core\task\PlayerKickTask;
use pocketmine\inventory\ArmorInventory;
use core\translation\Translation;
use core\translation\TranslationException;
use pocketmine\block\Block;
use core\libs\muqsit\invmenu\InvMenu;
use pocketmine\entity\EntityIds;
use pocketmine\entity\Entity;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\LeavesDecayEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\network\mcpe\protocol\AddActorPacket;
use pocketmine\level\Position;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\AddPlayerPacket;
use pocketmine\network\mcpe\protocol\EntityEventPacket;
use pocketmine\network\mcpe\protocol\LevelEventPacket;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\event\entity\EntityLevelChangeEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\event\player\PlayerExperienceChangeEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\event\player\PlayerToggleSneakEvent;
use pocketmine\item\Consumable;
use pocketmine\level\particle\{FlamingParticle, AngryVillagerParticle, BlockForceFieldParticle, BubbleParticle, CriticalParticle, DustParticle, EnchantmentTableParticle, EnchantParticle, EntityFlameParticle, ExplodeParticle, FlameParticle, GenericParticle, HappyVillagerParticle, HeartParticle, HugeExplodeParticle, HugeExplodeSeedParticle, InkParticle, InstantEnchantParticle, ItemBreakParticle, LavaDripParticle, PortalParticle, RainSplashParticle, RedstoneParticle, SmokeParticle, SplashParticle, SporeParticle, TerrainParticle, WaterDripParticle, WaterParticle};
use pocketmine\event\server\CommandEvent;
use pocketmine\network\mcpe\protocol\LoginPacket;
use pocketmine\network\mcpe\protocol\ProtocolInfo;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\event\server\QueryRegenerateEvent;
use pocketmine\item\Item;
use pocketmine\level\particle\Particle;
use pocketmine\math\Vector3;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\network\mcpe\protocol\ActorEventPacket;
use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat;
use pocketmine\event\entity\ItemSpawnEvent;

class ElementalListener implements Listener
{
    private $core;
    private $count = 0;
    private $messages = [];
    private $chat = [];
    private $command = [];
	public $skin = [];
	protected $foodCount = 0;
	protected $foodEvent = false;
	protected $foodMax = 300;

    public function __construct(Elemental $core)
    {
        $this->core = $core;
        $this->messages[] = Elemental::$SERVER_NAME;
        $this->messages = array_merge($this->messages, Elemental::MESSAGES);
    }

    public function onCommandUse(CommandEvent $e): void
    {
        /** @var ElementalPlayer $player */
        $player = $e->getSender();
        if ($player instanceof ElementalPlayer) {
            $webhook = "776154747236253717/n0A_rPlSbXtjaC8Vx4oxj_wq6eu2W-CpB0CLlONdBY340GAPr3c1bxFOTjfBtzyKBZwF";
			DiscordManager::postWebhook($webhook, "Command executed: /" . $e->getCommand(), $player->getName() . " (" . $player->getRank() . ")");
			if($player->getGamemode() === ElementalPlayer::SPECTATOR){
				if($e->getCommand() == "xyz on" || $e->getCommand() == "coords on"){
					$e->setCancelled();
					$player->sendMessage("§8§l(§c!§8) §r§7You can't turn on your coordinates while in spectator.");
					return;
				}
			}
        }
    }

    public function onDrop(PlayerDropItemEvent $e): void
    {
        if (!$e->isCancelled() and $e->getPlayer()->getLevel()->getFolderName() == Elemental::WORLD and !$e->getPlayer()->isOp()) {
            $e->setCancelled();
        }
	}
	
	public function onDataPacketReceive(DataPacketReceiveEvent $event)
	{
	    
	    $pk = $event->getPacket();
        if (!$pk instanceof LoginPacket) return;
        $player = $event->getPlayer();
        $currentProtocol = ProtocolInfo::CURRENT_PROTOCOL;

        $pk->protocol = $currentProtocol;
	    
	}
	
	public function onConsume(PlayerItemConsumeEvent $event){
		$player = $event->getPlayer();
		$item = $event->getItem();

		$webhook = "776157752283365447/ZVpNT5IW26cRotnpIyspJqGP0tSKH-PliBJrWBdCs9xuE1jOwa7HSdwIBNMaEp2HdF9T";

		if($item->getId() === 364){
			if($this->foodEvent == true){
				if($player->getFood() !== $player->getMaxFood()){
					$this->foodCount++;
				}
			}
			if($this->foodEvent == false){
				$this->foodEvent = true;
				$player->getServer()->broadcastMessage(TextFormat::BOLD . TextFormat::DARK_GRAY . "\n(" . TextFormat::AQUA . "!" . TextFormat::DARK_GRAY . ") " . TextFormat::RESET . TextFormat::GRAY . "The food event has started. Eat as much food as you can.\n\n");

				DiscordManager::postWebhook($webhook, "@Events", "Astrobaut", [
					[
						"color" => 0x00ffff,
						"title" => "THE FOOD EVENT HAS BEGUN",
						"description" => "Hello there fellow astronauts! The food event has just begun!\nGet your tummies ready to rumble and start eating!\n\nJoin now with the following information:\n\n**IP**: play.astralmc.tk\n**PORT**: 19132 (Default)"
					]
				]);

			}
			if($this->foodEvent == true and $this->foodCount == 250){
				$player->getServer()->broadcastMessage(TextFormat::BOLD . TextFormat::DARK_GRAY . "(" . TextFormat::AQUA . "!" . TextFormat::DARK_GRAY . ") " . TextFormat::RESET . TextFormat::GRAY . "Everyone online has eaten " . TextFormat::AQUA . $this->foodCount . TextFormat::GRAY . " food so far since the food event started! " . TextFormat::AQUA . "50" . TextFormat::GRAY . " food left to eat!");
			}
			if($this->foodEvent == true and $this->foodCount == 200){
				$player->getServer()->broadcastMessage(TextFormat::BOLD . TextFormat::DARK_GRAY . "(" . TextFormat::AQUA . "!" . TextFormat::DARK_GRAY . ") " . TextFormat::RESET . TextFormat::GRAY . "Everyone online has eaten " . TextFormat::AQUA . $this->foodCount . TextFormat::GRAY . " food so far since the food event started! " . TextFormat::AQUA . "100" . TextFormat::GRAY . " food left to eat!");
			}
			if($this->foodEvent == true and $this->foodCount == 150){
				$player->getServer()->broadcastMessage(TextFormat::BOLD . TextFormat::DARK_GRAY . "(" . TextFormat::AQUA . "!" . TextFormat::DARK_GRAY . ") " . TextFormat::RESET . TextFormat::GRAY . "Everyone online has eaten " . TextFormat::AQUA . $this->foodCount . TextFormat::GRAY . " food so far since the food event started! " . TextFormat::AQUA . "150" . TextFormat::GRAY . " food left to eat!");
			}
			if($this->foodEvent == true and $this->foodCount == 50){
				$player->getServer()->broadcastMessage(TextFormat::BOLD . TextFormat::DARK_GRAY . "(" . TextFormat::AQUA . "!" . TextFormat::DARK_GRAY . ") " . TextFormat::RESET . TextFormat::GRAY . "Everyone online has eaten " . TextFormat::AQUA . $this->foodCount . TextFormat::GRAY . " food so far since the food event started! " . TextFormat::AQUA . "250" . TextFormat::GRAY . " food left to eat!");
			}
			if($this->foodEvent == true and $this->foodCount == $this->foodMax){
				$player->getServer()->broadcastMessage(TextFormat::BOLD . TextFormat::DARK_GRAY . "(" . TextFormat::AQUA . "!" . TextFormat::DARK_GRAY . ") " . TextFormat::RESET . TextFormat::GRAY . "Everyone online has eaten " . TextFormat::AQUA . $this->foodCount . TextFormat::GRAY . " food so far since the food event started! " . TextFormat::AQUA . "Event over.");
				$this->foodEvent = false;
				$this->foodCount = 0;
				$randomKeyAmount = mt_rand(1, 2);
				$player->getServer()->dispatchCommand(new ConsoleCommandSender(), "keyall Astronomic $randomKeyAmount");
				$randomArtifact = mt_rand(1, 5);
				if($randomArtifact <= 4){
					$player->getServer()->dispatchCommand(new ConsoleCommandSender(), "artifactall 1");
				}
			}
		}
	}

    public function onPlayerLogin(PlayerLoginEvent $event): void
    {
		$player = $event->getPlayer();
		$level = $player->getServer()->getDefaultLevel();
        if (!$player instanceof ElementalPlayer) {
            return;
		}
		if($level === null){
			return;
		}
		$spawn = $level->getSpawnLocation();
		$player->teleport($spawn);
		$player->load($this->core);
		$player->addJoin(1);
		
		//if($player->getName() instanceof PlayerName){
			//return $this->playerName();
		//}

		//if($player->getLevel()->getFolderName() === "world"){
			//return 
		//}

    }

    public function onQuit(PlayerQuitEvent $e): void
    {
		$p = $e->getPlayer();
		$n = $p->getName();
        if ($p instanceof ElementalPlayer)
			$session = Elemental::getInstance()->getSession();
        if (isset($session[$p->getName()])) unset(Elemental::getInstance()->sessions[$p->getName()]);
    }

    public function onPlayerJoin(PlayerJoinEvent $event): void {
		$player = $event->getPlayer();
		$name = $player->getName();
		$event->setJoinMessage("§8§l[§a+§8] §r§b" . $event->getPlayer()->getName() . " §r§7has joined the server!");

		if($player->getRank()->getIdentifier() >= Rank::TRAINEE) {
			foreach(Elemental::getInstance()->getServer()->getOnlinePlayers() as $onlinePlayers) {
				if($onlinePlayers->getRank()->getIdentifier() >= Rank::TRAINEE) {
					$onlinePlayers->sendMessage("§8§l(§d!§8) §r§b" . $event->getPlayer()->getName() . " §r§8[§r" . $event->getPlayer()->getRank()->getColoredName() . "§r§8]§r" . " §r§7has been connected to §bOP Factions!§r");
				}
			}
		}

		$player->addTitle(TextFormat::BOLD . TextFormat::DARK_GREEN . "Loading" . TextFormat::RESET . TextFormat::GREEN . "\nFetching your data");
        if (!$player instanceof ElementalPlayer) {
            return;
        }
        $server = $this->core->getServer();
        $players = count($server->getOnlinePlayers());
        $maxPlayers = $this->core->getServer()->getMaxPlayers();
        $max = $maxPlayers - Elemental::EXTRA_SLOTS;
//        if ($players >= $max) {
//            if (!$player->hasPermission("permission.join.full") or $player->getRank()->getIdentifier() < Rank::TRAINEE) {
//                $this->core->getScheduler()->scheduleDelayedTask(new PlayerKickTask($player), 40);
//                return;
//            }
//        }
        foreach ($this->core->getServer()->getOnlinePlayers() as $onlinePlayer) {
            if ($player->getRank()->getIdentifier() >= Rank::TRAINEE and $player->getRank()->getIdentifier() <= Rank::OWNER) {
                break;
            }
            if ($onlinePlayer->hasVanished()) {
                $player->hidePlayer($onlinePlayer);
            }
        }
        if ($player->getCurrentTotalXp() > 0x7fffffff) {
            $player->setCurrentTotalXp(0x7fffffff);
        }
        if ($player->getCurrentTotalXp() < -0x80000000) {
            $player->setCurrentTotalXp(0);
		}

        $this->core->getScheduler()->scheduleDelayedTask(new class($player) extends Task
        {
            private $player;

            public function __construct(ElementalPlayer $player)
            {
                $this->player = $player;
            }

            public function onRun(int $currentTick)
            {
                if ($this->player->isOnline() === false) {
                    return;
				}
				$level = $this->player->getServer()->getDefaultLevel();
				$spawn = $level->getSpawnLocation();
				$this->player->sendTitle(TextFormat::BOLD . TextFormat::DARK_GREEN . "Loading" . TextFormat::RESET . TextFormat::GREEN . "\nFetching your data");
				$this->player->sendTitle("  ", "§b§lASTROVERSE§r\n§d§lOP FACTIONS§r" . "\n\n\n", 5, 20, 5);
				$this->player->setFlying(false);
				$this->player->setAllowFlight(false);

				if($this->player->getClass() !== null) {

					$this->player->teleport($spawn);

				}

				$this->player->getLevel()->broadcastLevelEvent($this->player->add(0, $this->player->getEyeHeight()), LevelEventPacket::EVENT_SOUND_TOTEM);
				$pk = new AddActorPacket();
            	$pk->type = AddActorPacket::LEGACY_ID_MAP_BC[EntityIds::LIGHTNING_BOLT];
            	$pk->entityRuntimeId = Entity::$entityCount++;
            	$pk->position = $this->player->add(0, 1);
            	$pk->yaw = 0;
            	$pk->pitch = 0;
				$this->player->sendDataPacket($pk);
				foreach($this->player->getServer()->getOnlinePlayers() as $players){
					$players->sendDataPacket($pk);
				}
				$this->player->sendMessage("§3------------------------------------------------------------\n\n   §b§lASTROVERSE§r\n\n   §bVote§3: §7vote.astralmc.ml\n   §bStore§3: §7store.astralmc.ml\n   §bDiscord§3: §7discord.io/Astroverse\n\n   §7Use §9/info §r§7for information!\n\n§r§3------------------------------------------------------------");
            }
        }, 40);
        $this->skin[$player->getName()] = $player->getName();
}

    public function onThrow(ItemSpawnEvent $e)
    {
        $entity = $e->getEntity();
        $item = $entity->getItem();
        $name = $item->getName();
        $count = $item->getCount();
        $entity->setNameTag("§7" . $name . " §r§8[§l§ex" . $count . "§r§8]§r");
        $entity->setNameTagVisible(true);
        $entity->setNameTagAlwaysVisible(true);
    }

    public function onPlayerExperienceChange(PlayerExperienceChangeEvent $event): void
    {
        $player = $event->getEntity();
        if (!$player instanceof ElementalPlayer) {
            return;
        }
        if ($player->getCurrentTotalXp() > 0x7fffffff or $player->getCurrentTotalXp() < -0x80000000) {
            $event->setCancelled();
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $event): void
    {
        $event->setQuitMessage("§8§l[§c-§8] §r§b" . $event->getPlayer()->getName() . " §r§7has left the server!");

        unset($this->skin[$event->getPlayer()->getName()]);
    }

    public function onPlayerCreation(PlayerCreationEvent $event): void
    {
        $event->setPlayerClass(ElementalPlayer::class);
    }

    public function onPlayerChat(PlayerChatEvent $event)
    {
        $player = $event->getPlayer();
        if (!$player instanceof ElementalPlayer) {
            return;
        }
        if ($player->getRank()->getIdentifier() >= Rank::ASTRONOMER) {
            return;
        }
        if ($player->getRank()->getIdentifier() < 8) {
            if (!isset($this->chat[$player->getRawUniqueId()])) {
                $this->chat[$player->getRawUniqueId()] = time();
                return;
            }
            if (time() - $this->chat[$player->getRawUniqueId()] >= 3) {
                $this->chat[$player->getRawUniqueId()] = time();
                return;
            }
            $seconds = 3 - (time() - $this->chat[$player->getRawUniqueId()]);
            $player->sendMessage(Translation::getMessage("actionCooldown", [
                "amount" => TextFormat::RED . $seconds
            ]));
            $event->setCancelled();
        }
    }

    public function onPlayerCommandPreprocess(PlayerCommandPreprocessEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof ElementalPlayer) {
            return;
        }
        if ($this->core->getAnnouncementManager()->getRestarter()->getRestartProgress() > 30) {
            if (strpos($event->getMessage(), "/") !== 0) {
                return;
            }
            if ($player->getRank()->getIdentifier() > 8) {
                return;
            }
            if (!isset($this->command[$player->getRawUniqueId()])) {
                $this->command[$player->getRawUniqueId()] = time();
                return;
            }
            if (time() - $this->command[$player->getRawUniqueId()] >= 3) {
                $this->command[$player->getRawUniqueId()] = time();
                return;
            }
            $seconds = 3 - (time() - $this->command[$player->getRawUniqueId()]);
            $player->sendMessage(Translation::getMessage("actionCooldown", [
                "amount" => TextFormat::RED . $seconds
            ]));
            $event->setCancelled();
            return;
        }
        $event->setCancelled();
        $player->sendMessage(Translation::getMessage("restartingSoon"));
    }

    public function onPlayerMove(PlayerMoveEvent $event)
    {
        $player = $event->getPlayer();
        $level = $player->getLevel();
        if ($level->getName() !== Faction::CLAIM_WORLD) {
            return;
        }
        $x = abs($player->getFloorX());
        $y = abs($player->getFloorY());
        $z = abs($player->getFloorZ());
		$message = Translation::getMessage("borderReached");
		$alertMessage = "§cWorld Border\nReached";
        if ($x >= Elemental::BORDER) {
            $player->teleport(new Vector3($x - 1, $y, Elemental::BORDER - 1));
			$player->sendMessage($message);
			$player->addTitle($alertMessage);
        }
        if ($z >= Elemental::BORDER) {
            $player->teleport(new Vector3($x, $y, Elemental::BORDER - 1));
			$player->sendMessage($message);
			$player->addTitle($alertMessage);
        }
        if ($x >= Elemental::BORDER and abs($z) >= Elemental::BORDER) {
            $player->teleport(new Vector3(Elemental::BORDER - 1, $y, Elemental::BORDER - 1));
			$player->sendMessage($message);
			$player->addTitle($alertMessage);
        }
	}
	
	public function regenerativeClassEffects(PlayerMoveEvent $event)
	{

		$player = $event->getPlayer();

		$player->applyClass();

	}

	public function onSneakToggle(PlayerToggleSneakEvent $event) {

		$player = $event->getPlayer();

		if($player instanceof ElementalPlayer) {
			if($player->getClass() == "Assassin") {

				if($player->getAssassinateCooldown() == 30) {

					$player->applyClass();
					$player->addEffect(new EffectInstance(Effect::getEffect(Effect::INVISIBILITY), 5 * 20, 10));
					$player->addEffect(new EffectInstance(Effect::getEffect(Effect::RESISTANCE), 20, 4));
					$player->sendPopup("§bYou are now invisible for §35 §bseconds.");
					$player->resetAssassinateCooldown();

					return;

				}

				$player->addAssassinateCooldown(1);
				//$player->sendPopup("§bYou are currently on cooldown");

			}
		}

	}

	//public function onFlyMovement(PlayerMoveEvent $event) {

		//$player = $event->getPlayer();

		//if($player->isFlying(true)) {

			//$position = Position::fromObject($player->add(0, 0.5, 0), $player->getLevel());

			//$player->getLevel()->addParticle(new SmokeParticle($position));

		//} 

	//}

    public function onQueryRegenerate(QueryRegenerateEvent $event): void
    {
		$event->setMaxPlayerCount($event->getPlayerCount() + 1);
        $event->setPlayerCount($event->getPlayerCount() + 0);
    }

    public function onBlockBreak(BlockBreakEvent $event)
    {
        $player = $event->getPlayer();
        if ($player instanceof ElementalPlayer) {
            if ($player->isInStaffMode()) {
                $event->setCancelled();
                return;
            }
            if ($player->canAutoSell() && $player->isAutoSelling()) {
                $player->autoSell();
            }
            if ($player->isOp()) {
                return;
            }
            $level = $event->getBlock()->getLevel();
            if ($level->getName() == Faction::CLAIM_WORLD || $level->getName() == "teanether") {
                
                return;
                
            }
            else 
            {
                
                $event->setCancelled(true);
                
                return;
                
            }
        }
    }

    public function onBlockPlace(BlockPlaceEvent $event)
    {
        $player = $event->getPlayer();
        if ($player instanceof ElementalPlayer) {
            if ($player->isInStaffMode()) {
                $event->setCancelled();
                return;
            }
            if ($player->isOp()) {
                return;
            }
            $level = $event->getBlock()->getLevel();
            if ($level->getName() == Faction::CLAIM_WORLD || $level->getName() == "teanether") {
                
                return;
                
            }
            else 
            {
                
                $event->setCancelled(true);
                
                return;
                
            }
        }
    }

    public function onEntityLevelChange(EntityLevelChangeEvent $event): void
    {
        $entity = $event->getEntity();
        if (!$entity instanceof ElementalPlayer) {
            return;
		}

		if($entity->getLevel()->getName() == $entity->getServer()->getDefaultLevel()->getName()){

        	foreach ($entity->getFloatingTexts() as $floatingText) {
        	    $floatingText->spawn($entity);
        	}
        	foreach ($this->core->getEntityManager()->getNPCs() as $npc) {
				$npc->spawnTo($entity);
			}
		} else {
//
//			//foreach ($entity->getFloatingTexts() as $floatingText) {
//				//if ($floatingText->isInvisible() and $event->getTarget()->getName() === $floatingText->getLevel()->getName()) {
//					//$floatingText->spawn($entity);
//					//continue;
//				//}
//				//if ((!$floatingText->isInvisible()) and $entity->getLevel()->getName() !== "world") {
//					//$floatingText->despawn($entity);
//					//continue;
//				//}
//			//}
//			//foreach ($this->core->getEntityManager()->getNPCs() as $npc) {
//				//if ($npc->getPosition()->getLevel()->getName() !== $event->getTarget()->getName()) {
//					//$npc->despawnFrom($entity);
//				//} else {
//					//$npc->spawnTo($entity);
//				//}
//				//}
//
//			//return;
//
//			//}
//
		}

		//foreach($entity->getFloatingTexts() as $floatingTexts) {
			//if(!$floatingTexts->isInvisible()) {

				//$floatingTexts->despawn($entity);

			//}
		//}

	}

    public function onLeaveDecay(LeavesDecayEvent $event): void
    {
        $event->setCancelled();
    }

    public function onArmorInteract(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        if ($event->getAction() !== PlayerInteractEvent::RIGHT_CLICK_AIR) {
            return;
        }
        $item = $player->getInventory()->getItemInHand();
        if ($player->getArmorInventory()->getHelmet()->getId() === Item::AIR && in_array($item->getId(), [Item::LEATHER_CAP, Item::CHAIN_HELMET, Item::IRON_HELMET, Item::GOLD_BOOTS, Item::DIAMOND_HELMET, Item::MOB_HEAD, Item::TURTLE_HELMET])) {
            if ($player->isCreative()) return;
            if ($event->isCancelled()) return;
            $helmet = Item::get($item->getId(), $item->getDamage());
            foreach ($item->getEnchantments() as $enchantment) {
                $helmet->addEnchantment($enchantment);
            }
            $helmet->setCustomName($item->hasCustomName() ? $item->getCustomName() : $item->getName());
            $helmet->setLore($item->getLore());
            $player->getArmorInventory()->setHelmet($helmet);
            $player->getInventory()->setItemInHand(Item::get(Item::AIR));
        } elseif ($player->getArmorInventory()->getChestplate()->getId() === Item::AIR && in_array($item->getId(), [Item::LEATHER_CHESTPLATE, Item::CHAIN_CHESTPLATE, Item::IRON_CHESTPLATE, Item::GOLD_CHESTPLATE, Item::DIAMOND_CHESTPLATE, Item::ELYTRA])) {
            if ($player->isCreative()) return;
            if ($event->isCancelled()) return;
            $chestplate = Item::get($item->getId(), $item->getDamage());
            foreach ($item->getEnchantments() as $enchantment) {
                $chestplate->addEnchantment($enchantment);
            }
            $chestplate->setCustomName($item->hasCustomName() ? $item->getCustomName() : $item->getName());
            $chestplate->setLore($item->getLore());
            $player->getArmorInventory()->setChestplate($chestplate);
            $player->getInventory()->setItemInHand(Item::get(Item::AIR));
        } elseif ($player->getArmorInventory()->getLeggings()->getId() === Item::AIR && in_array($item->getId(), [Item::LEATHER_LEGGINGS, Item::CHAIN_LEGGINGS, Item::IRON_LEGGINGS, Item::GOLD_LEGGINGS, Item::DIAMOND_LEGGINGS])) {
            if ($player->isCreative()) return;
            if ($event->isCancelled()) return;
            $leggings = Item::get($item->getId(), $item->getDamage());
            foreach ($item->getEnchantments() as $enchantment) {
                $leggings->addEnchantment($enchantment);
            }
            $leggings->setCustomName($item->hasCustomName() ? $item->getCustomName() : $item->getName());
            $leggings->setLore($item->getLore());
            $player->getArmorInventory()->setLeggings($leggings);
            $player->getInventory()->setItemInHand(Item::get(Item::AIR));
        } elseif ($player->getArmorInventory()->getBoots()->getId() === Item::AIR && in_array($item->getId(), [Item::LEATHER_BOOTS, Item::CHAIN_BOOTS, Item::IRON_BOOTS, Item::GOLD_BOOTS, Item::DIAMOND_BOOTS])) {
            if ($player->isCreative()) return;
            if ($event->isCancelled()) return;
            $boots = Item::get($item->getId(), $item->getDamage());
            foreach ($item->getEnchantments() as $enchantment) {
                $boots->addEnchantment($enchantment);
            }
            $boots->setCustomName($item->hasCustomName() ? $item->getCustomName() : $item->getName());
            $boots->setLore($item->getLore());
            $player->getArmorInventory()->setBoots($boots);
            $player->getInventory()->setItemInHand(Item::get(Item::AIR));
        }
    }

    public function onPlaceHead(BlockPlaceEvent $e): void
    {
        if ($e->getItem()->getId() == Item::SKULL) {
            $e->setCancelled();
        }
    }

    public function onInvTransaction(InventoryTransactionEvent $event): void
    {
        $player = $event->getTransaction()->getSource();
        if ($player instanceof ElementalPlayer) {
            if ($player->isInStaffMode()) {
                $event->setCancelled();
                return;
            }
        }
    }

    public function onItemDrop(PlayerDropItemEvent $event): void
    {
        $player = $event->getPlayer();
        if ($player instanceof ElementalPlayer) {
            if ($player->isInStaffMode()) {
                $event->setCancelled();
                return;
            }
        }
    }

    public function onInteract(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        if ($player instanceof ElementalPlayer) {
			$item = $event->getItem();
			$block = $event->getBlock();
            if ($player->isInStaffMode()) {
                if ($block->getId() === Block::CHEST) {
                    $event->setCancelled();
                    return;
                }
                switch ($item->getId()) {
                    case Item::CONCRETE:
                        if ($item->getDamage() === 5) {
                            $player->setChatMode(ElementalPlayer::PUBLIC);
                            $player->getInventory()->setItem(1, Item::get(Item::CONCRETE, 14, 1)->setCustomName(TextFormat::ITALIC . TextFormat::RED . "Staff Chat"));
                            $player->sendMessage(Translation::getMessage("chatModeSwitch", [
                                "mode" => TextFormat::GREEN . strtoupper($player->getChatModeToString())
                            ]));
                        } elseif ($item->getDamage() === 14) {
                            $player->setChatMode(ElementalPlayer::STAFF);
                            $player->getInventory()->setItem(1, Item::get(Item::CONCRETE, 5, 1)->setCustomName(TextFormat::ITALIC . TextFormat::GREEN . "Staff Chat"));
                            $player->sendMessage(Translation::getMessage("chatModeSwitch", [
                                "mode" => TextFormat::GREEN . strtoupper($player->getChatModeToString())
                            ]));
                        }
                        break;
                    case Item::ICE:
                        $player->sendMessage("§l§8(§a!§8)§r §7You must tap a player with this item to freeze/unfreeze them!");
                        break;
                    case Item::MOB_HEAD:
                        $event->setCancelled();
						$randomPlayer = $this->core->getServer()->getOnlinePlayers()[array_rand($this->core->getServer()->getOnlinePlayers())];
                        if ($randomPlayer instanceof ElementalPlayer) {
                            $player->teleport($randomPlayer->asPosition());
                            $player->sendMessage("§l§8(§a!§8)§r §7You have teleported to " . TextFormat::GREEN . $randomPlayer->getName() . "§r§7.");
                        }
                        break;
                    case Item::BOOK:
                        $player->sendMessage("§l§8(§a!§8)§r §7You must tap a player with this item to see their inventory!");
                        break;
                }
            }
        }
    }

    public function onEntityDamage(EntityDamageEvent $event): void
    {
        $entity = $event->getEntity();
        if ($entity instanceof ElementalPlayer) {
            if ($event instanceof EntityDamageByEntityEvent) {
                $damager = $event->getDamager();
                if ($damager instanceof ElementalPlayer) {
					$event->setAttackCooldown(9);
                    $event->setKnockback($event->getKnockback() - 0.01999999);
                    if ($damager->isInStaffMode()) {
                        $event->setCancelled();
                        switch ($damager->getInventory()->getItemInHand()->getId()) {
                            case Item::ICE:
								$entity->setImmobile(!$entity->isImmobile());
								$entity->sendMessage(Translation::getMessage("freezePlayer"));
								$entity->addTitle("§c§lDO NOT LOGOUT\n§r§cListen to staff");
                                $damager->sendMessage($entity->isImmobile() ? "§l§8(§a!§8)§r §7You have successfully §l§aENABLED§r §7freeze on " . TextFormat::GOLD . $entity->getName() . "§7!" : "§l§8(§a!§8)§r §7You have successfully §l§cDISABLED§r §7freeze on " . TextFormat::GOLD . $entity->getName() . "§7!");
                                break;
							case Item::BOOK:

								$menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
								$inv = $menu->getInventory();
								$menu->readonly();
								$menu->getInventory($entity)->setContents($entity->getInventory()->getContents());
								$menu->setName("§b" . $entity->getName());
								$menu->send($damager);

								$overlay = Item::get(Item::STAINED_GLASS_PANE, 8);
								$overlay->setCustomName(" ");

								$inv->setItem(53, $overlay);
								$inv->setItem(52, $overlay);
								$inv->setItem(51, $entity->getArmorInventory()->getHelmet());
								$inv->setItem(50, $entity->getArmorInventory()->getChestplate());
								$inv->setItem(49, $entity->getArmorInventory()->getLeggings());
								$inv->setItem(48, $entity->getArmorInventory()->getBoots());
								$inv->setItem(47, Item::get(Item::STAINED_GLASS_PANE, 7)->setCustomName(" "));
								$inv->setItem(46, $overlay);
								$inv->setItem(45, $overlay);

//                                $damager->addWindow(SyncInventory::load($entity->getName())); // gotta fix coming soon

                                break;
                        }
                    }
                }
            }
        }
    }

    public function onCommandPreProcess(PlayerCommandPreprocessEvent $event): void
    {
        $player = $event->getPlayer();
        if ($player instanceof ElementalPlayer) {
            if (substr($event->getMessage(), 0, 1) === "/") {
                $command = substr(explode(" ", $event->getMessage())[0], 1);
            }
        }
    }

    public function onStaffModeQuit(PlayerQuitEvent $event): void
    {
        $player = $event->getPlayer();
        if ($player instanceof ElementalPlayer) {
            if ($player->isInStaffMode()) {
                $player->setStaffMode(false);
            }
        }
    }

    /**
     * @param PlayerExhaustEvent $event
     */
    public function onPlayerExhaust(PlayerExhaustEvent $event): void
    {
        $player = $event->getPlayer();
        if ($player instanceof ElementalPlayer) {
           if($player->hasFeedCooldown()) {
               $event->setCancelled();
           }
        }
	}
	
	private $xp;

	public function onDeath(PlayerDeathEvent $event){

		$player = $event->getPlayer();

		$this->xp[$player->getName()] = $player->getXpLevel();

		//$player->load($this->core);

	}

	public function onRespawn(PlayerRespawnEvent $event){

		$player = $event->getPlayer();

		$player->load($this->core);
		
	}
}
