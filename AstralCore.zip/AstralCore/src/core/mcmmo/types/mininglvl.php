<?php

declare(strict_types = 1);

namespace core\mcmmo\types;

use core\mcmmo\Mcmmo;
use core\mcmmo\McmmoManager;
use core\Elemental;
use core\ElementalPlayer;
use core\utils\UtilsException;
use pocketmine\item\Item;
use pocketmine\level\Position;

class mininglvl extends Mcmmo {

    /**
     * mininglvl constructor.
     *
     */
    public function __construct() {
        parent::__construct(self::MINING, [

			// Todo

        ]);
    }
}
