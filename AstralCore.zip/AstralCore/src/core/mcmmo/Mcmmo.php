<?php

declare(strict_types = 1);

namespace core\mcmmo;

use core\crate\task\AnimationTask;
use core\Elemental;
use core\ElementalPlayer;
use core\libs\form\CustomForm;
use core\translation\Translation;
use core\translation\TranslationException;
use pocketmine\level\Position;

abstract class Mcmmo {

	const PLAYER = "Player";

	const MINING = "Mining";

	const COMBAT = "Combat";
	
	/** @var string */
    private $name;

    /**
     * Mcmmo constructor.
	 * 
	 * @param string $name
	 * 
     */
    public function __construct(string $name) {

		$this->name = $name;

		$this->player = Mcmmo::PLAYER;
		$this->mining = Mcmmo::MINING;
		$this->combat = Mcmmo::COMBAT;

	}
	
	/**
     * @return string
     */
    public function getName(): string {
        return $this->name;
    }

}