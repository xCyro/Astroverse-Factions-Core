<?php

declare(strict_types=1);

namespace core\mcmmo;

use core\Elemental;
use core\ElementalPlayer;
use core\translation\TranslationException;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\inventory\ChestInventory;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\tile\Chest;

use core\mcmmo\McmmoManager;

class McmmoListener implements Listener
{

    /** @var Elemental */
    private $core;

    /**
     * McmmoListener constructor.
     *
     * @param Elemental $core
     */
    public function __construct(Elemental $core)
    {
        $this->core = $core;
    }

    /**
     * @param PlayerJoinEvent $event
     */
    public function onPlayerJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof ElementalPlayer) {
            return;
        }
    }

    /**
     * @priority LOWEST
     * @param PlayerInteractEvent $event
     *
     * @throws TranslationException
     */
    public function onPlayerInteract(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof ElementalPlayer) {
            return;
        }
        $block = $event->getBlock();
	}

	public function onBlockBreak(BlockBreakEvent $event) {

		//if($event->isCancelled(true)) {
			//return;
		//}

		$entity = $event->getPlayer();

		//$entity->sendMessage("lol");

		if($entity instanceof ElementalPlayer) {

			//$mcmmo = Elemental::getInstance()->getMcmmoManager();->getMcmmo("Mining");

			//$entity->addMcmmoLevel($mcmmo);

			//Elemental::getInstance()->getServer()->broadcastMessage("idk");

		}

	}

}