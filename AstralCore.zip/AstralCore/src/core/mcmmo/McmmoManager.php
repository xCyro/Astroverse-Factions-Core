<?php

declare(strict_types = 1);

namespace core\mcmmo;

use core\Elemental;
use core\mcmmo\Mcmmo;
use pocketmine\item\Item;
use pocketmine\level\Position;
use pocketmine\utils\Config;

use core\mcmmo\types\playerlvl;
use core\mcmmo\types\mininglvl;

class McmmoManager {

    /** @var Elemental */
	private $core;
	
	/** @var Mcmmo[] */
	private $mcmmo = [];

    /**
     * McmmoManager constructor.
     *
     * @param Elemental $core
     */
    public function __construct(Elemental $core) {
		$this->core = $core;
		//Elemental::getInstance()->getServer()->getPluginManager()->registerEvents(new McmmoListener($core), $core);
		$this->init();
	}

	public function init(){

		$this->addMcmmo(new playerlvl());
		$this->addMcmmo(new mininglvl());

	}

	/**
     * @return Mcmmo[]
     */
    public function getMcmmoList(): array {
        return $this->mcmmo;
    }

    /**
     * @param string $identifier
     *
     * @return Mcmmo|null
     */
    public function getMcmmo(string $identifier): ? Mcmmo {
        return isset($this->mcmmo[strtolower($identifier)]) ? $this->mcmmo[strtolower($identifier)] : null;
    }

	/**
     * @param Mcmmo $mcmmo
     */
    public function addMcmmo(Mcmmo $mcmmo) {
        $this->mcmmo[strtolower($mcmmo->getName())] = $mcmmo;
    }

}
