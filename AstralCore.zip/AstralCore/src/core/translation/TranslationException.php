<?php

declare(strict_types = 1);

namespace core\translation;

use Exception;

class TranslationException extends Exception {

}