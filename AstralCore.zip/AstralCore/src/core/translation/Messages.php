<?php

declare(strict_types = 1);

namespace core\translation;

use core\faction\Faction;
use pocketmine\utils\TextFormat;

interface Messages {

    const MESSAGE = [
        "noPermission" => self::RED . "You don't have permission to do this action!",
        "invalidPlayer" => self::RED . "§7The player that you specified is invalid.§r",
        "invalidAmount" => self::RED . "§7The amount that you specified is invalid.§r",
        "invalidEnchantment" => self::RED . "§7The enchantment that you specified is invalid.§r",
        "invalidItem" => self::RED . "§7The item that you specified is invalid.§r",
        "invalidKit" => self::RED . "§7The kit that you specified is invalid.§r",
        "invalidBoss" => self::RED . "§r §7The boss that you specified is invalid.§r",
        "invalidBlock" => self::RED . "§r §7The block that you specified is invalid.§r",
        "invalidSound" => self::RED . "§r §7The sound that you specified is invalid.§r",
        "invalidParticle" => self::RED . "§r §7The particle that you specified is invalid.§r",
        "invalidRank" => self::RED . "§r §7The rank that you specified is invalid.§r",
        "invalidCrate" => self::RED . "§r §7The crate that you specified is invalid.§r",
        "invalidCoinFlip" => self::RED . "§r §7The coin flip that you specified is invalid.§r",
        "existingCoinFlip" => self::RED . "You already have an existing coin flip!",
        "addCoinFlip" => self::GREEN . "You have added a coin flip bet.",
        "canOnlySpawnInArena" => self::RED . "You can only spawn this in the boss arena!",
        "bossSpawned" => self::PURPLE . "A exclusive boss that was bought on the store has been spawned in the boss arena. The player that deals the MOST damage gets 4 rewards! Everyone else gets 1 reward! To teleport to the boss arena, type /boss.",
        "enchantmentRemoverFail" => self::RED . "Your enchantment remover failed, {enchantment} was removed!",
        "blockProtected" => self::RED . "You can not do this action because this block is protected!",
        "questComplete" => self::GREEN . "You've completed {name} quest and earned {amount} points!",
        "onlyInSpawn" => self::RED . "You can only do this at the spawn!",
		"successRepair" => self::GREEN . "You've successfully fixed this item.",
		"successRepairFree" => self::GREEN . "You've successfully fixed this item for free!",
        "successRename" => self::GREEN . "You've successfully renamed an item.",
        "nothingSellable" => self::RED . "You don't have anything to sell!",
        "notSellable" => self::RED . "This item is not sellable!",
        "notBuyable" => self::RED . "This item is not buyable!",
        "rankUp" => self::AQUA . "{name} Has Ranked Up To {rank} Using /rankup.",
        "buy" => self::PURPLE . "You bought {amount} {item} for {price}.",
        "sell" => self::PURPLE . "You sold {amount} {item} for {price}.",
        "turnOnAToggle" => self::RED . "You don't have the required amount of money to do this action.", // I know it's for not turning a toggle but it makes more sense on where it is used :/
        "factionAddPowerSuccess" => self::GREEN . "You've successfully added {amount} power to {name}.",
        "beInFaction" => self::RED . "You must be in a faction to do this action!",
        "factionMaxAllies" => self::RED . "{faction} has reached its max amount of allies!",
        "allyRequest" => self::PURPLE . "{senderFaction} has requested to ally with {faction}.",
        "allyAdd" => self::PURPLE . "Your faction has allied with {faction}.",
        "notAllied" => self::PURPLE . "Your faction is not allied with {faction}.",
        "invalidFaction" => self::RED . "Invalid faction!",
        "homeNotSet" => self::RED . "You don't have a set home!",
        "notInvited" => self::RED . "You were not invited to {faction}!",
        "factionMaxMembers" => self::RED . "{faction} has reached its max amount of members!",
        "inviteSentSender" => self::GREEN . "You've invited {name} to the faction!",
        "inviteSentPlayer" => self::GREEN . "You've been invited to {faction}! Use /f join {faction} to join!",
        "factionJoin" => self::PURPLE . "{name} has joined the faction!",
        "factionLeave" => self::PURPLE . "{name} has left the faction!",
        "inClaim" => self::RED . "You are in a faction's claim!",
        "promotion" => self::PURPLE . "{name} has been promoted to {position}.",
        "editClaimNotAllowed" => self::RED . "You aren't allowed to edit this claim!",
        "claimSuccess" => self::GREEN . "You've successfully claimed this chunk!",
        "overclaimSuccess" => self::GREEN . "You've successfully over claimed this claim!",
        "mustLeaveFaction" => self::RED . "You must leave your faction to do this!",
        "factionNameTooLong" => self::RED . "The specified faction name is too long!",
        "existingFaction" => self::RED . "{faction} is already an existing faction!",
        "factionCreate" => self::GREEN . "You've successfully created a faction.",
        "notFactionMember" => self::RED . "{name} is not one of your faction members!",
        "cannotPromote" => self::RED . "{name} can not be promoted!",
        "promoted" => self::PURPLE . "{name} has been promoted by {sender}.",
        "cannotDemote" => self::RED . "{name} can not be demoted!",
        "demoted" => self::PURPLE . "{name} has been demoted by {sender}.",
        "deposit" => self::PURPLE . "{name} has deposited {amount}.",
        "withdraw" => self::PURPLE . "{name} has withdrew {amount}.",
        "mustBeInClaim" => self::RED . "You must be in your claim to do this action!",
        "homeSet" => self::GREEN . "Faction home has been set!",
        "unally" => self::PURPLE . "Your faction has unallied with {faction}.",
        "doNotOwnClaim" => self::RED . "You do not own this claim!",
        "notEnoughStrength" => self::RED . "You don't have enough power!",
        "notEnoughLevels" => self::RED . "You don't have enough levels!",
        "notClaimed" => self::RED . "This area of land is not claimed!",
        "unclaimSuccess" => self::GREEN . "You've successfully unclaimed this part of the land!",
        "forceDelete" => self::GREEN . "You've successfully force deleted a faction.",
        "notEnoughFactionMembersToClaim" => self::RED . "You don't have enough faction members to claim! You need at least " . Faction::MEMBERS_NEEDED_TO_CLAIM . "!",
        "kothReward" => self::BLUE . "You have received a KOTH lootbag!",
        "keyAll" => self::BLUE . "{name} gave everyone online {amount} {type} crate key(s)!",
        "artifactAll" => self::BLUE . "{name} gave everyone online {amount} artifact(s)!",
        "notNumeric" => self::RED . "The number you've entered isn't a valid number!",
        "restartMessage" => "§l§8[§b+§8]§r §7The server will reboot in {hours} hour(s), {minutes} minutes(s) and {seconds} second(s).§r",
        "listMessage" => "{count} {group}: {list}",
        "homeExist" => self::RED . "You can't create an already existing home!",
        "invalidHome" => self::RED . "The home that you specified is invalid!",
        "setHome" => self::GREEN . "You've successfully set a home at your current location.",
        "deleteHome" => self::GREEN . "You've successfully removed a home.",
        "kitCooldown" => self::BLUE . "§7The selected kit is currently on cool down for {time}.§r",
        "maxReached" => self::RED . "You have reached the maximum!",
        "errorOccurred" => self::RED . "An error had occurred in this process!",
        "alreadyVoted" => self::RED . "You have already claimed your vote!",
        "haveNotVoted" => self::RED . "You have note voted yet! Vote at §bvote.astralmc.tk§r",
        "voteBroadcast" => self::AQUA . "{name} has voted for our server at §bvote.astralmc.ml §7and received a reward! {votes} votes before everyone receiving {amount} artifacts! Amount of total artifacts given increases as the goal is achieved.",
        "payMoneyTo" => self::GREEN . "You've sent {amount} to {name}.",
        "receiveMoneyFrom" => self::GREEN . "You've received {amount} from {name}.",
        "tagSetSuccess" => self::GREEN . "You've successfully set your tag to {tag}.",
        "tagAddSuccess" => self::GREEN . "You've successfully added a {tag} tag to {name}.",
        "chatModeSwitch" => self::GREEN . "Your chat mode has been switched to {mode}.",
        "alreadyTeleporting" => self::RED . "{name} already teleporting somewhere!",
        "alreadyTrading" => self::RED . "{name} is already trading with someone!",
        "successTrade" => self::GREEN . "You've successfully traded!.",
        "inboxAlert" => self::PURPLE . "It seems like you have unclaimed items in your inbox. Claim it by using /inbox.",
        "alreadyRequest" => self::RED . "You have already requested!",
        "didNotRequest" => self::RED . "No request by them was found!",
        "denyRequest" => self::ORANGE . "Your request was denied.",
        "acceptRequest" => self::ORANGE . "Your request was accepted.",
        "requestTeleport" => self::ORANGE . "{name} requested to teleport to {player}.",
        "requestTrade" => self::ORANGE . "{name} requested to trade with {player}.",
        "rankSet" => self::GREEN . "You've successfully set {name}'s rank to {rank}.",
        "addMoneySuccess" => self::GREEN . "You've successfully added {amount} to {name}'s balance.",
        "removeMoneySuccess" => self::GREEN . "You've successfully removed {amount} from {name}'s balance.",
        "fullInventory" => self::RED . "Your inventory has reached it's maximum limit of storage!",
        "animationAlreadyRunning" => self::RED . "There's already an animation running!",
        "noKeys" => self::RED . "You don't have any keys for this crate!",
        "noPermissionCombatTag" => self::RED . "You can't do this action because you are combat tagged!",
        "enterSafeZoneInCombat" => self::RED . "You can't enter a safe zone while in combat!",
        "combatTag" => self::RED . "You've been combat tagged, you may not log out for 15 seconds!",
        "flightToggle" => self::AQUA . "Your flight has been toggled.",
        "vanishToggle" => self::ORANGE . "Your visibility has been toggled.",
        "autoSellToggle" => self::ORANGE . "Your auto sell has been toggled.",
        "hungerRestored" => self::GREEN . "Your hunger has been restored!",
        "death" => self::AQUA . "{name} died.",
        "deathByPlayer" => self::AQUA . "{name} took the L to {killer}.",
        "borderReached" => self::RED . "You've reached the world border!",
        "broadcast" => self::PURPLE . "{message}",
        "restartingSoon" => self::RED . "The server is rebooting soon!",
        "addPermission" => self::GREEN . "You have successfully added permission \"{permission}\" to {name}.",
        "balance" => self::GREEN . "{name} balance: {amount}",
        "actionCooldown" => self::RED . "Slow down! This action is currently on cooldown for {amount} seconds!",
        "notEnoughPoints" => self::RED . "You don't have enough points!",
        "notEnoughMoney" => self::RED . "You don't have enough money!",
        "targetNotEnoughMoney" => self::RED . "{name} doesn't have enough money!",
        "notEnoughMoneyRankUp" => self::RED . "You don't have enough money! You need {amount} in total!",
        "maxRank" => self::RED . "You are at max rank!",
        "frozen" => self::RED . "{name} is currently frozen!",
        "freezePlayer" => self::RED . "You have been frozen! If you leave, that means you will be admitting to cheating causing a 7 day ban!",
        "freezeSender" => self::GREEN . "You've successfully frozen {player}.",
        "unfreezePlayer" => self::GREEN . "You have been unfrozen.",
        "unfreezeSender" => self::GREEN . "You've successfully unfrozen {player}.",
        "coordsShowChange" => self::GREEN . "You've turned {mode} your coordinates displayer.",
        "broadcastMessage" => "{message}",
        "luckyBlockFound" => self::ORANGE . "You've found a lucky block!",
        "haveCorrectRank" => self::RED . "You currently are the rank you are supposed to be in!",
        "rankTransferred" => self::GREEN . "Your rank has been successfully transferred!",
        "attackFactionAssociate" => self::RED . "You may not attack a faction associate!",
        "needLevelsToEnchant" => self::RED . "You need {amount} xp levels to apply this enchantment!",
        "banMessage" => TextFormat::RED . "You have been banned by {name} " . TextFormat::RED . "for \"{reason}" . TextFormat::RED . "\". Expiration: {time}" . TextFormat::RED . ".",
        "kickMessage" => TextFormat::RED . "You have been kicked by {name} " . TextFormat::RED . "for \"{reason}" . TextFormat::RED . "\".",
        "muteMessage" => TextFormat::RED . "You have been muted by {name} " . TextFormat::RED . "for \"{reason}" . TextFormat::RED . "\". Expiration: {time}" . TextFormat::RED . ".",
        "banBroadcast" => self::RED . TextFormat::RED . "{name} " . TextFormat::RED . "has been banned by {effector} " . TextFormat::RED . "for \"{reason}" . TextFormat::RED . "\". Expiration: {time}" . TextFormat::RED . ".",
        "muteBroadcast" => self::RED . TextFormat::RED . "{name} " . TextFormat::RED . "has been muted by {effector} " . TextFormat::RED . "for \"{reason}" . TextFormat::RED . "\". Expiration: {time}" . TextFormat::RED . ".",
        "kickBroadcast" => self::RED . TextFormat::RED . "{name} " . TextFormat::RED . "has been kicked by {effector} " . TextFormat::RED . "for \"{reason}" . TextFormat::RED . "\".",
        "punishmentRelivedBroadcast" => self::GREEN . TextFormat::GREEN . "{name}" . TextFormat::GREEN . "'s punishment has been relieved by {effector}" . TextFormat::GREEN . "!",
        "usageMessage" => self::ORANGE . "Usage: {usage}",
        "successAbuse" => self::GREEN . "You've successfully executed this abusive staff command.",
        "unallowedAbuse" => self::RED . "You cannot do this. The reason being is to prevent any sort of staff abuse.",
		"withdrawXpWhileMending" => self::RED . "You cannot withdraw XP while holding an item with the Mending Enchantment",
		"gambleLost" => self::RED . "You have lost §b{money} §7from gambling!",
		"gambleWon" => self::GREEN . "You have won §b{money} §7from gambling!",
		"gambleWonAnnouncement" => self::AQUA . "§b{player} §7has just won §b{money} §7from gambling!" 
    ];

    const RED = "§c§lAstral §r§8| §r§7";

    const ORANGE = "§6§lAstral §r§8| §r§7";

    const GREEN = "§a§lAstral §r§8| §r§7";

    const AQUA = "§b§lAstral §r§8| §r§7";

    const PURPLE = "§d§lAstral §r§8| §r§7";

	const BLUE = "§3§lAstral §r§8| §r§7";
	
	const DARK_BLUE = "§1§lAstral §r§8| §r§7";

	const DISCORD_COLOR = "§9§lAstral §r§8| §r§7";
	
}
