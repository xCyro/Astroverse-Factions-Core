<?php

namespace core\outpost;


use core\ElementalPlayer;
use core\utils\FloatingTextParticle;
use pocketmine\level\Position;
use pocketmine\math\AxisAlignedBB;
use pocketmine\Player;
use pocketmine\Server;

class Outpost
{
}
