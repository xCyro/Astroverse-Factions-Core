<?php

namespace core\outpost\task;

use core\Elemental;
use core\ElementalPlayer;
use core\item\CustomItem;
use core\item\types\CrateKeyNote;
use core\item\types\SellWand;
use core\outpost\Outpost;
use core\outpost\OutpostManager;
use core\translation\Translation;
use pocketmine\item\Item;
use pocketmine\scheduler\Task;
use pocketmine\level\Position;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat;
use pocketmine\event\player\PlayerMoveEvent;

class OutpostCapturetask extends Task
{
	private $player;
	
    /**
     * @var int
     */
    private $time = 0;

    public function __construct($player)
    {
		$this->player = $player;
		$this->taskId = $this->getTaskId();
    }

    function onRun(int $currentTick)
    {

		$outpost = Elemental::getInstance()->getOutpostManager();

		if($outpost->isCaptured() == true)
		{

			$outpost->setCaptured(false);

			return;

		}

		$this->time++;
		$this->player->sendPopup("§cCapturing: §r§a" . $this->time .  "§2%");
		if($this->time == 100){
			$outpost->setCaptured(true);
			Elemental::getInstance()->getScheduler()->cancelTask($this->getTaskId());
			//Elemental::getInstance()->getScheduler()->scheduleRepeatingTask(new OutpostCapturingTask($this->player), $this);
			return;
		}
	}
}