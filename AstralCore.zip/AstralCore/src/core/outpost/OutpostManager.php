<?php

namespace core\outpost;


use core\Elemental;
use core\ElementalPlayer;
use core\outpost\task\OutpostCapturetask;
use core\outpost\task\OutpostParticleTask;
use core\translation\Translation;
use core\utils\FloatingTextParticle;
use pocketmine\entity\Entity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\math\AxisAlignedBB;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\scheduler\TaskScheduler;
use pocketmine\utils\TextFormat;

class OutpostManager implements Listener
{

	//protected $firstPosition = new Position(196, 82, 506, Elemental::getInstance()->getServer()->getLevelByFolderName("pvp")); 
	//protected $secondPosition = new Position(194, 82, 504, Elemental::getInstance()->getServer()->getLevelByFolderName("pvp"));

	public function __construct()
	{
		$this->firstPosition = new Position(196, 82, 506, Elemental::getInstance()->getServer()->getLevelByName("world"));
		$this->secondPosition = new Position(194, 78, 504, Elemental::getInstance()->getServer()->getLevelByName("world"));
		$this->level = Elemental::getInstance()->getServer()->getDefaultLevel();
		$this->isCapturing = false;
		$this->isCaptured = false;
		$this->taskRunning = false;
	}

	//public function onMove(PlayerMoveEvent $event){
		//$player = $event->getPlayer();
		//if(!$player instanceof ElementalPlayer){
			//return;
		//}

		//$level = $player->getLevel();

		//$position = $player->getPosition();

		//$player->sendMessage('a');
		

		//if($this->isPositionInside($position) and ($this->isCapturing == false)){
			//$this->isCapturing = true;
			//$this->taskRunning = true;
			//$player->sendMessage('b');
			//Elemental::getInstance()->getScheduler()->scheduleRepeatingTask(new OutpostCapturetask($player), 20);
		//}
		//if(!$this->isPositionInside($position) and ($this->isCapturing == true) and ($this->taskRunning == true) and ($this->isCaptured == false)){
			//$player->sendMessage("c");
			//$this->isCapturing = false;
			//$this->taskRunning = false;
			//return;
		//}

	//}

	/**
     * @param Position $position
     *
     * @return bool
     */
    public function isPositionInside(Position $position): bool {
        $level = $position->getLevel();
        $firstPosition = $this->firstPosition;
        $secondPosition = $this->secondPosition;
        $minX = min($firstPosition->getX(), $secondPosition->getX());
        $maxX = max($firstPosition->getX(), $secondPosition->getX());
        $minY = min($firstPosition->getY(), $secondPosition->getY());
        $maxY = max($firstPosition->getY(), $secondPosition->getY());
        $minZ = min($firstPosition->getZ(), $secondPosition->getZ());
        $maxZ = max($firstPosition->getZ(), $secondPosition->getZ());
        return $minX <= $position->getX() and $maxX >= $position->getX() and $minY <= $position->getY() and
            $maxY >= $position->getY() and $minZ <= $position->getZ() and $maxZ >= $position->getZ() and
            $this->level->getName() === $level->getName();
	}
	
	    /**
     * @return Position
     */
    public function getFirstPosition(): Position {
        return $this->firstPosition;
    }

    /**
     * @return Position
     */
    public function getSecondPosition(): Position {
        return $this->secondPosition;
	}
	
	public function isCapturing(): bool
	{

		return $this->isCapturing;

	}

	public function isCaptured(): bool
	{

		return $this->isCaptured;

	}

	public function isTaskRunning(): bool
	{

		return $this->isTaskRunning;

	}

	public function setTaskRunning($value)
	{

		$this->isTaskRunning = $value;

	}
	
	public function setCaptured($value)
	{

		$this->isCaptured = $value;

	}

	public function setCapturing($value)
	{

		$this->isCapturing = $value;

	}

}