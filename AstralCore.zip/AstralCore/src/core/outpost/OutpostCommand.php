<?php

namespace core\outpost;

use core\command\utils\Command;
use core\Elemental;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AnimatePacket;
use pocketmine\utils\TextFormat;
use core\command\task\TeleportTask;
use pocketmine\level\Position;
use pocketmine\Server;
use pocketmine\level\Level;

class OutpostCommand extends Command
{

    public function __construct()
    {
        parent::__construct('outpost', 'Outposts Command', '', ['']);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if (!$sender instanceof ElementalPlayer) return;
        if (!$args) {
			$x = 1;
			$y = 30;
			$z = 1;
			$level = $sender->getServer()->getLevelByName('pvp');
			$position = $level->getSpawnLocation();
			Elemental::getInstance()->getScheduler()->scheduleRepeatingTask(new TeleportTask($sender, $position, 5), 20);			
			return;
		}
		if($args[0] == "coords" || $args[0] == "coordinates" || $args[0] == "c"){
			$sender->sendMessage("§c§lOUTPOST§r§c: §r§7The outpost is located at the warzone. Type §e/outpost §7or §e/pvp §7to teleport there!");
			return;
		}
		if($args[0] == "list" || $args[0] == "l" || $args[0] == "types"){
			$sender->sendMessage("§c§lOUTPOSTS§r§c: §r§bCavern §r§7and §bArtisan§7!");
			return;
		}
    }
}
